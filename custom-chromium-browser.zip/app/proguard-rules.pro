# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# GeckoView keep rules for R8 / ProGuard
-keep class org.mozilla.geckoview.** { *; }
-keep class org.mozilla.gecko.** { *; }
-dontwarn org.mozilla.geckoview.**
-dontwarn org.mozilla.gecko.**

# R8 shrinking & optimization without obfuscation (keep readable stack traces)
-dontobfuscate
-keepattributes SourceFile,LineNumberTable,Signature,*Annotation*,InnerClasses,EnclosingMethod

# Suppress missing class warnings detected by R8 (from missing_rules.txt)
-dontwarn java.beans.**
-dontwarn java.beans.BeanInfo
-dontwarn java.beans.FeatureDescriptor
-dontwarn java.beans.IntrospectionException
-dontwarn java.beans.Introspector
-dontwarn java.beans.PropertyDescriptor
-dontwarn javax.script.**
-dontwarn org.mozilla.javascript.**

# NewPipeExtractor & Rhino keep rules for R8 / ProGuard
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**
-keep class org.mozilla.javascript.** { *; }
-dontwarn org.mozilla.javascript.**

# jsoup (transitive dependency of NewPipeExtractor) optionally uses re2j
-dontwarn com.google.re2j.**
-dontwarn com.google.re2j.Matcher
-dontwarn com.google.re2j.Pattern
