package com.example

import com.example.data.local.SitePolicyStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
    @Test
    fun testNormalizeHost() {
        assertEquals("example.com", SitePolicyStore.normalizeHost("https://www.example.com/page?query=1"))
        assertEquals("example.com", SitePolicyStore.normalizeHost("http://example.com:8080/"))
        assertEquals("m.example.com", SitePolicyStore.normalizeHost("https://m.example.com"))
        assertEquals("facebook.com", SitePolicyStore.normalizeHost("www.facebook.com"))
        assertEquals("news.vnexpress.net", SitePolicyStore.normalizeHost("https://news.vnexpress.net/articles"))
    }

    @Test
    fun testHostBlockedMatching() {
        val blocked = setOf("example.com", "malicious-site.org")

        fun isBlocked(target: String): Boolean {
            val norm = SitePolicyStore.normalizeHost(target)
            return blocked.any { b ->
                val normB = SitePolicyStore.normalizeHost(b)
                norm == normB || norm.endsWith(".$normB")
            }
        }

        // Exact match
        assertTrue(isBlocked("example.com"))
        assertTrue(isBlocked("https://example.com"))
        assertTrue(isBlocked("www.example.com"))

        // Subdomain match (e.g. m.example.com)
        assertTrue(isBlocked("m.example.com"))
        assertTrue(isBlocked("https://m.example.com/login"))
        assertTrue(isBlocked("sub.api.example.com"))

        // Should not block unrelated domains ending with example.com
        assertFalse(isBlocked("notexample.com"))
        assertFalse(isBlocked("myexample.com"))
        assertFalse(isBlocked("google.com"))
    }

    @Test
    fun testPopupAllowedMatching() {
        val allowed = setOf("trusted.com")

        fun isAllowed(target: String): Boolean {
            val norm = SitePolicyStore.normalizeHost(target)
            return allowed.any { a ->
                val normA = SitePolicyStore.normalizeHost(a)
                norm == normA || norm.endsWith(".$normA")
            }
        }

        assertTrue(isAllowed("trusted.com"))
        assertTrue(isAllowed("login.trusted.com"))
        assertTrue(isAllowed("https://www.trusted.com/auth"))
        assertFalse(isAllowed("untrusted.com"))
    }
}
