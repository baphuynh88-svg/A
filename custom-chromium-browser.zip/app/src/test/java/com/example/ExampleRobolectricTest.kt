package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SitePolicyStore
import com.example.data.local.ShortcutStore
import com.example.gecko.AuraDownloader
import com.example.gecko.MediaDownloader
import com.example.gecko.MediaItem
import com.example.gecko.MediaKind
import com.example.gecko.MediaNotificationData
import com.example.gecko.SaviorDownloadStatus
import com.example.gecko.SaviorItemDownloadState
import com.example.gecko.YouTubeExtractorRepo
import com.example.gecko.YtDownloader
import com.example.gecko.YtOption
import com.example.ui.BrowserViewModel
import com.example.ui.components.formatYtOptionSizeMb
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.exceptions.AgeRestrictedContentException
import org.schabi.newpipe.extractor.exceptions.GeographicRestrictionException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aura Browser", appName)
  }

  @Test
  fun `normalizeHost parses userinfo port trailing dot ipv6 and path`() {
    assertEquals("blocked.com", SitePolicyStore.normalizeHost("http://a@blocked.com/"))
    assertEquals("blocked.com", SitePolicyStore.normalizeHost("https://BLOCKED.com:8443/x?y#z"))
    assertEquals("blocked.com", SitePolicyStore.normalizeHost("blocked.com."))
    assertEquals("[::1]", SitePolicyStore.normalizeHost("http://[::1]:8080/"))
    assertEquals("blocked.com", SitePolicyStore.normalizeHost("blocked.com/path"))
    assertEquals("blocked.com", SitePolicyStore.normalizeHost("https://www.blocked.com./test"))
    assertEquals("", SitePolicyStore.normalizeHost(""))
    assertEquals("", SitePolicyStore.normalizeHost("about:blank"))
  }

  @Test
  fun `mediaNotificationData extrapolates playing position and clamps to duration`() {
    val data = MediaNotificationData(
      tabId = "tab-1",
      title = "Song",
      artistOrHost = "youtube.com",
      artwork = null,
      isPlaying = true,
      durationMs = 60_000L,
      positionMs = 10_000L,
      playbackRate = 1.0f,
      positionUpdatedAtElapsedMs = 1_000L
    )
    assertEquals(15_000L, data.currentPositionMs(6_000L))
    assertEquals(60_000L, data.currentPositionMs(100_000L))
  }

  @Test
  fun `savior MediaKind and extractHostAndPath work accurately`() {
    assertEquals(MediaKind.VIDEO, MediaKind.fromRaw("video"))
    assertEquals(MediaKind.AUDIO, MediaKind.fromRaw("audio"))
    assertEquals(MediaKind.HLS, MediaKind.fromRaw("hls"))
    assertEquals(MediaKind.DASH, MediaKind.fromRaw("dash"))

    assertEquals("example.com/watch", BrowserViewModel.extractHostAndPath("https://www.example.com/watch/?v=123#top"))
    assertEquals("example.com/", BrowserViewModel.extractHostAndPath("https://example.com"))

    val protectedItem = MediaItem(
      url = "https://cdn.example.com/drm.mp4",
      kind = MediaKind.VIDEO,
      pageUrl = "https://example.com/watch",
      pageTitle = "DRM Video",
      isProtected = true,
      durationSec = 120.0
    )
    assertFalse(protectedItem.isDownloadAllowed)

    val normalItem = protectedItem.copy(isProtected = false)
    assertTrue(normalItem.isDownloadAllowed)
  }

  @Test
  fun `mediaDownloader sanitizes filename and resolves extension accurately`() {
    assertEquals("Video_Title_Test", MediaDownloader.sanitizeBaseTitle("Video:Title*Test?", "https://example.com/a.mp4"))
    assertEquals("webm", MediaDownloader.resolveExtension("https://cdn.example.com/clip.webm?token=1", "video/mp4", MediaKind.VIDEO))
    assertEquals("m4a", MediaDownloader.resolveExtension("https://cdn.example.com/stream", "audio/mp4", MediaKind.AUDIO))
    assertEquals("audio/mp4", MediaDownloader.resolveMimeType("m4a", null, MediaKind.AUDIO))

    val dlState = SaviorItemDownloadState(
      itemId = "1",
      fileName = "clip.mp4",
      audioOnly = false,
      status = SaviorDownloadStatus.DOWNLOADING,
      downloadedBytes = 25L,
      totalBytes = 100L
    )
    assertEquals(0.25f, dlState.progressFraction ?: 0f, 0.001f)
  }

  @Test
  fun `youTubeExtractorRepo initializes NewPipe and parses clen and videoId`() {
    YouTubeExtractorRepo.ensureInitialized()
    assertSame(AuraDownloader, NewPipe.getDownloader())
    assertEquals("vi", NewPipe.getPreferredLocalization().languageCode)
    assertEquals("VN", NewPipe.getPreferredLocalization().countryCode)

    assertEquals("dQw4w9WgXcQ", YouTubeExtractorRepo.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
    assertEquals("dQw4w9WgXcQ", YouTubeExtractorRepo.extractVideoId("https://youtu.be/dQw4w9WgXcQ?si=abc"))
    assertEquals(14582910L, YouTubeExtractorRepo.extractClenFromUrl("https://rr1.googlevideo.com/videoplayback?expire=1&clen=14582910&mime=video/mp4"))

    assertEquals(
      "Video bị giới hạn độ tuổi, không thể tải",
      YouTubeExtractorRepo.mapExceptionToVietnameseMessage(AgeRestrictedContentException("Age restricted"))
    )
    assertEquals(
      "Video bị chặn tại khu vực của bạn",
      YouTubeExtractorRepo.mapExceptionToVietnameseMessage(GeographicRestrictionException("Geo restricted"))
    )
    assertEquals(
      "Không lấy được thông tin video, thử lại sau",
      YouTubeExtractorRepo.mapExceptionToVietnameseMessage(ReCaptchaException("429", "https://youtube.com"))
    )
  }

  @Test
  fun `youTubeUrlDetection defaultOption and ytDownloader helpers work accurately`() {
    assertTrue(YouTubeExtractorRepo.isYouTubeVideoUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
    assertTrue(YouTubeExtractorRepo.isYouTubeVideoUrl("https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=10s"))
    assertTrue(YouTubeExtractorRepo.isYouTubeVideoUrl("https://music.youtube.com/watch?v=dQw4w9WgXcQ"))
    assertTrue(YouTubeExtractorRepo.isYouTubeVideoUrl("https://www.youtube.com/shorts/abcDEF12345"))
    assertTrue(YouTubeExtractorRepo.isYouTubeVideoUrl("https://youtu.be/dQw4w9WgXcQ?si=xyz"))
    assertFalse(YouTubeExtractorRepo.isYouTubeVideoUrl("https://www.youtube.com/"))
    assertFalse(YouTubeExtractorRepo.isYouTubeVideoUrl("https://www.youtube.com/results?search_query=test"))
    assertFalse(YouTubeExtractorRepo.isYouTubeVideoUrl("https://example.com/watch?v=dQw4w9WgXcQ"))

    val optAudio = YtOption("audio_128", "Audio 128kbps", MediaKind.AUDIO, null, null, 3_460_300L, false, "m4a")
    val opt360 = YtOption("v_360", "360p", MediaKind.VIDEO, null, null, 15_000_000L, false, "mp4")
    val opt480 = YtOption("v_480", "480p", MediaKind.VIDEO, null, null, 28_000_000L, true, "mp4")
    val opt720 = YtOption("v_720", "720p", MediaKind.VIDEO, null, null, 55_000_000L, true, "mp4")
    val opt1080 = YtOption("v_1080", "1080p", MediaKind.VIDEO, null, null, 124_780_544L, true, "webm")

    assertEquals("v_720", YouTubeExtractorRepo.pickDefaultOptionId(listOf(optAudio, opt360, opt480, opt720, opt1080)))
    assertEquals("v_480", YouTubeExtractorRepo.pickDefaultOptionId(listOf(optAudio, opt360, opt480, opt1080)))

    assertEquals("3.3 MB", formatYtOptionSizeMb(3_460_300L))
    assertEquals("119 MB", formatYtOptionSizeMb(124_780_544L))
    assertEquals("—", formatYtOptionSizeMb(null))

    assertEquals(
      "Bai_hat_hay [720p]",
      YtDownloader.buildBaseTitleWithLabel("Bai:hat*hay?", "https://youtu.be/dQw4w9WgXcQ", "720p")
    )
    assertEquals("m4a" to "audio/mp4", YtDownloader.resolveFinalExtAndMime(optAudio))
    assertEquals("mp4" to "video/mp4", YtDownloader.resolveFinalExtAndMime(opt720))
    assertEquals("webm" to "video/webm", YtDownloader.resolveFinalExtAndMime(opt1080))
  }

  @Test
  fun `shortcutStore normalizes urls manages up to 12 items and restores deleted item`() {
    assertEquals("https://vnexpress.net", ShortcutStore.normalizeAndValidateUrl("vnexpress.net"))
    assertEquals("http://example.com/test", ShortcutStore.normalizeAndValidateUrl("http://example.com/test"))
    assertEquals(null, ShortcutStore.normalizeAndValidateUrl(""))
    assertEquals(null, ShortcutStore.normalizeAndValidateUrl("not a url"))
    assertEquals(null, ShortcutStore.normalizeAndValidateUrl("invalid_host"))

    val context = ApplicationProvider.getApplicationContext<Context>()
    val store = ShortcutStore(context)
    assertEquals(8, store.shortcuts.value.size)

    val added = store.add("", "vnexpress.net")
    assertEquals("vnexpress.net", added?.title)
    assertEquals("https://vnexpress.net", added?.url)
    assertEquals(9, store.shortcuts.value.size)

    val edited = store.edit(added!!.id, "VNExpress", "https://vnexpress.net/tin-tuc")
    assertTrue(edited)
    assertEquals("VNExpress", store.shortcuts.value.last().title)

    val removed = store.remove(added.id)
    assertEquals("VNExpress", removed?.title)
    assertEquals(8, store.shortcuts.value.size)

    assertTrue(store.restore())
    assertEquals(9, store.shortcuts.value.size)
    assertEquals("VNExpress", store.shortcuts.value.last().title)
  }
}
