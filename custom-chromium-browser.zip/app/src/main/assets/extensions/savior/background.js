(function () {
  "use strict";

  // Đường dự phòng: nếu content script không gọi trực tiếp được sendNativeMessage
  // và chuyển qua browser.runtime.sendMessage, background script sẽ chuyển tiếp
  // về native app "browser" kèm thông tin URL của tab gửi.
  if (typeof browser !== "undefined" && browser.runtime && browser.runtime.onMessage) {
    browser.runtime.onMessage.addListener(function (message, sender) {
      try {
        if (!message || message.type !== "media") return;
        const tabUrl =
          (sender && sender.tab && sender.tab.url) ||
          (sender && sender.url) ||
          message.page ||
          "";
        const tabTitle =
          (sender && sender.tab && sender.tab.title) ||
          message.title ||
          "";
        const forwarded = Object.assign({}, message, {
          page: message.page || tabUrl,
          tabUrl: tabUrl,
          title: message.title || tabTitle
        });
        const p = browser.runtime.sendNativeMessage("browser", forwarded);
        if (p && typeof p.catch === "function") {
          p.catch(function () {});
        }
      } catch (_) {}
    });
  }
})();
