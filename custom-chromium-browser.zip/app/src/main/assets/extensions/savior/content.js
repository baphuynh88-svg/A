(function () {
  "use strict";

  const MEDIA_RE = /\.(mp4|webm|m4v|mov|mp3|m4a|aac|ogg|opus|wav|flac|m3u8|mpd)(\?|#|$)/i;
  const AUDIO_RE = /\.(mp3|m4a|aac|ogg|opus|wav|flac)(\?|#|$)/i;
  const HLS_RE = /\.m3u8(\?|#|$)/i;
  const DASH_RE = /\.mpd(\?|#|$)/i;

  const seen = new Set();
  let lastPageKey = getPageKey(location.href);

  function getPageKey(rawUrl) {
    try {
      const u = new URL(rawUrl);
      return (u.hostname || "").toLowerCase() + (u.pathname || "/");
    } catch (_) {
      return rawUrl || "";
    }
  }

  function checkNavigationReset() {
    const currentKey = getPageKey(location.href);
    if (currentKey && lastPageKey && currentKey !== lastPageKey) {
      seen.clear();
      lastPageKey = currentKey;
    } else if (currentKey && !lastPageKey) {
      lastPageKey = currentKey;
    }
  }

  function normalizeCandidateUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== "string") return null;
    const trimmed = rawUrl.trim();
    if (!trimmed) return null;
    if (/^(blob:|data:|javascript:|about:)/i.test(trimmed)) return null;
    try {
      const resolved = new URL(trimmed, location.href).href;
      if (/^(blob:|data:|javascript:|about:)/i.test(resolved)) return null;
      if (!/^https?:\/\//i.test(resolved)) return null;
      return resolved;
    } catch (_) {
      return null;
    }
  }

  function guessKindByExtension(url) {
    if (HLS_RE.test(url)) return "hls";
    if (DASH_RE.test(url)) return "dash";
    if (AUDIO_RE.test(url)) return "audio";
    return "video";
  }

  function sendMediaMessage(url, kind, isProtected, duration) {
    const normalizedUrl = normalizeCandidateUrl(url);
    if (!normalizedUrl) return;
    if (seen.has(normalizedUrl)) return;
    seen.add(normalizedUrl);

    const cleanDuration =
      typeof duration === "number" && isFinite(duration) && duration > 0
        ? duration
        : 0;

    const payload = {
      type: "media",
      url: normalizedUrl,
      kind: kind || "video",
      protected: Boolean(isProtected),
      duration: cleanDuration,
      page: location.href || "",
      title: document.title || ""
    };

    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.sendNativeMessage === "function"
      ) {
        const result = browser.runtime.sendNativeMessage("browser", payload);
        if (result && typeof result.catch === "function") {
          result.catch(function () {
            sendFallbackToBackground(payload);
          });
        }
      } else {
        sendFallbackToBackground(payload);
      }
    } catch (_) {
      sendFallbackToBackground(payload);
    }
  }

  function sendFallbackToBackground(payload) {
    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.sendMessage === "function"
      ) {
        const p = browser.runtime.sendMessage(payload);
        if (p && typeof p.catch === "function") {
          p.catch(function () {});
        }
      }
    } catch (_) {}
  }

  function scanDom() {
    try {
      const mediaElements = document.querySelectorAll("video, audio");
      for (let i = 0; i < mediaElements.length; i++) {
        const el = mediaElements[i];
        const tagName = (el.tagName || "").toUpperCase();
        const kind = tagName === "AUDIO" ? "audio" : "video";
        const isProtected = Boolean(el.mediaKeys);
        const duration =
          typeof el.duration === "number" && isFinite(el.duration) && el.duration > 0
            ? el.duration
            : 0;

        if (el.currentSrc) {
          sendMediaMessage(el.currentSrc, kind, isProtected, duration);
        }
        const directSrc = el.src || el.getAttribute("src");
        if (directSrc) {
          sendMediaMessage(directSrc, kind, isProtected, duration);
        }

        const sources = el.querySelectorAll("source");
        for (let j = 0; j < sources.length; j++) {
          const srcEl = sources[j];
          const sUrl = srcEl.src || srcEl.getAttribute("src");
          if (sUrl) {
            sendMediaMessage(sUrl, kind, isProtected, duration);
          }
        }
      }

      // Quét thêm thẻ <source> độc lập (nếu không nằm trong video/audio hoặc chưa quét)
      const standaloneSources = document.querySelectorAll("source");
      for (let k = 0; k < standaloneSources.length; k++) {
        const sourceEl = standaloneSources[k];
        const parent = sourceEl.parentElement;
        const parentTag = parent && parent.tagName ? parent.tagName.toUpperCase() : "";
        if (parentTag === "VIDEO" || parentTag === "AUDIO") {
          continue;
        }
        const srcUrl = sourceEl.src || sourceEl.getAttribute("src");
        if (srcUrl) {
          sendMediaMessage(srcUrl, "video", false, 0);
        }
      }
    } catch (_) {}
  }

  function scanPerf() {
    try {
      if (typeof performance === "undefined" || typeof performance.getEntriesByType !== "function") {
        return;
      }
      const entries = performance.getEntriesByType("resource");
      if (!entries || !entries.length) return;
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        const name = entry && entry.name ? entry.name : "";
        if (name && MEDIA_RE.test(name)) {
          const kind = guessKindByExtension(name);
          sendMediaMessage(name, kind, false, 0);
        }
      }
    } catch (_) {}
  }

  function scanAll() {
    checkNavigationReset();
    scanDom();
    scanPerf();
  }

  // Chạy ngay khi nạp content script
  scanAll();

  // Chạy định kỳ mỗi 2 giây
  setInterval(scanAll, 2000);

  // Theo dõi khi DOM thay đổi bằng MutationObserver
  let mutationTimer = null;
  try {
    const observer = new MutationObserver(function () {
      if (mutationTimer !== null) return;
      mutationTimer = setTimeout(function () {
        mutationTimer = null;
        scanAll();
      }, 250);
    });
    const root = document.documentElement || document.body;
    if (root) {
      observer.observe(root, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src"]
      });
    }
  } catch (_) {}
})();
