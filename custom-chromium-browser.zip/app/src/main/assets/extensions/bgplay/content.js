(function() {
  try {
    const pageWin = window.wrappedJSObject || window;
    const DocProto = (pageWin.Document && pageWin.Document.prototype) || Document.prototype;

    const getFalse = typeof exportFunction === "function"
      ? exportFunction(function() { return false; }, pageWin)
      : function() { return false; };

    const getTrue = typeof exportFunction === "function"
      ? exportFunction(function() { return true; }, pageWin)
      : function() { return true; };

    const getVisible = typeof exportFunction === "function"
      ? exportFunction(function() { return "visible"; }, pageWin)
      : function() { return "visible"; };

    Object.defineProperty(DocProto, "hidden", {
      get: getFalse,
      configurable: true,
      enumerable: true
    });

    Object.defineProperty(DocProto, "visibilityState", {
      get: getVisible,
      configurable: true,
      enumerable: true
    });

    Object.defineProperty(DocProto, "webkitHidden", {
      get: getFalse,
      configurable: true,
      enumerable: true
    });

    Object.defineProperty(DocProto, "webkitVisibilityState", {
      get: getVisible,
      configurable: true,
      enumerable: true
    });

    Object.defineProperty(DocProto, "hasFocus", {
      value: getTrue,
      configurable: true,
      writable: true
    });
  } catch (e) {}

  const blockedEvents = [
    "visibilitychange",
    "webkitvisibilitychange",
    "pagehide",
    "blur"
  ];

  const stopEvent = function(e) {
    try {
      e.stopImmediatePropagation();
    } catch (_) {}
  };

  for (let i = 0; i < blockedEvents.length; i++) {
    const evt = blockedEvents[i];
    window.addEventListener(evt, stopEvent, true);
    document.addEventListener(evt, stopEvent, true);
  }
})();
