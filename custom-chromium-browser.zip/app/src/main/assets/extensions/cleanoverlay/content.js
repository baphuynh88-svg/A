(function () {
  "use strict";

  // Danh sách host/đường dẫn loại trừ cố định
  const EXCLUDED_HOSTS = [
    "accounts.google.com"
  ];

  function isExcludedPage() {
    try {
      const host = (location.hostname || "").toLowerCase().replace(/^www\./, "");
      const pathname = (location.pathname || "").toLowerCase();
      if (!host) return false;
      // Google (tìm kiếm, AI Mode, Gemini...): trang tự cập nhật DOM liên tục, quét sẽ gây lag
      if (/^google\.[a-z.]+$/.test(host) || host.endsWith(".google.com") || host.endsWith(".google.com.vn")) {
        if (host !== "accounts.google.com") return true;
      }
      if (EXCLUDED_HOSTS.some((h) => host === h || host.endsWith("." + h))) {
        return true;
      }
      if ((host === "facebook.com" || host.endsWith(".facebook.com")) && pathname.startsWith("/login")) {
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  if (isExcludedPage()) {
    return;
  }

  const AD_KEYWORD_REGEX = /(^|[-_ ])(ad|ads|advert|popup|popunder|interstitial|sponsor|promo|overlay|lightbox)([-_ ]|$)/i;
  const SCROLL_LOCK_CLASSES = [
    "modal-open",
    "no-scroll",
    "noscroll",
    "overflow-hidden",
    "is-locked"
  ];

  // Giới hạn an toàn: tối đa 8 lần xoá mỗi 10 giây trên 1 trang
  const MAX_REMOVALS_PER_WINDOW = 8;
  const REMOVAL_WINDOW_MS = 10000;
  let removalTimestamps = [];
  let safetyLimitReached = false;

  // Theo dõi chữ ký phần tử đã xoá để phát hiện trường hợp framework dựng lại sau ~1 giây
  const removedSignatures = new Map();

  function canRemoveMore() {
    if (safetyLimitReached) return false;
    const now = Date.now();
    removalTimestamps = removalTimestamps.filter((t) => now - t < REMOVAL_WINDOW_MS);
    if (removalTimestamps.length >= MAX_REMOVALS_PER_WINDOW) {
      safetyLimitReached = true;
      stopObservers();
      return false;
    }
    return true;
  }

  function recordRemoval() {
    removalTimestamps.push(Date.now());
    notifyOverlayRemoved();
  }

  function notifyOverlayRemoved() {
    try {
      if (typeof browser !== "undefined" && browser.runtime && typeof browser.runtime.sendNativeMessage === "function") {
        const p = browser.runtime.sendNativeMessage("browser", {
          type: "overlay_removed",
          host: location.hostname || ""
        });
        if (p && typeof p.catch === "function") {
          p.catch(function () {});
        }
      }
    } catch (_) {
      // Bỏ qua nếu chưa kết nối Native Messaging
    }
  }

  function getElementSignature(el) {
    if (!el || !el.tagName) return "";
    const tag = el.tagName.toLowerCase();
    const id = el.id ? "#" + el.id : "";
    const cls = typeof el.className === "string" && el.className.trim()
      ? "." + el.className.trim().split(/\s+/).sort().join(".")
      : "";
    return tag + id + cls;
  }

  function isVisibleMedia(node) {
    try {
      const style = window.getComputedStyle(node);
      if (style.display === "none" || style.visibility === "hidden" || parseFloat(style.opacity) === 0) {
        return false;
      }
      const rect = node.getBoundingClientRect();
      return rect.width > 10 && rect.height > 10;
    } catch (_) {
      return false;
    }
  }

  function containsVisibleVideoOrCanvas(el) {
    if (el.tagName === "VIDEO" || el.tagName === "CANVAS") {
      return isVisibleMedia(el);
    }
    const mediaList = el.querySelectorAll("video, canvas");
    for (let i = 0; i < mediaList.length; i++) {
      if (isVisibleMedia(mediaList[i])) {
        return true;
      }
    }
    return false;
  }

  function containsLoginDialog(el) {
    const isDialog = el.getAttribute("role") === "dialog" || el.querySelector('[role="dialog"]') !== null;
    if (!isDialog) return false;
    const hasLoginInput = el.querySelector(
      'input[type="password"], input[type="email"], input[name*="user" i], input[name*="login" i], input[name*="email" i], form'
    );
    return hasLoginInput !== null;
  }

  function isProtectedElement(el, rect, vh) {
    if (!el || el.nodeType !== 1) return true;
    const tag = el.tagName;
    if (tag === "HTML" || tag === "BODY" || tag === "HEAD" || tag === "SCRIPT" || tag === "STYLE") {
      return true;
    }

    // Bỏ qua phần tử có thuộc tính data-aura-keep hoặc đã bị ẩn bởi tiện ích
    if (el.hasAttribute("data-aura-keep") || el.closest("[data-aura-keep]")) {
      return true;
    }
    if (el.hasAttribute("data-aura-hidden")) {
      return true;
    }

    // Không xoá nếu là fullscreenElement hoặc chứa nó
    const fsEl = document.fullscreenElement || document.webkitFullscreenElement;
    if (fsEl && (el === fsEl || el.contains(fsEl) || fsEl.contains(el))) {
      return true;
    }

    // Thanh điều hướng / header cao dưới 20% màn hình
    if (rect.height < vh * 0.2 || tag === "HEADER" || tag === "NAV") {
      return true;
    }

    // Chứa <input type="password">
    if (el.querySelector('input[type="password"]') !== null) {
      return true;
    }

    // Chứa <main>/<article> hoặc role="dialog" kèm form đăng nhập
    if (tag === "MAIN" || tag === "ARTICLE" || el.querySelector("main, article") !== null) {
      return true;
    }
    if (containsLoginDialog(el)) {
      return true;
    }

    // Chứa <video> hoặc <canvas> đang hiển thị
    if (containsVisibleVideoOrCanvas(el)) {
      return true;
    }

    return false;
  }

  function isCandidateOverlay(el, style, rect, vw, vh) {
    const pos = style.position;
    if (pos !== "fixed" && pos !== "absolute") {
      return false;
    }
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }

    // Phần diện tích nằm trong viewport
    const visWidth = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    const visHeight = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));

    // Phủ ít nhất 60% chiều rộng và 50% chiều cao viewport
    if (visWidth < vw * 0.6 || visHeight < vh * 0.5) {
      return false;
    }

    const zIndex = parseInt(style.zIndex, 10);
    if (!isNaN(zIndex) && zIndex >= 100) {
      return true;
    }

    // Hoặc nằm trực tiếp trong body với z-index auto nhưng phủ gần kín màn hình
    const isZAuto = style.zIndex === "auto" || isNaN(zIndex);
    const nearlyFullScreen = visWidth >= vw * 0.85 && visHeight >= vh * 0.85;
    if (el.parentElement === document.body && isZAuto && nearlyFullScreen) {
      return true;
    }

    return false;
  }

  function isDifferentHost(urlStr) {
    if (!urlStr) return false;
    try {
      const parsed = new URL(urlStr, location.href);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return false;
      }
      const currentHost = (location.hostname || "").toLowerCase().replace(/^www\./, "");
      const targetHost = (parsed.hostname || "").toLowerCase().replace(/^www\./, "");
      return Boolean(targetHost && currentHost && targetHost !== currentHost);
    } catch (_) {
      return false;
    }
  }

  // (a) Chứa <iframe> khác origin hoặc link target=_blank trỏ ra host khác
  function hasCrossOriginIframeOrExternalBlankLink(el) {
    if (el.tagName === "IFRAME") {
      const src = el.getAttribute("src") || el.src || "";
      if (isDifferentHost(src)) return true;
    }
    const iframes = el.querySelectorAll("iframe");
    for (let i = 0; i < iframes.length; i++) {
      const src = iframes[i].getAttribute("src") || iframes[i].src || "";
      if (isDifferentHost(src)) return true;
    }

    if (el.tagName === "A" && (el.getAttribute("target") || "").toLowerCase() === "_blank") {
      const href = el.getAttribute("href") || el.href || "";
      if (isDifferentHost(href)) return true;
    }
    const links = el.querySelectorAll('a[target="_blank" i]');
    for (let i = 0; i < links.length; i++) {
      const href = links[i].getAttribute("href") || links[i].href || "";
      if (isDifferentHost(href)) return true;
    }

    return false;
  }

  // (b) class/id khớp /(^|[-_ ])(ad|ads|advert|popup|popunder|interstitial|sponsor|promo|overlay|lightbox)([-_ ]|$)/i
  function hasAdClassOrId(el) {
    const idStr = typeof el.id === "string" ? el.id : "";
    const clsStr = typeof el.className === "string" ? el.className : "";
    return AD_KEYWORD_REGEX.test(idStr) || AD_KEYWORD_REGEX.test(clsStr);
  }

  function parseRgba(bgColor) {
    if (!bgColor || typeof bgColor !== "string") return null;
    const match = bgColor.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([0-9.]+))?\s*\)/i);
    if (!match) return null;
    return {
      r: parseInt(match[1], 10),
      g: parseInt(match[2], 10),
      b: parseInt(match[3], 10),
      a: match[4] !== undefined ? parseFloat(match[4]) : 1
    };
  }

  function isTransparentBackground(style) {
    const bg = (style.backgroundColor || "").toLowerCase();
    const bgImg = (style.backgroundImage || "").toLowerCase();
    if (bgImg && bgImg !== "none") return false;
    if (!bg || bg === "transparent") return true;
    const rgba = parseRgba(bg);
    return rgba !== null && rgba.a < 0.05;
  }

  function isDarkDimBackground(style) {
    const bg = (style.backgroundColor || "").toLowerCase();
    const rgba = parseRgba(bg);
    if (!rgba) return false;
    const isDark = rgba.r <= 70 && rgba.g <= 70 && rgba.b <= 70;
    return isDark && rgba.a >= 0.15 && rgba.a <= 0.98;
  }

  // (c) Lớp trong suốt (opacity < 0.05 hoặc background trong suốt) phủ kín màn hình mà là thẻ <a> hoặc có onclick
  function isTransparentClickjackOverlay(el, style, rect, vw, vh) {
    const visWidth = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    const visHeight = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
    if (visWidth < vw * 0.8 || visHeight < vh * 0.8) return false;

    const opacity = parseFloat(style.opacity);
    const isTransparent = (!isNaN(opacity) && opacity < 0.05) || isTransparentBackground(style);
    if (!isTransparent) return false;

    const isClickable =
      el.tagName === "A" ||
      el.hasAttribute("onclick") ||
      typeof el.onclick === "function" ||
      el.querySelector("a[href]") !== null;

    return isClickable;
  }

  // (d) Lớp nền tối (background rgba/ màu tối, ít con) phủ kín mà không có nội dung chữ nào đáng kể
  function isDarkEmptyBackdrop(el, style, rect, vw, vh) {
    const visWidth = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    const visHeight = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
    if (visWidth < vw * 0.8 || visHeight < vh * 0.8) return false;

    if (!isDarkDimBackground(style)) return false;
    if (el.children.length > 3) return false;

    const textLen = (el.innerText || "").trim().length;
    return textLen < 40;
  }

  function isRemovableAdOverlay(el, style, rect, vw, vh) {
    return (
      hasCrossOriginIframeOrExternalBlankLink(el) ||
      hasAdClassOrId(el) ||
      isTransparentClickjackOverlay(el, style, rect, vw, vh) ||
      isDarkEmptyBackdrop(el, style, rect, vw, vh)
    );
  }

  function hideElementPermanently(el) {
    try {
      el.style.setProperty("display", "none", "important");
      el.style.setProperty("visibility", "hidden", "important");
      el.style.setProperty("pointer-events", "none", "important");
      el.setAttribute("data-aura-hidden", "1");
    } catch (_) {}
  }

  function removeOrHideOverlay(el) {
    if (!canRemoveMore()) return false;
    const sig = getElementSignature(el);
    const now = Date.now();
    const prevRemovedAt = sig ? removedSignatures.get(sig) : undefined;

    // Nếu phần tử có cùng signature vừa bị xoá và bị framework dựng lại ngay -> ẩn bằng display:none !important
    if (prevRemovedAt !== undefined && now - prevRemovedAt < 3000) {
      hideElementPermanently(el);
      recordRemoval();
      return true;
    }

    if (sig) {
      removedSignatures.set(sig, now);
    }

    try {
      el.remove();
    } catch (_) {
      hideElementPermanently(el);
    }

    recordRemoval();

    // Kiểm tra lại sau 1 giây xem phần tử có bị framework dựng lại không
    if (sig) {
      setTimeout(function () {
        try {
          if (el.isConnected) {
            hideElementPermanently(el);
            return;
          }
          const vw = window.innerWidth || document.documentElement.clientWidth || 0;
          const vh = window.innerHeight || document.documentElement.clientHeight || 0;
          if (!vw || !vh) return;
          const candidates = document.body ? document.body.getElementsByTagName(el.tagName) : [];
          for (let i = 0; i < candidates.length; i++) {
            const c = candidates[i];
            if (getElementSignature(c) === sig) {
              const cStyle = window.getComputedStyle(c);
              const cRect = c.getBoundingClientRect();
              if (
                !isProtectedElement(c, cRect, vh) &&
                isCandidateOverlay(c, cStyle, cRect, vw, vh)
              ) {
                hideElementPermanently(c);
              }
            }
          }
        } catch (_) {}
      }, 1000);
    }

    return true;
  }

  function cleanupRemainingBackdropsAndRestoreScroll(vw, vh) {
    try {
      // Tìm tiếp các phần tử fixed phủ kín màn hình còn sót (nền tối / trong suốt, ít nội dung) và xoá luôn
      const allElements = document.body ? document.body.querySelectorAll("*") : [];
      for (let i = 0; i < allElements.length; i++) {
        if (!canRemoveMore()) break;
        const el = allElements[i];
        if (!el || !el.isConnected) continue;
        const style = window.getComputedStyle(el);
        if (style.position !== "fixed") continue;
        const rect = el.getBoundingClientRect();
        if (isProtectedElement(el, rect, vh)) continue;

        const visWidth = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
        const visHeight = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
        if (visWidth < vw * 0.8 || visHeight < vh * 0.8) continue;

        const opacity = parseFloat(style.opacity);
        const isTransparent = (!isNaN(opacity) && opacity < 0.05) || isTransparentBackground(style);
        const isDark = isDarkDimBackground(style);
        const lowContent = el.children.length <= 2 && (el.innerText || "").trim().length < 30;

        if ((isTransparent || isDark) && lowContent) {
          removeOrHideOverlay(el);
        }
      }
    } catch (_) {}

    // Trả lại cuộn trang cho html và body
    try {
      const rootTargets = [document.documentElement, document.body];
      for (let i = 0; i < rootTargets.length; i++) {
        const node = rootTargets[i];
        if (!node) continue;

        for (let c = 0; c < SCROLL_LOCK_CLASSES.length; c++) {
          node.classList.remove(SCROLL_LOCK_CLASSES[c]);
        }

        const comp = window.getComputedStyle(node);
        if (comp.overflow === "hidden" || comp.overflowY === "hidden") {
          node.style.setProperty("overflow", "auto", "important");
          node.style.setProperty("overflow-y", "auto", "important");
        }
        if (comp.position === "fixed") {
          node.style.setProperty("position", "static", "important");
        }
        if (node.style.height === "100%" || node.style.height === "100vh") {
          node.style.setProperty("height", "auto", "important");
        }
      }
    } catch (_) {}
  }

  function scanOverlays() {
    if (safetyLimitReached || !document.body) return;
    const vw = window.innerWidth || document.documentElement.clientWidth || 0;
    const vh = window.innerHeight || document.documentElement.clientHeight || 0;
    if (vw <= 0 || vh <= 0) return;

    let removedAny = false;
    const elements = document.body.querySelectorAll("*");

    for (let i = 0; i < elements.length; i++) {
      if (!canRemoveMore()) break;
      const el = elements[i];
      if (!el || !el.isConnected) continue;

      let style;
      let rect;
      try {
        style = window.getComputedStyle(el);
        if (style.position !== "fixed" && style.position !== "absolute") {
          continue;
        }
        rect = el.getBoundingClientRect();
      } catch (_) {
        continue;
      }

      if (!isCandidateOverlay(el, style, rect, vw, vh)) {
        continue;
      }

      if (isProtectedElement(el, rect, vh)) {
        continue;
      }

      if (isRemovableAdOverlay(el, style, rect, vw, vh)) {
        if (removeOrHideOverlay(el)) {
          removedAny = true;
        }
      }
    }

    if (removedAny) {
      cleanupRemainingBackdropsAndRestoreScroll(vw, vh);
    }
  }

  // Điều phối quét với requestAnimationFrame và giới hạn tối đa 1 lần mỗi 300ms
  const MIN_SCAN_INTERVAL_MS = 300;
  const MAX_SCAN_INTERVAL_MS = 5000;
  const pageStartTime = Date.now();
  let adaptiveIntervalMs = MIN_SCAN_INTERVAL_MS;
  let lastScanTime = 0;

  // Quét có đo thời gian: trang càng nặng thì càng quét thưa (tối đa ~7% thời gian CPU)
  function timedScan() {
    const t0 = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    scanOverlays();
    const t1 = (typeof performance !== "undefined" && performance.now) ? performance.now() : Date.now();
    const cost = t1 - t0;
    let next = Math.max(MIN_SCAN_INTERVAL_MS, Math.round(cost * 15));
    // Sau 20 giây đầu, popup quảng cáo hiếm khi xuất hiện thêm nên quét thưa hơn
    if (Date.now() - pageStartTime > 20000) next = Math.max(next, 1500);
    adaptiveIntervalMs = Math.min(MAX_SCAN_INTERVAL_MS, next);
  }
  let rafScheduled = false;
  let throttleTimer = null;
  let mutationObserver = null;
  let periodicTimer = null;

  function scheduleScan() {
    if (safetyLimitReached) return;
    if (rafScheduled || throttleTimer !== null) return;

    const now = Date.now();
    const elapsed = now - lastScanTime;

    if (elapsed >= adaptiveIntervalMs) {
      rafScheduled = true;
      requestAnimationFrame(function () {
        rafScheduled = false;
        lastScanTime = Date.now();
        timedScan();
      });
    } else {
      const waitMs = adaptiveIntervalMs - elapsed;
      throttleTimer = setTimeout(function () {
        throttleTimer = null;
        rafScheduled = true;
        requestAnimationFrame(function () {
          rafScheduled = false;
          lastScanTime = Date.now();
          timedScan();
        });
      }, waitMs);
    }
  }

  function stopObservers() {
    if (mutationObserver) {
      try {
        mutationObserver.disconnect();
      } catch (_) {}
      mutationObserver = null;
    }
    if (periodicTimer !== null) {
      clearInterval(periodicTimer);
      periodicTimer = null;
    }
    if (throttleTimer !== null) {
      clearTimeout(throttleTimer);
      throttleTimer = null;
    }
  }

  function initCleanOverlay() {
    if (isExcludedPage()) return;

    // Quét lần đầu ngay khi DOM sẵn sàng
    scheduleScan();

    // Dùng MutationObserver (childList + subtree + attributes style/class)
    const targetRoot = document.documentElement || document.body;
    if (targetRoot && typeof MutationObserver !== "undefined") {
      mutationObserver = new MutationObserver(function () {
        scheduleScan();
      });
      mutationObserver.observe(targetRoot, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["style", "class"]
      });
    }

    // Quét thêm mỗi 1.5 giây trong 20 giây đầu
    const startTime = Date.now();
    periodicTimer = setInterval(function () {
      if (safetyLimitReached || Date.now() - startTime > 20000) {
        if (periodicTimer !== null) {
          clearInterval(periodicTimer);
          periodicTimer = null;
        }
        return;
      }
      scheduleScan();
    }, 1500);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initCleanOverlay, { once: true });
  } else {
    initCleanOverlay();
  }
})();
