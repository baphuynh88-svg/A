// Chạy trong CONTEXT CỦA TRANG (được content.js chèn qua web_accessible_resources),
// để truy cập thẳng shadow DOM của Eruda mà không bị giới hạn Xray của content script.
// Thêm nút ⬇ vào góc trên-phải mỗi ảnh trong Eruda; bấm nút sẽ gửi CustomEvent
// "aura-devtools-save-image" cho content script, content script chuyển tiếp về app.
(function () {
  "use strict";
  try {
    if (window.__auraSaveImgInit) {
      return;
    }
    window.__auraSaveImgInit = true;

    var EVENT_NAME = "aura-devtools-save-image";

    function decorate(root) {
      try {
        // Không phụ thuộc tên class (Eruda đổi tiền tố tuỳ bản): lấy mọi <img> trong giao diện
        // Eruda và đặt nút vào phần tử cha của ảnh.
        var imgs = root.querySelectorAll("img");
        for (var i = 0; i < imgs.length; i++) {
          var holder = imgs[i].parentNode;
          if (!holder || holder.nodeType !== 1) {
            continue;
          }
          if (holder.querySelector(".aura-save-img-btn")) {
            continue;
          }
          var imgSrc = imgs[i].currentSrc || imgs[i].getAttribute("src") || "";
          if (!imgSrc) {
            continue;
          }
          var btn = document.createElement("button");
          btn.className = "aura-save-img-btn";
          btn.setAttribute("data-aura-keep", "1");
          btn.setAttribute("aria-label", "Lưu ảnh");
          btn.textContent = "⬇";
          btn.style.cssText =
            "position:absolute;top:4px;right:4px;width:34px;height:34px;" +
            "border-radius:50%;border:none;padding:0;margin:0;" +
            "background:rgba(0,0,0,0.75);color:#fff;font-size:18px;line-height:34px;" +
            "text-align:center;z-index:10;cursor:pointer;font-family:sans-serif;";
          holder.style.position = "relative";
          btn.addEventListener("click", function (ev) {
            try {
              ev.preventDefault();
              ev.stopPropagation();
              var parent = ev.currentTarget.parentNode;
              var target = parent ? parent.querySelector("img") : null;
              var raw = target ? (target.currentSrc || target.getAttribute("src") || "") : "";
              if (!raw) {
                return;
              }
              var abs = new URL(raw, document.baseURI).href;
              window.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: abs }));
            } catch (_) {}
          }, true);
          holder.appendChild(btn);
        }
      } catch (_) {}
    }

    function start() {
      var host = document.getElementById("eruda");
      var root = host && host.shadowRoot;
      if (!root) {
        return false;
      }
      var timer = null;
      new MutationObserver(function () {
        if (timer) {
          return;
        }
        timer = setTimeout(function () {
          timer = null;
          decorate(root);
        }, 120);
      }).observe(root, { childList: true, subtree: true });
      decorate(root);
      return true;
    }

    if (!start()) {
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        if (start() || tries > 50) {
          clearInterval(iv);
        }
      }, 200);
    }
  } catch (_) {}
})();
