(function () {
  "use strict";

  try {
    // Chỉ chạy ở top frame
    if (window !== window.top) {
      return;
    }

    // Bỏ qua các trang nội bộ about: và moz-extension:
    var protocol = (window.location && window.location.protocol)
      ? String(window.location.protocol).toLowerCase()
      : "";
    var href = (window.location && window.location.href)
      ? String(window.location.href).toLowerCase()
      : "";
    if (
      protocol === "about:" ||
      protocol === "moz-extension:" ||
      href.indexOf("about:") === 0 ||
      href.indexOf("moz-extension:") === 0
    ) {
      return;
    }

    var pageWin = window.wrappedJSObject || window;
    if (
      window.__auraDevtoolsInitialized ||
      (pageWin && pageWin.__auraDevtoolsInitialized) ||
      document.getElementById("eruda")
    ) {
      return;
    }
    window.__auraDevtoolsInitialized = true;
    try {
      if (pageWin) {
        pageWin.__auraDevtoolsInitialized = true;
      }
    } catch (_) {}

    function configureEruda(erudaInstance, isPageContext) {
      try {
        if (!erudaInstance || typeof erudaInstance.init !== "function") {
          return false;
        }

        // Khởi tạo Eruda với bộ công cụ mặc định
        erudaInstance.init();

        // Tính vị trí góc dưới bên trái để không đè nút Savior ở góc dưới bên phải
        var vh = window.innerHeight ||
          (document.documentElement && document.documentElement.clientHeight) ||
          600;
        var targetY = Math.max(10, vh - 60);
        try {
          var currentPos = typeof erudaInstance.position === "function"
            ? erudaInstance.position()
            : null;
          if (currentPos && typeof currentPos.y === "number" && currentPos.y > 0) {
            targetY = currentPos.y;
          }
        } catch (_) {}

        var bottomLeftPos = { x: 16, y: targetY };

        try {
          if (typeof erudaInstance.position === "function") {
            var posArg = (isPageContext && typeof cloneInto === "function")
              ? cloneInto(bottomLeftPos, window)
              : bottomLeftPos;
            erudaInstance.position(posArg);
          }
        } catch (_) {}

        try {
          var host = document.getElementById("eruda");
          if (host) {
            // Đánh dấu để CleanOverlay không nhận nhầm giao diện Eruda là quảng cáo phủ
            host.setAttribute("data-aura-keep", "1");
            var root = host.shadowRoot || host;
            var entryBtn = root.querySelector && root.querySelector(".eruda-entry-btn");
            if (entryBtn && entryBtn.style) {
              entryBtn.style.left = bottomLeftPos.x + "px";
              entryBtn.style.top = bottomLeftPos.y + "px";
            }
          }
        } catch (_) {}

        return Boolean(document.getElementById("eruda"));
      } catch (_) {
        return false;
      }
    }

    function initInIsolatedWorldFallback() {
      try {
        if (document.getElementById("eruda")) {
          return;
        }
        var isolatedEruda = typeof eruda !== "undefined" ? eruda : window.eruda;
        configureEruda(isolatedEruda, false);
      } catch (_) {}
    }

    // Trong GeckoView/Firefox, content script chạy trong isolated world nên nếu gọi eruda.init()
    // trực tiếp ở isolated world thì Eruda không hook được window.console / fetch / XHR của trang.
    // Do đó ưu tiên chèn eruda.js vào page context qua web_accessible_resources, rồi gọi init trên
    // window.wrappedJSObject.eruda; nếu trang chặn hoặc lỗi thì fallback về eruda trong isolated world.
    var scriptUrl = null;
    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.getURL === "function"
      ) {
        scriptUrl = browser.runtime.getURL("eruda.js");
      } else if (
        typeof chrome !== "undefined" &&
        chrome.runtime &&
        typeof chrome.runtime.getURL === "function"
      ) {
        scriptUrl = chrome.runtime.getURL("eruda.js");
      }
    } catch (_) {}

    var parent = document.head || document.documentElement || document.body;
    if (scriptUrl && parent) {
      var script = document.createElement("script");
      script.src = scriptUrl;
      script.async = false;
      script.setAttribute("data-aura-keep", "1");
      script.onload = function () {
        try {
          if (script.parentNode) {
            script.parentNode.removeChild(script);
          }
        } catch (_) {}

        try {
          var pageEruda = window.wrappedJSObject && window.wrappedJSObject.eruda;
          if (!configureEruda(pageEruda, true)) {
            initInIsolatedWorldFallback();
          }
        } catch (_) {
          initInIsolatedWorldFallback();
        }
      };
      script.onerror = function () {
        try {
          if (script.parentNode) {
            script.parentNode.removeChild(script);
          }
        } catch (_) {}
        initInIsolatedWorldFallback();
      };
      parent.appendChild(script);
    } else {
      initInIsolatedWorldFallback();
    }
  } catch (_) {}
})();
