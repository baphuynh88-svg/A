(function () {
  "use strict";

  try {
    // Chỉ chạy ở top frame
    if (window !== window.top) {
      return;
    }

    // Bỏ qua các trang nội bộ about: và moz-extension:
    var protocol = (window.location && window.location.protocol)
      ? String(window.location.protocol).toLowerCase()
      : "";
    var href = (window.location && window.location.href)
      ? String(window.location.href).toLowerCase()
      : "";
    if (
      protocol === "about:" ||
      protocol === "moz-extension:" ||
      href.indexOf("about:") === 0 ||
      href.indexOf("moz-extension:") === 0
    ) {
      return;
    }

    var pageWin = window.wrappedJSObject || window;
    if (
      window.__auraDevtoolsInitialized ||
      (pageWin && pageWin.__auraDevtoolsInitialized) ||
      document.getElementById("eruda")
    ) {
      return;
    }
    window.__auraDevtoolsInitialized = true;
    try {
      if (pageWin) {
        pageWin.__auraDevtoolsInitialized = true;
      }
    } catch (_) {}

    // ===== Nút "Lưu ảnh" ở góc trên-phải mỗi ảnh trong tab Resources / chi tiết ảnh của Eruda =====
    var saveBtnObserverStarted = false;

    function sendSaveImage(url) {
      try {
        if (
          typeof browser !== "undefined" &&
          browser.runtime &&
          typeof browser.runtime.sendNativeMessage === "function"
        ) {
          var p = browser.runtime.sendNativeMessage("browser", { type: "save_image", url: url });
          if (p && typeof p.catch === "function") {
            p.catch(function () {});
          }
        }
      } catch (_) {}
    }

    function setupSaveImageButtons() {
      if (saveBtnObserverStarted) {
        return;
      }
      try {
        var host = document.getElementById("eruda");
        if (!host) {
          return;
        }
        var root = host.openOrClosedShadowRoot || host.shadowRoot || host;
        saveBtnObserverStarted = true;

        function decorate() {
          try {
            var holders = root.querySelectorAll("li._image, ._img-container");
            for (var i = 0; i < holders.length; i++) {
              var holder = holders[i];
              if (holder.querySelector(".aura-save-img-btn")) {
                continue;
              }
              var img = holder.querySelector("img");
              if (!img) {
                continue;
              }
              var btn = document.createElement("button");
              btn.className = "aura-save-img-btn";
              btn.setAttribute("data-aura-keep", "1");
              btn.setAttribute("aria-label", "Lưu ảnh");
              btn.textContent = "\u2B07";
              btn.style.cssText =
                "position:absolute;top:4px;right:4px;width:30px;height:30px;" +
                "border-radius:50%;border:none;padding:0;margin:0;" +
                "background:rgba(0,0,0,0.7);color:#fff;font-size:16px;line-height:30px;" +
                "text-align:center;z-index:10;cursor:pointer;";
              if (holder.style) {
                holder.style.position = "relative";
              }
              btn.addEventListener("click", function (ev) {
                try {
                  ev.preventDefault();
                  ev.stopPropagation();
                  var target = ev.currentTarget.parentNode.querySelector("img");
                  var raw = target ? (target.currentSrc || target.getAttribute("src") || "") : "";
                  if (!raw) {
                    return;
                  }
                  var abs = new URL(raw, document.baseURI).href;
                  sendSaveImage(abs);
                } catch (_) {}
              }, true);
              holder.appendChild(btn);
            }
          } catch (_) {}
        }

        var timer = null;
        var observer = new MutationObserver(function () {
          if (timer) {
            return;
          }
          timer = setTimeout(function () {
            timer = null;
            decorate();
          }, 120);
        });
        observer.observe(root, { childList: true, subtree: true });
        decorate();
      } catch (_) {
        saveBtnObserverStarted = false;
      }
    }

    function configureEruda(erudaInstance, isPageContext) {
      try {
        if (!erudaInstance || typeof erudaInstance.init !== "function") {
          return false;
        }

        // Khởi tạo Eruda với bộ công cụ mặc định
        erudaInstance.init();

        // Tính vị trí góc dưới bên trái để không đè nút Savior ở góc dưới bên phải
        var vh = window.innerHeight ||
          (document.documentElement && document.documentElement.clientHeight) ||
          600;
        var targetY = Math.max(10, vh - 60);
        try {
          var currentPos = typeof erudaInstance.position === "function"
            ? erudaInstance.position()
            : null;
          if (currentPos && typeof currentPos.y === "number" && currentPos.y > 0) {
            targetY = currentPos.y;
          }
        } catch (_) {}

        var bottomLeftPos = { x: 16, y: targetY };

        try {
          if (typeof erudaInstance.position === "function") {
            var posArg = (isPageContext && typeof cloneInto === "function")
              ? cloneInto(bottomLeftPos, window)
              : bottomLeftPos;
            erudaInstance.position(posArg);
          }
        } catch (_) {}

        try {
          var host = document.getElementById("eruda");
          if (host) {
            // Đánh dấu để CleanOverlay không nhận nhầm giao diện Eruda là quảng cáo phủ
            host.setAttribute("data-aura-keep", "1");
            var root = host.shadowRoot || host;
            var entryBtn = root.querySelector && root.querySelector(".eruda-entry-btn");
            if (entryBtn && entryBtn.style) {
              entryBtn.style.left = bottomLeftPos.x + "px";
              entryBtn.style.top = bottomLeftPos.y + "px";
            }
          }
        } catch (_) {}

        setupSaveImageButtons();
        return Boolean(document.getElementById("eruda"));
      } catch (_) {
        return false;
      }
    }

    function initInIsolatedWorldFallback() {
      try {
        if (document.getElementById("eruda")) {
          return;
        }
        var isolatedEruda = typeof eruda !== "undefined" ? eruda : window.eruda;
        configureEruda(isolatedEruda, false);
      } catch (_) {}
    }

    // Trong GeckoView/Firefox, content script chạy trong isolated world nên nếu gọi eruda.init()
    // trực tiếp ở isolated world thì Eruda không hook được window.console / fetch / XHR của trang.
    // Do đó ưu tiên chèn eruda.js vào page context qua web_accessible_resources, rồi gọi init trên
    // window.wrappedJSObject.eruda; nếu trang chặn hoặc lỗi thì fallback về eruda trong isolated world.
    var scriptUrl = null;
    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.getURL === "function"
      ) {
        scriptUrl = browser.runtime.getURL("eruda.js");
      } else if (
        typeof chrome !== "undefined" &&
        chrome.runtime &&
        typeof chrome.runtime.getURL === "function"
      ) {
        scriptUrl = chrome.runtime.getURL("eruda.js");
      }
    } catch (_) {}

    var parent = document.head || document.documentElement || document.body;
    if (scriptUrl && parent) {
      var script = document.createElement("script");
      script.src = scriptUrl;
      script.async = false;
      script.setAttribute("data-aura-keep", "1");
      script.onload = function () {
        try {
          if (script.parentNode) {
            script.parentNode.removeChild(script);
          }
        } catch (_) {}

        try {
          var pageEruda = window.wrappedJSObject && window.wrappedJSObject.eruda;
          if (!configureEruda(pageEruda, true)) {
            initInIsolatedWorldFallback();
          }
        } catch (_) {
          initInIsolatedWorldFallback();
        }
      };
      script.onerror = function () {
        try {
          if (script.parentNode) {
            script.parentNode.removeChild(script);
          }
        } catch (_) {}
        initInIsolatedWorldFallback();
      };
      parent.appendChild(script);
    } else {
      initInIsolatedWorldFallback();
    }
  } catch (_) {}
})();
