(function () {
  "use strict";

  try {
    // Chỉ chạy ở top frame
    if (window !== window.top) {
      return;
    }

    function report() {
      try {
        var entries = performance.getEntriesByType("navigation");
        var nav = entries && entries[0];
        var status = nav ? nav.responseStatus : 0;
        // Chỉ báo mã lỗi (>= 400). Trang cache / chưa có mã thì status = 0 hoặc undefined.
        if (typeof status !== "number" || status < 400) {
          return;
        }
        if (
          typeof browser !== "undefined" &&
          browser.runtime &&
          typeof browser.runtime.sendNativeMessage === "function"
        ) {
          var p = browser.runtime.sendNativeMessage("browser", {
            type: "http_status",
            status: status,
            url: location.href
          });
          if (p && typeof p.catch === "function") {
            p.catch(function () {});
          }
        }
      } catch (_) {}
    }

    if (document.readyState === "complete") {
      setTimeout(report, 0);
    } else {
      window.addEventListener("load", function () {
        setTimeout(report, 0);
      }, { once: true });
    }
  } catch (_) {}
})();
