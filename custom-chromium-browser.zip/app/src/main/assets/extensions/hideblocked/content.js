(function () {
  "use strict";

  const CACHE_KEY = "aura_blocked_hosts_cache";
  const NATIVE_TIMEOUT_MS = 2000;
  const DEBOUNCE_MS = 200;

  let blockedHosts = [];
  let observer = null;
  let debounceTimer = null;

  function normalizeHost(raw) {
    if (!raw || typeof raw !== "string") return "";
    let h = raw.trim().toLowerCase();
    if (h.startsWith("http://")) h = h.slice(7);
    else if (h.startsWith("https://")) h = h.slice(8);
    h = h.split("/")[0].split("?")[0].split("#")[0].split(":")[0];
    return h.replace(/^www\./, "");
  }

  function isSearchResultsPage() {
    try {
      const pathname = location.pathname || "";
      if (pathname.startsWith("/search")) {
        return true;
      }
      const host = normalizeHost(location.hostname);
      const isDdgOrBrave =
        host === "duckduckgo.com" ||
        host.endsWith(".duckduckgo.com") ||
        host === "search.brave.com";
      if (isDdgOrBrave) {
        const params = new URLSearchParams(location.search || "");
        const q = params.get("q");
        return Boolean(q && q.trim().length > 0);
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  if (!isSearchResultsPage()) {
    return;
  }

  const currentSearchHost = normalizeHost(location.hostname);

  function isSameAsSearchEngineHost(host) {
    if (!host) return true;
    if (host === currentSearchHost || host.endsWith("." + currentSearchHost)) {
      return true;
    }
    if (
      (currentSearchHost === "google.com" || currentSearchHost === "google.com.vn" || currentSearchHost.endsWith(".google.com") || currentSearchHost.endsWith(".google.com.vn")) &&
      (host === "google.com" || host === "google.com.vn" || host.endsWith(".google.com") || host.endsWith(".google.com.vn") || host.endsWith(".gstatic.com") || host.endsWith(".googleapis.com"))
    ) {
      return true;
    }
    if (
      (currentSearchHost === "bing.com" || currentSearchHost.endsWith(".bing.com")) &&
      (host === "bing.com" || host.endsWith(".bing.com") || host === "microsoft.com" || host.endsWith(".microsoft.com"))
    ) {
      return true;
    }
    if (
      (currentSearchHost === "duckduckgo.com" || currentSearchHost.endsWith(".duckduckgo.com")) &&
      (host === "duckduckgo.com" || host.endsWith(".duckduckgo.com"))
    ) {
      return true;
    }
    if (
      currentSearchHost === "search.brave.com" &&
      (host === "search.brave.com" || host === "brave.com" || host.endsWith(".brave.com"))
    ) {
      return true;
    }
    return false;
  }

  function isBlocked(host) {
    const clean = normalizeHost(host);
    if (!clean || blockedHosts.length === 0) return false;
    for (let i = 0; i < blockedHosts.length; i++) {
      const h = blockedHosts[i];
      if (clean === h || clean.endsWith("." + h)) {
        return true;
      }
    }
    return false;
  }

  function realUrl(a) {
    if (!a || !a.href) return null;
    try {
      const parsed = new URL(a.href, location.href);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return null;
      }
      const linkHost = normalizeHost(parsed.hostname);
      const isGoogleOrBing =
        linkHost === "google.com" ||
        linkHost === "google.com.vn" ||
        linkHost.endsWith(".google.com") ||
        linkHost.endsWith(".google.com.vn") ||
        linkHost === "bing.com" ||
        linkHost.endsWith(".bing.com");

      if (isGoogleOrBing && (parsed.pathname === "/url" || parsed.pathname === "/aclk")) {
        const target = parsed.searchParams.get("q") || parsed.searchParams.get("url");
        if (target) {
          const targetUrl = new URL(target, location.href);
          if (targetUrl.protocol === "http:" || targetUrl.protocol === "https:") {
            const targetHost = normalizeHost(targetUrl.hostname);
            if (isSameAsSearchEngineHost(targetHost)) return null;
            return targetUrl.href;
          }
        }
      }

      if (isSameAsSearchEngineHost(linkHost)) {
        return null;
      }

      return parsed.href;
    } catch (_) {
      return null;
    }
  }

  function getExternalUnblockedHostCount(container) {
    const hosts = new Set();
    const links = container.querySelectorAll("a[href]");
    for (let i = 0; i < links.length; i++) {
      const resolved = realUrl(links[i]);
      if (!resolved) continue;
      try {
        const h = normalizeHost(new URL(resolved).hostname);
        if (h && !isSameAsSearchEngineHost(h) && !isBlocked(h)) {
          hosts.add(h);
          if (hosts.size >= 2) {
            return hosts.size;
          }
        }
      } catch (_) {}
    }
    return hosts.size;
  }

  function isForbiddenContainer(el) {
    if (!el || el.nodeType !== 1) return true;
    const tag = el.tagName.toUpperCase();
    if (tag === "BODY" || tag === "HTML" || tag === "MAIN") return true;
    if (el.id === "search") return true;
    return false;
  }

  function hideAll() {
    if (!blockedHosts || blockedHosts.length === 0 || !document.body) return;

    const anchors = document.querySelectorAll("a[href]");
    for (let i = 0; i < anchors.length; i++) {
      const a = anchors[i];
      if (!a || a.closest('[data-aura-hidden="1"]')) continue;

      const resolved = realUrl(a);
      if (!resolved) continue;

      let targetHost = "";
      try {
        targetHost = normalizeHost(new URL(resolved).hostname);
      } catch (_) {
        continue;
      }

      if (!targetHost || !isBlocked(targetHost)) continue;

      // Leo lên tối đa 10 cấp từ thẻ <a>
      let candidate = a;
      for (let step = 0; step < 10; step++) {
        const parent = candidate.parentElement;
        if (!parent || isForbiddenContainer(parent)) {
          break;
        }
        // Dừng khi phần tử cha chứa link tới >= 2 host ngoài khác nhau (không phải host trang tìm kiếm, không bị chặn)
        if (getExternalUnblockedHostCount(parent) >= 2) {
          break;
        }
        candidate = parent;
      }

      if (candidate && !isForbiddenContainer(candidate)) {
        candidate.style.display = "none";
        candidate.setAttribute("data-aura-hidden", "1");
      }
    }
  }

  function saveCache(hosts) {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.local) {
        browser.storage.local.set({ [CACHE_KEY]: hosts }).catch(function () {});
      }
    } catch (_) {}
  }

  function loadCache() {
    return new Promise(function (resolve) {
      try {
        if (typeof browser !== "undefined" && browser.storage && browser.storage.local) {
          browser.storage.local.get(CACHE_KEY).then(
            function (res) {
              const cached = res && Array.isArray(res[CACHE_KEY]) ? res[CACHE_KEY] : [];
              resolve(cached);
            },
            function () {
              resolve([]);
            }
          );
        } else {
          resolve([]);
        }
      } catch (_) {
        resolve([]);
      }
    });
  }

  function applyBlockedList(rawList) {
    if (!Array.isArray(rawList)) return;
    saveCache(rawList);
    blockedHosts = rawList
      .map(normalizeHost)
      .filter(function (h) {
        return h.length > 0;
      });
    if (blockedHosts.length > 0) {
      hideAll();
      startObserver();
    }
  }

  // Phương án dự phòng & cập nhật tức thì qua Port (browser.runtime.connectNative)
  function connectPortFallback(onInitialList) {
    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.connectNative === "function"
      ) {
        const port = browser.runtime.connectNative("browser");
        let receivedInitial = false;
        port.onMessage.addListener(function (msg) {
          const list =
            msg && Array.isArray(msg.hosts)
              ? msg.hosts
              : Array.isArray(msg)
              ? msg
              : null;
          if (list) {
            if (!receivedInitial && typeof onInitialList === "function") {
              receivedInitial = true;
              onInitialList(list);
            } else {
              applyBlockedList(list);
            }
          }
        });
        port.postMessage({ type: "get_blocked" });
      }
    } catch (_) {}
  }

  function fetchBlockedHostsWithTimeout() {
    return new Promise(function (resolve) {
      let settled = false;
      const timer = setTimeout(function () {
        if (!settled) {
          settled = true;
          loadCache().then(resolve);
        }
      }, NATIVE_TIMEOUT_MS);

      connectPortFallback(function (portHosts) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          saveCache(portHosts);
          resolve(portHosts);
        } else {
          applyBlockedList(portHosts);
        }
      });

      try {
        if (
          typeof browser !== "undefined" &&
          browser.runtime &&
          typeof browser.runtime.sendNativeMessage === "function"
        ) {
          browser.runtime
            .sendNativeMessage("browser", { type: "get_blocked" })
            .then(
              function (response) {
                if (settled) return;
                const rawList =
                  response && Array.isArray(response.hosts)
                    ? response.hosts
                    : Array.isArray(response)
                    ? response
                    : null;
                if (rawList) {
                  settled = true;
                  clearTimeout(timer);
                  saveCache(rawList);
                  resolve(rawList);
                }
              },
              function () {
                // Nếu sendNativeMessage lỗi, chờ port hoặc timeout đọc cache
              }
            );
        }
      } catch (_) {}
    });
  }

  function startObserver() {
    if (observer || !document.body || typeof MutationObserver === "undefined") return;
    observer = new MutationObserver(function () {
      if (debounceTimer !== null) {
        clearTimeout(debounceTimer);
      }
      debounceTimer = setTimeout(function () {
        debounceTimer = null;
        hideAll();
      }, DEBOUNCE_MS);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  fetchBlockedHostsWithTimeout().then(function (list) {
    if (!Array.isArray(list) || list.length === 0) {
      return;
    }
    blockedHosts = list
      .map(normalizeHost)
      .filter(function (h) {
        return h.length > 0;
      });
    if (blockedHosts.length === 0) {
      return;
    }

    hideAll();
    startObserver();
  });
})();
