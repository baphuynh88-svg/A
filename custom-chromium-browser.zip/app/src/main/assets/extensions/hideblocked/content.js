(function () {
  "use strict";

  // Hide Blocked v1.1
  //  - Trang tìm kiếm (Google/Bing/DuckDuckGo/Brave): ẩn kết quả của trang bị chặn.
  //  - Mọi trang khác: ẩn banner/ảnh/iframe có link dẫn tới tên miền bị chặn.

  const CACHE_KEY = "aura_blocked_hosts_cache";
  const NATIVE_TIMEOUT_MS = 2000;
  const DEBOUNCE_MS = 200;
  const MAX_HOSTS_IN_SELECTOR = 150;
  const HIDE_ATTR = "data-aura-hb";

  let blockedHosts = [];
  let blockedSet = new Set();
  let observer = null;
  let debounceTimer = null;
  let lastDebug = "";
  let lastDebugAt = 0;

  function normalizeHost(raw) {
    if (!raw || typeof raw !== "string") return "";
    let h = raw.trim().toLowerCase();
    if (h.startsWith("http://")) h = h.slice(7);
    else if (h.startsWith("https://")) h = h.slice(8);
    h = h.split("/")[0].split("?")[0].split("#")[0].split(":")[0];
    return h.replace(/^www\./, "");
  }

  function isSearchResultsPage() {
    try {
      const pathname = location.pathname || "";
      if (pathname.startsWith("/search")) {
        return true;
      }
      const host = normalizeHost(location.hostname);
      const isDdgOrBrave =
        host === "duckduckgo.com" ||
        host.endsWith(".duckduckgo.com") ||
        host === "search.brave.com";
      if (isDdgOrBrave) {
        const params = new URLSearchParams(location.search || "");
        const q = params.get("q");
        return Boolean(q && q.trim().length > 0);
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  const searchMode = isSearchResultsPage();
  const currentHost = normalizeHost(location.hostname);

  // ---------- So khớp host ----------

  function setBlockedList(rawList) {
    blockedHosts = rawList
      .map(normalizeHost)
      .filter(function (h) {
        return h.length > 0 && /^[a-z0-9.\-]+$/.test(h);
      });
    blockedSet = new Set(blockedHosts);
  }

  // Khớp chính host hoặc bất kỳ tên miền cha nào (a.b.com -> a.b.com, b.com, com)
  function isBlocked(host) {
    let h = normalizeHost(host);
    if (!h || blockedSet.size === 0) return false;
    while (h) {
      if (blockedSet.has(h)) return true;
      const i = h.indexOf(".");
      if (i < 0) return false;
      h = h.slice(i + 1);
    }
    return false;
  }

  function isSameAsSearchEngineHost(host) {
    if (!host) return true;
    const cur = currentHost;
    if (host === cur || host.endsWith("." + cur)) {
      return true;
    }
    if (
      (cur === "google.com" || cur === "google.com.vn" || cur.endsWith(".google.com") || cur.endsWith(".google.com.vn")) &&
      (host === "google.com" || host === "google.com.vn" || host.endsWith(".google.com") || host.endsWith(".google.com.vn") || host.endsWith(".gstatic.com") || host.endsWith(".googleapis.com"))
    ) {
      return true;
    }
    if (
      (cur === "bing.com" || cur.endsWith(".bing.com")) &&
      (host === "bing.com" || host.endsWith(".bing.com") || host === "microsoft.com" || host.endsWith(".microsoft.com"))
    ) {
      return true;
    }
    if (
      (cur === "duckduckgo.com" || cur.endsWith(".duckduckgo.com")) &&
      (host === "duckduckgo.com" || host.endsWith(".duckduckgo.com"))
    ) {
      return true;
    }
    if (
      cur === "search.brave.com" &&
      (host === "search.brave.com" || host === "brave.com" || host.endsWith(".brave.com"))
    ) {
      return true;
    }
    return false;
  }

  // Cùng trang đang mở (hoặc tên miền cha/con) thì không coi là "trang khác"
  function isSameSite(host) {
    if (!host) return true;
    const cur = currentHost;
    return host === cur || host.endsWith("." + cur) || cur.endsWith("." + host);
  }

  function isOwnHost(host) {
    return searchMode ? isSameAsSearchEngineHost(host) : isSameSite(host);
  }

  // ---------- Tìm URL thật của link ----------

  function realUrl(a) {
    if (!a || !a.href) return null;
    try {
      const parsed = new URL(a.href, location.href);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return null;
      }
      const linkHost = normalizeHost(parsed.hostname);
      const isGoogleOrBing =
        linkHost === "google.com" ||
        linkHost === "google.com.vn" ||
        linkHost.endsWith(".google.com") ||
        linkHost.endsWith(".google.com.vn") ||
        linkHost === "bing.com" ||
        linkHost.endsWith(".bing.com");

      if (isGoogleOrBing && (parsed.pathname === "/url" || parsed.pathname === "/aclk")) {
        const target = parsed.searchParams.get("q") || parsed.searchParams.get("url");
        if (target) {
          const targetUrl = new URL(target, location.href);
          if (targetUrl.protocol === "http:" || targetUrl.protocol === "https:") {
            const targetHost = normalizeHost(targetUrl.hostname);
            if (isOwnHost(targetHost)) return null;
            return targetUrl.href;
          }
        }
      }

      if (isOwnHost(linkHost)) {
        return null;
      }

      return parsed.href;
    } catch (_) {
      return null;
    }
  }

  // Link (kể cả link bọc qua trang chuyển hướng ?url=https://...) có dẫn tới host bị chặn không
  function targetBlocked(rawHref) {
    try {
      const u = new URL(rawHref, location.href);
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      const h = normalizeHost(u.hostname);
      if (h && !isOwnHost(h) && isBlocked(h)) return true;
      let blockedInParam = false;
      u.searchParams.forEach(function (v) {
        if (blockedInParam || !/^https?:\/\//i.test(v)) return;
        try {
          const h2 = normalizeHost(new URL(v).hostname);
          if (h2 && !isOwnHost(h2) && isBlocked(h2)) blockedInParam = true;
        } catch (_) {}
      });
      return blockedInParam;
    } catch (_) {
      return false;
    }
  }

  function isForbiddenContainer(el) {
    if (!el || el.nodeType !== 1) return true;
    const tag = el.tagName.toUpperCase();
    if (tag === "BODY" || tag === "HTML" || tag === "MAIN") return true;
    if (el.id === "search") return true;
    return false;
  }

  function hideEl(el) {
    try {
      el.style.setProperty("display", "none", "important");
      el.setAttribute("data-aura-hidden", "1");
      el.setAttribute(HIDE_ATTR, "1");
    } catch (_) {}
  }

  function restoreAll() {
    try {
      const hidden = document.querySelectorAll("[" + HIDE_ATTR + "]");
      for (let i = 0; i < hidden.length; i++) {
        hidden[i].style.removeProperty("display");
        hidden[i].removeAttribute("data-aura-hidden");
        hidden[i].removeAttribute(HIDE_ATTR);
      }
    } catch (_) {}
  }

  // ================= TRANG TÌM KIẾM =================

  // Gốc của một kết quả tìm kiếm (Google mobile/desktop, Bing, DuckDuckGo, Brave)
  const RESULT_ROOT_SELECTORS = [
    ".vt6azd", ".Ww4FFb", ".MjjYud", "div.g",
    "li.b_algo",
    "article[data-testid='result']", "li[data-layout='organic']",
    "#results .snippet", ".snippet[data-type='web']"
  ].join(",");

  // Phần tử hiển thị tên miền dưới tiêu đề kết quả (khi link không có href http rõ ràng)
  const RESULT_CITE_SELECTORS = "cite, .ob9lvb, .byrV5b, .tjvcx, .qLRx3b, .TbwUpd";

  function hostFromDisplayText(t) {
    if (!t) return "";
    const m = String(t).trim().toLowerCase().match(/(?:https?:\/\/)?((?:[a-z0-9-]+\.)+[a-z]{2,})/);
    return m ? m[1].replace(/^www\./, "") : "";
  }

  function collectExternalHosts(root) {
    const hosts = new Set();
    const links = root.querySelectorAll("a[href]");
    for (let i = 0; i < links.length; i++) {
      const resolved = realUrl(links[i]);
      if (!resolved) continue;
      try {
        const h = normalizeHost(new URL(resolved).hostname);
        if (h && !isOwnHost(h)) hosts.add(h);
      } catch (_) {}
    }
    const cites = root.querySelectorAll(RESULT_CITE_SELECTORS);
    for (let i = 0; i < cites.length; i++) {
      const h = hostFromDisplayText(cites[i].textContent);
      if (h && !isOwnHost(h)) hosts.add(h);
    }
    return hosts;
  }

  // Cách 1: theo từng "khối kết quả": ẩn cả khối nếu mọi host ngoài trong khối đều bị chặn
  function hideSearchRoots() {
    let roots;
    try {
      roots = document.querySelectorAll(RESULT_ROOT_SELECTORS);
    } catch (_) {
      return 0;
    }
    let n = 0;
    for (let i = 0; i < roots.length; i++) {
      const root = roots[i];
      if (root.hasAttribute(HIDE_ATTR) || root.closest("[" + HIDE_ATTR + "]")) continue;
      if (isForbiddenContainer(root) || root.querySelector("#rso, #search, main")) continue;
      const hosts = collectExternalHosts(root);
      if (hosts.size === 0) continue;
      let allBlocked = true;
      hosts.forEach(function (h) {
        if (!isBlocked(h)) allBlocked = false;
      });
      if (allBlocked) {
        hideEl(root);
        n++;
      }
    }
    return n;
  }

  function getExternalUnblockedHostCount(container) {
    const hosts = new Set();
    const links = container.querySelectorAll("a[href]");
    for (let i = 0; i < links.length; i++) {
      const resolved = realUrl(links[i]);
      if (!resolved) continue;
      try {
        const h = normalizeHost(new URL(resolved).hostname);
        if (h && !isOwnHost(h) && !isBlocked(h)) {
          hosts.add(h);
          if (hosts.size >= 2) {
            return hosts.size;
          }
        }
      } catch (_) {}
    }
    return hosts.size;
  }

  // Cách 2 (dự phòng): đi từ từng thẻ <a> dẫn tới host bị chặn, leo lên khối cha
  function hideSearchAnchors() {
    const anchors = document.querySelectorAll("a[href]");
    let n = 0;
    for (let i = 0; i < anchors.length; i++) {
      const a = anchors[i];
      if (!a || a.closest("[" + HIDE_ATTR + "]")) continue;

      const resolved = realUrl(a);
      if (!resolved) continue;

      let targetHost = "";
      try {
        targetHost = normalizeHost(new URL(resolved).hostname);
      } catch (_) {
        continue;
      }

      if (!targetHost || !isBlocked(targetHost)) continue;

      let candidate = a;
      for (let step = 0; step < 10; step++) {
        const parent = candidate.parentElement;
        if (!parent || isForbiddenContainer(parent)) {
          break;
        }
        if (getExternalUnblockedHostCount(parent) >= 2) {
          break;
        }
        candidate = parent;
      }

      if (candidate && !isForbiddenContainer(candidate)) {
        hideEl(candidate);
        n++;
      }
    }
    return n;
  }

  // ================= TRANG THƯỜNG (BANNER) =================

  const BANNER_FORBIDDEN_TAGS = {
    BODY: 1, HTML: 1, MAIN: 1, ARTICLE: 1, HEADER: 1, NAV: 1, FOOTER: 1, SECTION: 1, FORM: 1
  };

  function cssSafeHost(h) {
    return h.replace(/"/g, "");
  }

  function hasBackgroundImage(el) {
    try {
      const bg = window.getComputedStyle(el).backgroundImage;
      return Boolean(bg && bg !== "none");
    } catch (_) {
      return false;
    }
  }

  function mediaCount(el) {
    let n = el.querySelectorAll("img, picture, video, canvas, iframe, svg").length;
    const tag = el.tagName;
    if (tag === "IMG" || tag === "PICTURE" || tag === "VIDEO" || tag === "CANVAS" || tag === "IFRAME" || tag === "svg") n++;
    return n;
  }

  function isBannerLike(a) {
    return mediaCount(a) > 0 || hasBackgroundImage(a);
  }

  function countBlockedAnchors(el) {
    const anchors = el.querySelectorAll("a[href]");
    let blocked = 0;
    for (let i = 0; i < anchors.length; i++) {
      if (targetBlocked(anchors[i].getAttribute("href") || "")) blocked++;
    }
    return { total: anchors.length, blocked: blocked };
  }

  // Leo lên tối đa 3 cấp để ẩn luôn khung chứa banner (kèm nút ×), nhưng không ẩn lẫn nội dung khác
  function pickBannerRoot(el) {
    const vh = window.innerHeight || document.documentElement.clientHeight || 800;
    let c = el;
    const baseMedia = mediaCount(el);
    for (let step = 0; step < 3; step++) {
      const p = c.parentElement;
      if (!p || BANNER_FORBIDDEN_TAGS[p.tagName]) break;
      if (p.hasAttribute("data-aura-keep") || p.closest("[data-aura-keep]")) break;
      const counts = countBlockedAnchors(p);
      if (counts.total !== counts.blocked) break;
      if (mediaCount(p) !== baseMedia) break;
      const text = (p.innerText || "").trim();
      if (text.length > 20) break;
      let h = 0;
      try {
        h = p.getBoundingClientRect().height;
      } catch (_) {}
      if (h > vh * 0.4) break;
      c = p;
    }
    return c;
  }

  function hideBanners() {
    if (blockedHosts.length === 0 || !document.body) return 0;
    const hosts = blockedHosts.slice(0, MAX_HOSTS_IN_SELECTOR);
    const parts = [];
    for (let i = 0; i < hosts.length; i++) {
      const h = cssSafeHost(hosts[i]);
      parts.push('a[href*="' + h + '"]');
      parts.push('iframe[src*="' + h + '"]');
    }
    let nodes;
    try {
      nodes = document.querySelectorAll(parts.join(","));
    } catch (_) {
      return 0;
    }
    let n = 0;
    for (let i = 0; i < nodes.length; i++) {
      const el = nodes[i];
      if (el.closest("[" + HIDE_ATTR + "]")) continue;
      if (el.hasAttribute("data-aura-keep") || el.closest("[data-aura-keep]")) continue;
      if (el.tagName === "IFRAME") {
        if (!targetBlocked(el.getAttribute("src") || "")) continue;
      } else {
        if (!targetBlocked(el.getAttribute("href") || "")) continue;
        // Chỉ ẩn banner/ảnh; link chữ bình thường trong bài viết được giữ nguyên
        if (!isBannerLike(el)) continue;
      }
      hideEl(pickBannerRoot(el));
      n++;
    }
    return n;
  }

  // ================= CHẠY & THEO DÕI =================

  function reportDebug(stats) {
    try {
      const key = JSON.stringify(stats);
      const now = Date.now();
      if (key === lastDebug || now - lastDebugAt < 2000) return;
      lastDebug = key;
      lastDebugAt = now;
      if (typeof browser !== "undefined" && browser.runtime && typeof browser.runtime.sendNativeMessage === "function") {
        const p = browser.runtime.sendNativeMessage("browser", {
          type: "hide_debug",
          host: currentHost,
          mode: stats.mode,
          blocked: stats.blocked,
          anchors: stats.anchors,
          roots: stats.roots,
          hidden: stats.hidden
        });
        if (p && typeof p.catch === "function") p.catch(function () {});
      }
    } catch (_) {}
  }

  function hideAll() {
    if (!blockedHosts || blockedHosts.length === 0 || !document.body) return;
    try {
      if (searchMode) {
        hideSearchRoots();
        hideSearchAnchors();
      } else {
        hideBanners();
      }
      let hiddenTotal = 0;
      let roots = 0;
      try {
        hiddenTotal = document.querySelectorAll("[" + HIDE_ATTR + "]").length;
        roots = searchMode ? document.querySelectorAll(RESULT_ROOT_SELECTORS).length : 0;
      } catch (_) {}
      reportDebug({
        mode: searchMode ? "search" : "page",
        blocked: blockedHosts.length,
        anchors: document.querySelectorAll("a[href]").length,
        roots: roots,
        hidden: hiddenTotal
      });
    } catch (_) {}
  }

  function saveCache(hosts) {
    try {
      if (typeof browser !== "undefined" && browser.storage && browser.storage.local) {
        browser.storage.local.set({ [CACHE_KEY]: hosts }).catch(function () {});
      }
    } catch (_) {}
  }

  function loadCache() {
    return new Promise(function (resolve) {
      try {
        if (typeof browser !== "undefined" && browser.storage && browser.storage.local) {
          browser.storage.local.get(CACHE_KEY).then(
            function (res) {
              const cached = res && Array.isArray(res[CACHE_KEY]) ? res[CACHE_KEY] : [];
              resolve(cached);
            },
            function () {
              resolve([]);
            }
          );
        } else {
          resolve([]);
        }
      } catch (_) {
        resolve([]);
      }
    });
  }

  // Áp danh sách mới (kể cả khi bỏ chặn: khôi phục phần đã ẩn rồi ẩn lại theo danh sách mới)
  function applyBlockedList(rawList, fromCache) {
    if (!Array.isArray(rawList)) return;
    if (!fromCache) saveCache(rawList);
    const before = blockedHosts.join("|");
    setBlockedList(rawList);
    if (before !== blockedHosts.join("|")) {
      restoreAll();
    }
    if (blockedHosts.length > 0) {
      hideAll();
      startObserver();
    }
  }

  // Phương án dự phòng & cập nhật tức thì qua Port (browser.runtime.connectNative)
  function connectPortFallback(onInitialList) {
    try {
      if (
        typeof browser !== "undefined" &&
        browser.runtime &&
        typeof browser.runtime.connectNative === "function"
      ) {
        const port = browser.runtime.connectNative("browser");
        let receivedInitial = false;
        port.onMessage.addListener(function (msg) {
          const list =
            msg && Array.isArray(msg.hosts)
              ? msg.hosts
              : Array.isArray(msg)
              ? msg
              : null;
          if (list) {
            if (!receivedInitial && typeof onInitialList === "function") {
              receivedInitial = true;
              onInitialList(list);
            } else {
              applyBlockedList(list, false);
            }
          }
        });
        port.postMessage({ type: "get_blocked" });
      }
    } catch (_) {}
  }

  function fetchBlockedHostsWithTimeout() {
    return new Promise(function (resolve) {
      let settled = false;
      const timer = setTimeout(function () {
        if (!settled) {
          settled = true;
          resolve(null);
        }
      }, NATIVE_TIMEOUT_MS);

      connectPortFallback(function (portHosts) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(portHosts);
        } else {
          applyBlockedList(portHosts, false);
        }
      });

      try {
        if (
          typeof browser !== "undefined" &&
          browser.runtime &&
          typeof browser.runtime.sendNativeMessage === "function"
        ) {
          browser.runtime
            .sendNativeMessage("browser", { type: "get_blocked" })
            .then(
              function (response) {
                if (settled) return;
                const rawList =
                  response && Array.isArray(response.hosts)
                    ? response.hosts
                    : Array.isArray(response)
                    ? response
                    : null;
                if (rawList) {
                  settled = true;
                  clearTimeout(timer);
                  resolve(rawList);
                }
              },
              function () {
                // Nếu sendNativeMessage lỗi, chờ port hoặc timeout
              }
            );
        }
      } catch (_) {}
    });
  }

  function startObserver() {
    if (observer || !document.body || typeof MutationObserver === "undefined") return;
    observer = new MutationObserver(function () {
      if (debounceTimer !== null) {
        clearTimeout(debounceTimer);
      }
      debounceTimer = setTimeout(function () {
        debounceTimer = null;
        hideAll();
      }, DEBOUNCE_MS);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // 1) Dùng ngay bản lưu cache để ẩn sớm, không phải chờ native
  loadCache().then(function (cached) {
    if (Array.isArray(cached) && cached.length > 0 && blockedHosts.length === 0) {
      applyBlockedList(cached, true);
    }
  });

  // 2) Lấy danh sách mới nhất từ app
  fetchBlockedHostsWithTimeout().then(function (list) {
    if (Array.isArray(list)) {
      applyBlockedList(list, false);
    }
  });
})();
