package com.example.util

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.PowerManager
import java.util.concurrent.Executors

/**
 * Thu thập dữ liệu để xác định vì sao tiến trình nội dung (GeckoView) hoặc app bị kill:
 * thiếu RAM hay nguyên nhân khác (tiết kiệm pin, quản lý nền của hãng, crash...).
 */
object SystemDiagnostics {
    private const val TAG = "SysDiag"
    private const val PREFS = "aura_diag_prefs"
    private const val KEY_LAST_EXIT_TS = "last_exit_ts"

    @Volatile private var appContext: Context? = null
    @Volatile private var lastTrimLevel = -1
    @Volatile private var lastTrimAt = 0L
    @Volatile private var backgroundSince = 0L
    @Volatile private var pickerOpenedAt = 0L
    @Volatile private var exitsLogged = false

    // Đo RAM (PSS...) hơi tốn thời gian nên chạy nền, không làm chậm luồng giao diện
    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread(r, "aura-sysdiag").apply { isDaemon = true }
    }

    fun init(context: Context) {
        if (appContext != null) return
        val app = context.applicationContext
        appContext = app
        AppLogger.init(app)
        app.registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onConfigurationChanged(newConfig: Configuration) {}

            override fun onLowMemory() {
                lastTrimLevel = 80
                lastTrimAt = System.currentTimeMillis()
                worker.execute {
                    AppLogger.flag("RAM", TAG, "onLowMemory: hệ thống báo thiếu RAM | ${memorySnapshot()}")
                }
            }

            override fun onTrimMemory(level: Int) {
                lastTrimLevel = level
                lastTrimAt = System.currentTimeMillis()
                // 10 = RUNNING_LOW, 15 = RUNNING_CRITICAL (đang chạy nền trước mà RAM yếu)
                // 40/60/80 = tiến trình nằm trong danh sách có thể bị kill sớm
                if (level == 10 || level == 15 || level >= 40) {
                    worker.execute {
                        AppLogger.flag("RAM", TAG, "onTrimMemory ${trimName(level)} | ${memorySnapshot()}")
                    }
                } else {
                    AppLogger.d(TAG, "onTrimMemory ${trimName(level)}")
                }
            }
        })
    }

    // ---------- Vòng đời app ----------

    fun onAppStarted() {
        backgroundSince = 0L
    }

    fun onAppStopped(isFinishing: Boolean, isChangingConfig: Boolean) {
        if (!isChangingConfig) backgroundSince = System.currentTimeMillis()
        worker.execute {
            AppLogger.d(
                "Lifecycle",
                "onStop isFinishing=$isFinishing changingConfig=$isChangingConfig | ${memorySnapshot()}"
            )
        }
    }

    // ---------- Bộ chọn file ----------

    fun onPickerOpened(info: String) {
        pickerOpenedAt = System.currentTimeMillis()
        worker.execute {
            AppLogger.flag("PICKER", TAG, "mở bộ chọn file ($info) | RAM trước khi rời app: ${memorySnapshot()}")
        }
    }

    fun onPickerResult(resultCode: Int, hadCallback: Boolean) {
        val now = System.currentTimeMillis()
        val secs = if (pickerOpenedAt > 0) (now - pickerOpenedAt) / 1000 else -1
        pickerOpenedAt = 0L
        val lost = if (hadCallback) "" else " => KẾT QUẢ MẤT: không còn nơi nhận (Activity/tiến trình đã bị tạo lại)"
        AppLogger.flag(
            "PICKER",
            TAG,
            "bộ chọn file trả về resultCode=$resultCode sau ${secs}s | còn callback=$hadCallback$lost"
        )
    }

    // ---------- Tiến trình nội dung bị kill / crash ----------

    fun logContentLoss(kind: String, tabId: String) {
        val now = System.currentTimeMillis()
        // Chụp trạng thái ngay lúc nhận thông báo; phần đo nặng làm ở luồng nền
        val bg = if (backgroundSince > 0) "có, ${(now - backgroundSince) / 1000}s" else "không (đang ở nền trước)"
        val picker = if (pickerOpenedAt > 0) "CÓ, mở cách đây ${(now - pickerOpenedAt) / 1000}s" else "không"
        val trimLevel = lastTrimLevel
        val trimAt = lastTrimAt
        worker.execute {
            val (cause, why) = classifyLoss(trimLevel, trimAt, now)
            AppLogger.flag(kind, TAG, "tab=$tabId | nguyên nhân=$cause ($why) | app đang ở nền=$bg | đang chọn file=$picker")
            AppLogger.flag(kind, TAG, "RAM (đo lúc nhận thông báo, có thể đã tăng lại sau khi bị kill): ${memorySnapshot()}")
            AppLogger.flag(kind, TAG, "Thiết bị: ${deviceState()}")
        }
    }

    private fun classifyLoss(trimLevel: Int, trimAt: Long, now: Long): Pair<String, String> {
        val ctx = appContext ?: return Pair("KHONG_RO", "chưa khởi tạo")
        val mi = memoryInfo(ctx)
        val recentTrim = (trimLevel in 10..15 || trimLevel >= 40) && now - trimAt < 120_000
        return when {
            mi.lowMemory -> Pair("THIEU_RAM", "hệ thống đang báo lowMemory=true")
            recentTrim -> Pair(
                "THIEU_RAM",
                "onTrimMemory=${trimName(trimLevel)} cách đây ${(now - trimAt) / 1000}s"
            )
            mi.availMem < mi.threshold * 2 -> Pair(
                "SAT_NGUONG_RAM",
                "RAM trống ${mb(mi.availMem)}MB chưa tới 2 lần ngưỡng ${mb(mi.threshold)}MB"
            )
            else -> Pair(
                "KHAC",
                "RAM còn dư (${mb(mi.availMem)}MB, ngưỡng ${mb(mi.threshold)}MB) và không có tín hiệu thiếu RAM; " +
                    "nghi do quản lý nền/tiết kiệm pin của hãng, hoặc lỗi riêng của tiến trình nội dung"
            )
        }
    }

    // ---------- Lý do tiến trình thoát ở lần chạy trước (Android 11+) ----------

    fun logPreviousExits() {
        if (exitsLogged) return
        exitsLogged = true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val ctx = appContext ?: return
        worker.execute { readPreviousExits(ctx) }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.R)
    private fun readPreviousExits(ctx: Context) {
        try {
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val lastLogged = prefs.getLong(KEY_LAST_EXIT_TS, 0L)
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val exits = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 8)
            val now = System.currentTimeMillis()
            var newest = lastLogged
            // Từ cũ đến mới để log theo thứ tự thời gian
            for (e in exits.sortedBy { it.timestamp }) {
                if (e.timestamp <= lastLogged) continue
                if (now - e.timestamp > 24L * 60 * 60 * 1000) continue
                if (e.timestamp > newest) newest = e.timestamp
                val (flag, label) = exitReasonLabel(e.reason)
                AppLogger.flag(
                    flag,
                    TAG,
                    "tiến trình đã thoát: ${e.processName} | lý do=$label | mô tả=${e.description ?: "-"} | " +
                        "độ ưu tiên lúc đó=${importanceName(e.importance)} | cách đây ${(now - e.timestamp) / 60000} phút | " +
                        "PSS=${e.pss / 1024}MB RSS=${e.rss / 1024}MB"
                )
            }
            if (newest > lastLogged) {
                prefs.edit().putLong(KEY_LAST_EXIT_TS, newest).apply()
            }
        } catch (_: Exception) {
            // Một số ROM không cho đọc: bỏ qua
        }
    }

    private fun exitReasonLabel(reason: Int): Pair<String, String> {
        return when (reason) {
            1 -> Pair("EXIT", "EXIT_SELF (app tự thoát)")
            2 -> Pair("KILL", "SIGNALED (bị gửi tín hiệu kill: LMKD/hệ thống/trình quản lý của hãng)")
            3 -> Pair("RAM", "LOW_MEMORY (THIẾU RAM, bị hệ thống kill)")
            4 -> Pair("CRASH", "CRASH (lỗi Java)")
            5 -> Pair("CRASH", "CRASH_NATIVE (lỗi mã native/Gecko)")
            6 -> Pair("CRASH", "ANR (treo, không phản hồi)")
            7 -> Pair("EXIT", "INITIALIZATION_FAILURE")
            8 -> Pair("KILL", "PERMISSION_CHANGE (đổi quyền)")
            9 -> Pair("KILL", "EXCESSIVE_RESOURCE_USAGE (dùng tài nguyên quá mức)")
            10 -> Pair("EXIT", "USER_REQUESTED (người dùng tắt)")
            11 -> Pair("EXIT", "USER_STOPPED (người dùng buộc dừng)")
            12 -> Pair("KILL", "DEPENDENCY_DIED (tiến trình phụ thuộc chết)")
            13 -> Pair("KILL", "OTHER (lý do khác; thường là trình quản lý nền của hãng)")
            14 -> Pair("KILL", "FREEZER (bị đóng băng)")
            15 -> Pair("EXIT", "PACKAGE_STATE_CHANGE")
            16 -> Pair("EXIT", "PACKAGE_UPDATED")
            else -> Pair("EXIT", "không rõ ($reason)")
        }
    }

    private fun importanceName(importance: Int): String {
        return when (importance) {
            100 -> "foreground"
            125 -> "foreground-service"
            200 -> "visible"
            230 -> "perceptible"
            300 -> "service"
            400 -> "cached"
            1000 -> "gone"
            else -> importance.toString()
        }
    }

    // ---------- Đo RAM / trạng thái máy ----------

    fun memorySnapshot(): String {
        val ctx = appContext ?: return "(chưa khởi tạo)"
        val sb = StringBuilder()
        try {
            val mi = memoryInfo(ctx)
            sb.append("RAM trống=${mb(mi.availMem)}MB/${mb(mi.totalMem)}MB ngưỡng=${mb(mi.threshold)}MB lowMemory=${mi.lowMemory}")
        } catch (_: Exception) {
            sb.append("RAM=?")
        }
        try {
            val rt = Runtime.getRuntime()
            sb.append(" heap=${mb(rt.totalMemory() - rt.freeMemory())}/${mb(rt.maxMemory())}MB")
        } catch (_: Exception) {
        }
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val procs = am.runningAppProcesses
            if (procs != null && procs.isNotEmpty()) {
                val infos = am.getProcessMemoryInfo(procs.map { it.pid }.toIntArray())
                sb.append(" PSS:")
                for (i in procs.indices) {
                    val name = procs[i].processName.substringAfter(':', "chính")
                    sb.append(" $name=${infos[i].totalPss / 1024}MB")
                }
            }
        } catch (_: Exception) {
        }
        return sb.toString()
    }

    private fun deviceState(): String {
        val ctx = appContext ?: return "?"
        val parts = ArrayList<String>()
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            parts.add("tiếtKiệmPin=${pm.isPowerSaveMode}")
            parts.add("bỏQuaTốiƯuPin=${pm.isIgnoringBatteryOptimizations(ctx.packageName)}")
        } catch (_: Exception) {
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                parts.add("hạnChếNền=${am.isBackgroundRestricted}")
                val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                parts.add("standby=${bucketName(usm.appStandbyBucket)}")
            } catch (_: Exception) {
            }
        }
        parts.add("máy=${Build.MANUFACTURER} ${Build.MODEL} Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        return parts.joinToString(" | ")
    }

    private fun bucketName(bucket: Int): String {
        return when (bucket) {
            10 -> "ACTIVE"
            20 -> "WORKING_SET"
            30 -> "FREQUENT"
            40 -> "RARE"
            45 -> "RESTRICTED"
            50 -> "NEVER"
            else -> bucket.toString()
        }
    }

    private fun memoryInfo(ctx: Context): ActivityManager.MemoryInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi
    }

    private fun mb(bytes: Long): Long = bytes / (1024L * 1024L)

    private fun trimName(level: Int): String {
        return when (level) {
            5 -> "RUNNING_MODERATE(5)"
            10 -> "RUNNING_LOW(10)"
            15 -> "RUNNING_CRITICAL(15)"
            20 -> "UI_HIDDEN(20)"
            40 -> "BACKGROUND(40)"
            60 -> "MODERATE(60)"
            80 -> "COMPLETE(80)"
            else -> level.toString()
        }
    }
}
