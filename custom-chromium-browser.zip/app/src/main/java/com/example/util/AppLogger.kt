package com.example.util

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.Executors

/**
 * Nhật ký chẩn đoán trong app.
 *  - d(): log thường, chỉ giữ trong bộ nhớ (tối đa MAX_LOGS dòng gần nhất).
 *  - flag(): log có CỜ (KILL, CRASH, RAM, PICKER, EXIT...) — ngoài bộ nhớ còn được lưu xuống file
 *    để vẫn đọc được sau khi tiến trình app bị hệ thống kill rồi mở lại.
 */
object AppLogger {
    private const val TAG = "AuraBrowser"
    const val MAX_LOGS = 50
    private const val FILE_NAME = "aura_diag_flagged.log"

    private val buffer = ConcurrentLinkedDeque<String>()
    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    // Các dòng có cờ, giữ để ghi file (tối đa MAX_LOGS dòng)
    private val persisted = kotlin.collections.ArrayDeque<String>()

    @Volatile
    private var file: File? = null

    private val io = Executors.newSingleThreadExecutor { r ->
        Thread(r, "aura-diag-io").apply { isDaemon = true }
    }

    fun d(tag: String = TAG, message: String) {
        Log.d(tag, message)
        add("[${now()}][$tag] $message")
    }

    /** Log có cờ: flag ví dụ "KILL", "CRASH", "RAM", "PICKER", "EXIT". */
    fun flag(flag: String, tag: String, message: String) {
        Log.w(tag, "[$flag] $message")
        val line = "[${now()}][$tag][$flag] $message"
        add(line)
        persist(line)
    }

    /** Gọi một lần lúc app khởi động: nạp lại các dòng có cờ từ phiên trước. */
    fun init(context: Context) {
        if (file != null) return
        val f = File(context.applicationContext.filesDir, FILE_NAME)
        file = f
        try {
            if (f.exists()) {
                val old = f.readLines().filter { it.isNotBlank() }.takeLast(MAX_LOGS)
                synchronized(persisted) {
                    persisted.clear()
                    persisted.addAll(old)
                }
                val marked = old.map { "(phiên trước) $it" }
                val current = buffer.toList()
                buffer.clear()
                (marked + current).takeLast(MAX_LOGS).forEach { buffer.addLast(it) }
            }
        } catch (_: Exception) {
            // Bỏ qua: log chẩn đoán không được làm hỏng app
        }
    }

    fun getRecentLogs(): List<String> {
        return buffer.toList()
    }

    private fun now(): String = synchronized(dateFormat) { dateFormat.format(Date()) }

    private fun add(line: String) {
        buffer.addLast(line)
        while (buffer.size > MAX_LOGS) {
            buffer.pollFirst()
        }
    }

    private fun persist(line: String) {
        val f = file ?: return
        io.execute {
            try {
                val snapshot = synchronized(persisted) {
                    persisted.addLast(line)
                    while (persisted.size > MAX_LOGS) {
                        persisted.removeFirst()
                    }
                    persisted.toList()
                }
                f.writeText(snapshot.joinToString("\n") + "\n")
            } catch (_: Exception) {
                // Bỏ qua lỗi ghi file
            }
        }
    }
}
