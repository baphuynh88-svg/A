package com.example.util

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedDeque

object AppLogger {
    private const val TAG = "AuraBrowser"
    private const val MAX_LOGS = 20
    private val buffer = ConcurrentLinkedDeque<String>()
    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun d(tag: String = TAG, message: String) {
        Log.d(tag, message)
        val timestamp = dateFormat.format(Date())
        buffer.addLast("[$timestamp][$tag] $message")
        while (buffer.size > MAX_LOGS) {
            buffer.pollFirst()
        }
    }

    fun getRecentLogs(): List<String> {
        return buffer.toList()
    }
}
