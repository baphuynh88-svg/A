package com.example.gecko

import com.example.data.local.SitePermissionStore
import com.example.data.local.SitePolicyStore
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PermissionDelegate
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.Callback
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.ContentPermission
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.MediaCallback
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.MediaSource

/**
 * Xử lý yêu cầu cấp quyền từ trang web và hệ thống Android theo chính sách bảo mật:
 * 1. Quyền runtime Android (Camera, Micro, Vị trí): Xin qua PermissionBridge.
 * 2. Quyền nội dung web (ContentPermission): Vị trí hỏi người dùng; Thông báo web luôn chặn;
 *    Autoplay & persistent storage luôn cho phép; loại khác chặn.
 * 3. Quyền Media (Camera/Micro): Hỏi người dùng, ưu tiên camera sau/ngoài nếu có, hỗ trợ nhớ lựa chọn.
 */
class AuraPermissionDelegate(
    private val tabId: String,
    private val sitePermissionStore: SitePermissionStore,
    private val sitePolicyStore: SitePolicyStore,
    private val getTabUrl: () -> String,
    private val onShowPermissionPrompt: (PermissionPrompt) -> Unit,
    private val onClearPermissionPrompt: () -> Unit
) : PermissionDelegate {

    override fun onAndroidPermissionsRequest(
        session: GeckoSession,
        permissions: Array<out String>?,
        callback: Callback
    ) {
        if (permissions.isNullOrEmpty()) {
            callback.grant()
            return
        }

        val requester = PermissionBridge.requester
        if (requester == null) {
            AppLogger.d("AuraPermissionDelegate", "PermissionBridge.requester chưa sẵn sàng")
            callback.reject()
            return
        }

        try {
            requester(permissions as Array<String>) { granted ->
                if (granted) {
                    callback.grant()
                } else {
                    callback.reject()
                }
            }
        } catch (e: Exception) {
            AppLogger.d("AuraPermissionDelegate", "Lỗi xin quyền Android: ${e.message}")
            callback.reject()
        }
    }

    override fun onContentPermissionRequest(
        session: GeckoSession,
        perm: ContentPermission
    ): GeckoResult<Int> {
        val host = getDisplayHost(perm.uri)

        when (perm.permission) {
            PermissionDelegate.PERMISSION_GEOLOCATION -> {
                // Kiểm tra lựa chọn đã nhớ trước đó
                val saved = sitePermissionStore.getPermission(host, SitePermissionStore.TYPE_GEOLOCATION)
                if (saved == SitePermissionStore.ALLOW) {
                    return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW)
                } else if (saved == SitePermissionStore.DENY) {
                    return GeckoResult.fromValue(ContentPermission.VALUE_DENY)
                }

                val result = GeckoResult<Int>()
                var isCompleted = false
                fun completeOnce(value: Int) {
                    if (!isCompleted) {
                        isCompleted = true
                        result.complete(value)
                    }
                }

                val prompt = PermissionPrompt.Geolocation(
                    tabId = tabId,
                    host = host,
                    onDecision = { allow, remember ->
                        if (remember) {
                            sitePermissionStore.setPermission(
                                host,
                                SitePermissionStore.TYPE_GEOLOCATION,
                                if (allow) SitePermissionStore.ALLOW else SitePermissionStore.DENY
                            )
                        }
                        completeOnce(if (allow) ContentPermission.VALUE_ALLOW else ContentPermission.VALUE_DENY)
                        onClearPermissionPrompt()
                    },
                    onDismiss = {
                        completeOnce(ContentPermission.VALUE_DENY)
                        onClearPermissionPrompt()
                    }
                )

                onShowPermissionPrompt(prompt)
                return result
            }

            PermissionDelegate.PERMISSION_DESKTOP_NOTIFICATION -> {
                // Luôn từ chối thông báo web để tránh spam
                return GeckoResult.fromValue(ContentPermission.VALUE_DENY)
            }

            PermissionDelegate.PERMISSION_PERSISTENT_STORAGE,
            PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE,
            PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE -> {
                return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW)
            }

            PermissionDelegate.PERMISSION_MEDIA_KEY_SYSTEM_ACCESS -> {
                AppLogger.d("AuraPermissionDelegate", "Cấp quyền DRM/Widevine (PERMISSION_MEDIA_KEY_SYSTEM_ACCESS) cho host: $host")
                return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW)
            }

            else -> {
                return GeckoResult.fromValue(ContentPermission.VALUE_DENY)
            }
        }
    }

    override fun onMediaPermissionRequest(
        session: GeckoSession,
        uri: String,
        video: Array<out MediaSource>?,
        audio: Array<out MediaSource>?,
        callback: MediaCallback
    ) {
        val host = getDisplayHost(uri)

        // Chọn camera ưu tiên camera sau/ngoài nếu có
        val chosenVideo = video?.firstOrNull {
            val name = it.name?.lowercase() ?: ""
            name.contains("back") || name.contains("rear") || name.contains("environment")
        } ?: video?.firstOrNull()

        val chosenAudio = audio?.firstOrNull()

        // Kiểm tra lựa chọn đã nhớ trước đó
        val saved = sitePermissionStore.getPermission(host, SitePermissionStore.TYPE_MEDIA)
        if (saved == SitePermissionStore.ALLOW) {
            callback.grant(chosenVideo, chosenAudio)
            return
        } else if (saved == SitePermissionStore.DENY) {
            callback.reject()
            return
        }

        var isCompleted = false
        val prompt = PermissionPrompt.Media(
            tabId = tabId,
            host = host,
            hasVideo = !video.isNullOrEmpty(),
            hasAudio = !audio.isNullOrEmpty(),
            onDecision = { allow, remember ->
                if (!isCompleted) {
                    isCompleted = true
                    if (remember) {
                        sitePermissionStore.setPermission(
                            host,
                            SitePermissionStore.TYPE_MEDIA,
                            if (allow) SitePermissionStore.ALLOW else SitePermissionStore.DENY
                        )
                    }
                    if (allow) {
                        callback.grant(chosenVideo, chosenAudio)
                    } else {
                        callback.reject()
                    }
                    onClearPermissionPrompt()
                }
            },
            onDismiss = {
                if (!isCompleted) {
                    isCompleted = true
                    callback.reject()
                    onClearPermissionPrompt()
                }
            }
        )

        onShowPermissionPrompt(prompt)
    }

    private fun getDisplayHost(uri: String?): String {
        val raw = if (!uri.isNullOrBlank()) uri else getTabUrl()
        val host = SitePolicyStore.normalizeHost(raw)
        return host.ifBlank { "trang web" }
    }
}
