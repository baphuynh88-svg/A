package com.example.gecko

import androidx.compose.runtime.Immutable
import org.mozilla.geckoview.GeckoSession
import java.util.UUID

@Immutable
data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Tab",
    val url: String = "",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isDesktopMode: Boolean = false,
    val isSecure: Boolean = false,
    val isStartPage: Boolean = true,
    val session: GeckoSession? = null,
    val sessionState: GeckoSession.SessionState? = null,
    val lastAccessedAt: Long = System.currentTimeMillis(),
    val isPrivate: Boolean = false
)
