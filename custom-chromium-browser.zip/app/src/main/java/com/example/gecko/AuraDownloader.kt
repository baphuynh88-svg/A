package com.example.gecko

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Bộ tải HTTP dùng chung OkHttpClient (timeout 15s) cho NewPipeExtractor.
 */
object AuraDownloader : Downloader() {

    const val USER_AGENT =
        "Mozilla/5.0 (Android 14; Mobile; rv:136.0) Gecko/136.0 Firefox/136.0"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    val headClient: OkHttpClient = client.newBuilder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .build()

    fun getInstance(): AuraDownloader = this

    @Throws(IOException::class, ReCaptchaException::class)
    override fun execute(request: Request): Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val dataToSend = request.dataToSend()

        val requestBody = when {
            dataToSend != null -> dataToSend.toRequestBody(null)
            requiresRequestBody(httpMethod) -> ByteArray(0).toRequestBody(null)
            else -> null
        }

        val requestBuilder = okhttp3.Request.Builder()
            .url(url)
            .method(httpMethod, requestBody)
            .header("User-Agent", USER_AGENT)

        for ((headerName, headerValueList) in headers) {
            if (headerValueList.size > 1) {
                requestBuilder.removeHeader(headerName)
                for (headerValue in headerValueList) {
                    if (headerValue != null) {
                        requestBuilder.addHeader(headerName, headerValue)
                    }
                }
            } else if (headerValueList.size == 1) {
                val singleValue = headerValueList[0]
                if (singleValue != null) {
                    requestBuilder.header(headerName, singleValue)
                }
            }
        }

        client.newCall(requestBuilder.build()).execute().use { okResponse ->
            if (okResponse.code == 429) {
                throw ReCaptchaException("reCaptcha Challenge requested", url)
            }

            val responseBodyToReturn = okResponse.body?.string()
            val latestUrl = okResponse.request.url.toString()

            return Response(
                okResponse.code,
                okResponse.message,
                okResponse.headers.toMultimap(),
                responseBodyToReturn,
                latestUrl
            )
        }
    }

    private fun requiresRequestBody(method: String): Boolean {
        return method.equals("POST", ignoreCase = true) ||
            method.equals("PUT", ignoreCase = true) ||
            method.equals("PATCH", ignoreCase = true) ||
            method.equals("PROPPATCH", ignoreCase = true) ||
            method.equals("REPORT", ignoreCase = true)
    }
}
