package com.example.gecko

/**
 * Trạng thái yêu cầu quyền của trang web hiển thị trên UI.
 */
sealed class PermissionPrompt {
    abstract val tabId: String
    abstract val host: String
    abstract fun dismiss()

    data class Geolocation(
        override val tabId: String,
        override val host: String,
        val onDecision: (allow: Boolean, remember: Boolean) -> Unit,
        val onDismiss: () -> Unit
    ) : PermissionPrompt() {
        override fun dismiss() = onDismiss()
    }

    data class Media(
        override val tabId: String,
        override val host: String,
        val hasVideo: Boolean,
        val hasAudio: Boolean,
        val onDecision: (allow: Boolean, remember: Boolean) -> Unit,
        val onDismiss: () -> Unit
    ) : PermissionPrompt() {
        override fun dismiss() = onDismiss()
    }
}
