package com.example.gecko

import android.text.TextUtils
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Nhận diện trang có rủi ro cao (cờ bạc / cá độ, dark web .onion) và dựng trang cảnh báo 2 bước.
 *
 * Việc nhận diện dựa trên tên miền (heuristic), không phải danh sách đầy đủ — trang lạ vẫn có thể lọt.
 * Trang cảnh báo là data: URI; các nút bấm là liên kết aura://back và aura://enter?u=... được
 * GeckoTabHelper.onLoadRequest chặn lại và xử lý.
 */
object RiskySiteGuard {

    enum class Category { GAMBLING, DARKWEB }

    // Sau khi người dùng xác nhận 2 lần, cho phép host này trong 30 phút (chỉ trong bộ nhớ)
    private const val ALLOW_DURATION_MS = 30L * 60L * 1000L
    private val allowedUntil = ConcurrentHashMap<String, Long>()

    private val DARKWEB_SUFFIXES = listOf(
        ".onion", ".onion.ly", ".onion.pet", ".onion.ws", ".onion.sh", ".onion.to",
        ".onion.cab", ".onion.ink", ".onion.link", ".onion.nu", ".onion.re", ".tor2web.org"
    )

    // Tên thương hiệu / từ khoá đủ dài và đặc trưng để khớp theo chuỗi con
    private val GAMBLING_SUBSTRINGS = listOf(
        "hello88", "sunwin", "casino", "nhacai", "cacuoc", "sbobet", "bet365", "1xbet", "22bet",
        "mostbet", "hitclub", "rikvip", "188bet", "789bet", "12bet", "8xbet", "f8bet", "kubet",
        "789club", "68gamebai", "dafabet", "betway", "fun88", "bong88", "tai-xiu", "taixiu",
        "slotgame", "xocdia", "xoc-dia"
    )

    // Dạng "chữ + 88" (w88, new88, jun88, hello88, ...) hoặc "88 + chữ" (88clb, 88bet, ...)
    private val PATTERN_88_SUFFIX = Regex("^[a-z]{1,10}88[a-z0-9]{0,4}$")
    private val PATTERN_88_PREFIX = Regex("^88[a-z]{1,10}$")

    // Thương hiệu ngắn: khớp cả token (có thể kèm tối đa 3 ký tự đuôi)
    private val PATTERN_SHORT_BRANDS = Regex(
        "^(m88|w88|fb88|bk8|mb66|jun88|new88|go88|vn88|v9bet|shbet|ok365|mu88|j88|ku11|sv388|vn138|qh88|88clb)[a-z0-9]{0,3}$"
    )

    private val GAMBLING_TLDS = setOf("bet", "casino", "poker", "bingo")

    // Một số tên miền hợp pháp có thể vô tình khớp mẫu — bỏ qua
    private val WHITELIST = setOf<String>()

    fun classify(rawHost: String): Category? {
        val host = rawHost.lowercase().trim().removePrefix("www.").trimEnd('.')
        if (host.isBlank()) return null
        if (WHITELIST.contains(baseKey(host))) return null

        if (DARKWEB_SUFFIXES.any { host == it.removePrefix(".") || host.endsWith(it) }) {
            return Category.DARKWEB
        }

        val labels = host.split('.')
        if (labels.size >= 2 && GAMBLING_TLDS.contains(labels.last())) {
            return Category.GAMBLING
        }

        // Bỏ nhãn TLD cuối cùng; xét từng nhãn và từng token tách bởi dấu '-'
        val candidates = labels.dropLast(1)
        for (label in candidates) {
            if (matchesGambling(label)) return Category.GAMBLING
            for (token in label.split('-')) {
                if (token.isNotEmpty() && matchesGambling(token)) return Category.GAMBLING
            }
        }
        return null
    }

    private fun matchesGambling(token: String): Boolean {
        if (GAMBLING_SUBSTRINGS.any { token.contains(it) }) return true
        if (PATTERN_SHORT_BRANDS.matches(token)) return true
        if (PATTERN_88_SUFFIX.matches(token)) return true
        if (PATTERN_88_PREFIX.matches(token)) return true
        return false
    }

    /** Khoá dùng để nhớ trạng thái "đã xác nhận": 2 nhãn cuối (3 nếu dạng com.vn, co.uk...). */
    fun baseKey(rawHost: String): String {
        val host = rawHost.lowercase().trim().removePrefix("www.").trimEnd('.')
        if (host.endsWith(".onion")) return host
        val parts = host.split('.')
        if (parts.size <= 2) return host
        val tld = parts.last()
        val sld = parts[parts.size - 2]
        val takeThree = tld.length == 2 && sld in setOf("com", "co", "net", "org", "gov", "edu")
        val n = if (takeThree) 3 else 2
        return parts.takeLast(n).joinToString(".")
    }

    fun isAllowed(host: String): Boolean {
        val key = baseKey(host)
        val until = allowedUntil[key] ?: return false
        if (System.currentTimeMillis() > until) {
            allowedUntil.remove(key)
            return false
        }
        return true
    }

    fun allow(host: String) {
        allowedUntil[baseKey(host)] = System.currentTimeMillis() + ALLOW_DURATION_MS
    }

    // ---------- Trang cảnh báo ----------

    private const val STYLE = """
        body { font-family: -apple-system, Roboto, sans-serif; margin: 0; padding: 24px; background: #ffffff; color: #202124; text-align: center; }
        .wrap { max-width: 420px; margin: 8vh auto 0; }
        .icon { font-size: 56px; line-height: 1; }
        h2 { margin: 12px 0 8px; font-size: 21px; }
        p { color: #5f6368; font-size: 14px; line-height: 1.5; margin: 8px 0; }
        .url { color: #80868b; font-size: 12px; word-break: break-all; margin: 14px 0 22px; }
        .btn { display: block; box-sizing: border-box; width: 100%; padding: 14px 16px; border-radius: 26px; font-size: 15px; font-weight: 600; text-decoration: none; margin: 10px 0; border: none; font-family: inherit; }
        .safe { background: #1a73e8; color: #ffffff; }
        .risky { background: #ffffff; color: #d93025; border: 1.5px solid #d93025; }
        .disabled { opacity: 0.4; pointer-events: none; }
        .hidden { display: none; }
    """

    private fun toDataUri(html: String): String =
        "data:text/html;charset=utf-8," + URLEncoder.encode(html, "UTF-8").replace("+", "%20")

    fun buildWarningDataUri(category: Category, targetUrl: String, host: String): String {
        val safeUrl = TextUtils.htmlEncode(targetUrl)
        val safeHost = TextUtils.htmlEncode(host)
        val enc = URLEncoder.encode(targetUrl, "UTF-8")
        val (icon, title, body1, body2) = when (category) {
            Category.GAMBLING -> Quad(
                "⚠️",
                "Cảnh báo: trang cờ bạc / cá độ",
                "Trang này có dấu hiệu là web cờ bạc hoặc cá độ trực tuyến. Loại trang này thường bất hợp pháp tại Việt Nam và hay đi kèm lừa đảo, mất tiền, lộ thông tin cá nhân.",
                "Đây là bước xác nhận cuối cùng. Nếu không chắc chắn, hãy quay lại."
            )
            Category.DARKWEB -> Quad(
                "☠️",
                "Cảnh báo: địa chỉ dark web (.onion)",
                "Đây là địa chỉ thuộc mạng ẩn danh (dark web). Nội dung không được kiểm duyệt, có thể chứa mã độc, lừa đảo hoặc nội dung bất hợp pháp.",
                "Trình duyệt này không đi qua mạng Tor nên thường cũng không mở được các địa chỉ .onion."
            )
        }
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Cảnh báo</title>
            <style>$STYLE</style>
            </head>
            <body>
            <div class="wrap">
              <div class="icon">$icon</div>

              <div id="step1">
                <h2>$title</h2>
                <p>$body1</p>
                <p class="url">$safeUrl</p>
                <a class="btn safe" href="aura://back">Quay lại an toàn</a>
                <button class="btn risky" onclick="goStep2()">Tiếp tục</button>
              </div>

              <div id="step2" class="hidden">
                <h2>Bạn chắc chắn muốn vào?</h2>
                <p>$body2</p>
                <p class="url">$safeHost</p>
                <a class="btn safe" href="aura://back">Quay lại an toàn</a>
                <a id="enterBtn" class="btn risky disabled" href="aura://enter?u=$enc">Tôi hiểu rủi ro, vào trang <span id="cd">(3)</span></a>
              </div>
            </div>
            <script>
              function goStep2() {
                document.getElementById('step1').className = 'hidden';
                document.getElementById('step2').className = '';
                var n = 3;
                var btn = document.getElementById('enterBtn');
                var cd = document.getElementById('cd');
                var t = setInterval(function () {
                  n--;
                  if (n <= 0) {
                    clearInterval(t);
                    cd.textContent = '';
                    btn.className = 'btn risky';
                  } else {
                    cd.textContent = '(' + n + ')';
                  }
                }, 1000);
              }
            </script>
            </body>
            </html>
        """.trimIndent()
        return toDataUri(html)
    }

    /** Trang hiển thị khi Safe Browsing của Gecko chặn (malware / lừa đảo / nguy hiểm): chỉ có nút quay lại. */
    fun buildSafeBrowsingDataUri(targetUrl: String): String {
        val safeUrl = TextUtils.htmlEncode(targetUrl)
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Trang nguy hiểm</title>
            <style>$STYLE body { background: #fdf3f2; }</style>
            </head>
            <body>
            <div class="wrap">
              <div class="icon">🛑</div>
              <h2 style="color:#d93025">Trang này nguy hiểm</h2>
              <p>Safe Browsing cho biết trang này có thể chứa mã độc, lừa đảo hoặc phần mềm gây hại. Aura đã chặn để bảo vệ bạn.</p>
              <p class="url">$safeUrl</p>
              <a class="btn safe" href="aura://back">Quay lại an toàn</a>
            </div>
            </body>
            </html>
        """.trimIndent()
        return toDataUri(html)
    }

    private data class Quad(val a: String, val b: String, val c: String, val d: String)
}
