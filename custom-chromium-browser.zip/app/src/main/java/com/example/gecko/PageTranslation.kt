package com.example.gecko

import android.net.Uri
import java.net.IDN

/**
 * Dịch trang qua Google Translate (translate.goog), giống cách "Dịch trang" của Chrome:
 *   https://example.com/a?b=1  ->  https://example-com.translate.goog/a?b=1&_x_tr_sl=auto&_x_tr_tl=vi...
 * Quy tắc đổi tên miền: "-" thành "--", "." thành "-", rồi thêm ".translate.goog".
 */
object PageTranslation {
    private const val SUFFIX = ".translate.goog"
    private const val TARGET_LANG = "vi"

    private val ipv4Regex = Regex("""^(\d{1,3}\.){3}\d{1,3}$""")

    fun isTranslatedUrl(url: String): Boolean {
        val host = try { Uri.parse(url).host?.lowercase() } catch (_: Exception) { null }
        return host != null && host.endsWith(SUFFIX)
    }

    /** Chỉ dịch được trang http/https có tên miền thật, không dùng cổng riêng. */
    fun canTranslate(url: String): Boolean {
        if (isTranslatedUrl(url)) return true
        return try {
            val uri = Uri.parse(url)
            val scheme = uri.scheme?.lowercase()
            val host = uri.host?.lowercase()
            (scheme == "http" || scheme == "https") &&
                !host.isNullOrBlank() &&
                host.contains('.') &&
                !ipv4Regex.matches(host) &&
                uri.port == -1
        } catch (_: Exception) {
            false
        }
    }

    fun toTranslatedUrl(url: String): String? {
        if (!canTranslate(url) || isTranslatedUrl(url)) return null
        return try {
            val uri = Uri.parse(url)
            val asciiHost = IDN.toASCII(uri.host!!.lowercase())
            val translatedHost = asciiHost.replace("-", "--").replace(".", "-") + SUFFIX

            val sb = StringBuilder("https://").append(translatedHost)
            sb.append(uri.encodedPath ?: "")
            sb.append('?')
            val query = uri.encodedQuery
            if (!query.isNullOrBlank()) sb.append(query).append('&')
            sb.append("_x_tr_sl=auto&_x_tr_tl=").append(TARGET_LANG)
            sb.append("&_x_tr_hl=").append(TARGET_LANG)
            sb.append("&_x_tr_pto=wapp")
            val fragment = uri.encodedFragment
            if (!fragment.isNullOrBlank()) sb.append('#').append(fragment)
            sb.toString()
        } catch (_: Exception) {
            null
        }
    }

    /** Từ địa chỉ translate.goog quay về địa chỉ gốc (mặc định https). */
    fun toOriginalUrl(url: String): String? {
        if (!isTranslatedUrl(url)) return null
        return try {
            val uri = Uri.parse(url)
            val host = uri.host!!.lowercase().removeSuffix(SUFFIX)
            val originalHost = host.replace("--", "\u0000").replace("-", ".").replace("\u0000", "-")

            val keptQuery = (uri.encodedQuery ?: "")
                .split('&')
                .filter { it.isNotBlank() && !it.startsWith("_x_tr_") }
                .joinToString("&")

            val sb = StringBuilder("https://").append(originalHost)
            sb.append(uri.encodedPath ?: "")
            if (keptQuery.isNotEmpty()) sb.append('?').append(keptQuery)
            val fragment = uri.encodedFragment
            if (!fragment.isNullOrBlank()) sb.append('#').append(fragment)
            sb.toString()
        } catch (_: Exception) {
            null
        }
    }
}
