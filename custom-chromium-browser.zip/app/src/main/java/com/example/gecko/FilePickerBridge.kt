package com.example.gecko

import android.content.Intent

/**
 * Cầu nối trung gian cho AuraPromptDelegate mở bộ chọn file hệ thống từ Activity
 * mà không giữ tham chiếu cứng đến Activity để tránh rò rỉ bộ nhớ (memory leak).
 */
object FilePickerBridge {
    /** true từ lúc mở bộ chọn file tới lúc trả kết quả cho GeckoView: giữ session KHÔNG bị setActive(false) */
    @Volatile
    var inProgress: Boolean = false

    @Volatile
    var launcher: ((intent: Intent, callback: (resultCode: Int, data: Intent?) -> Unit) -> Unit)? = null
}
