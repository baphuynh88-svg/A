package com.example.gecko

/**
 * Cầu nối yêu cầu quyền runtime hệ thống Android từ MainActivity.
 * Giúp AuraPermissionDelegate xin quyền thật mà không giữ tham chiếu cứng đến Activity.
 */
object PermissionBridge {
    @Volatile
    var requester: ((permissions: Array<String>, callback: (granted: Boolean) -> Unit) -> Unit)? = null
}
