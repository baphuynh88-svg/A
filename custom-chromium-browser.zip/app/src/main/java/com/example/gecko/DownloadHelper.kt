package com.example.gecko

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.example.util.AppLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.util.regex.Pattern

/**
 * Trạng thái sự kiện tải file.
 */
sealed class DownloadResult {
    data class Progress(val message: String) : DownloadResult()
    data class Success(val message: String, val uri: Uri?, val mimeType: String?) : DownloadResult()
    data class Error(val message: String) : DownloadResult()
}

object DownloadHelper {
    private val scope = CoroutineScope(Dispatchers.IO)

    /**
     * Bắt đầu tải file từ WebResponse của GeckoView.
     */
    fun start(
        context: Context,
        response: WebResponse,
        onResult: (DownloadResult) -> Unit
    ) {
        scope.launch {
            val contentDisposition = findHeader(response.headers, "Content-Disposition")
            val contentType = findHeader(response.headers, "Content-Type")?.substringBefore(';')?.trim()
            val inputStream = response.body
            if (inputStream == null) {
                withContext(Dispatchers.Main) {
                    onResult(DownloadResult.Error("Tải lỗi: Không có nội dung dữ liệu"))
                }
                return@launch
            }

            writeStream(
                context = context,
                inputStream = inputStream,
                uri = response.uri,
                contentDisposition = contentDisposition,
                contentType = contentType,
                onResult = onResult
            )
        }
    }

    /** Chỉ cho http/https và host phân giải ra IP công khai (không loopback/private/link-local). */
    private fun isPublicHttpUrl(raw: String): Boolean {
        return try {
            val u = URL(raw)
            val proto = u.protocol.lowercase()
            if (proto != "http" && proto != "https") return false
            val host = u.host
            if (host.isNullOrBlank()) return false
            java.net.InetAddress.getAllByName(host).none { a ->
                val b = a.address
                val cgnat = b.size == 4 && (b[0].toInt() and 0xFF) == 100 && (b[1].toInt() and 0xC0) == 64
                val ula = b.size == 16 && (b[0].toInt() and 0xFE) == 0xFC
                a.isAnyLocalAddress || a.isLoopbackAddress || a.isLinkLocalAddress ||
                    a.isSiteLocalAddress || a.isMulticastAddress || cgnat || ula
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Tải file hoặc hình ảnh trực tiếp từ URL thông qua HttpURLConnection.
     */
    fun downloadUrl(
        context: Context,
        url: String,
        onResult: (DownloadResult) -> Unit
    ) {
        scope.launch {
            try {
                // Chặn SSRF: không tải về địa chỉ mạng nội bộ (router 192.168.x.x, localhost...),
                // kiểm tra cả từng bước chuyển hướng (redirect) vì HttpURLConnection mặc định tự theo redirect.
                var currentUrl = url
                var connection: HttpURLConnection? = null
                var hops = 0
                while (true) {
                    if (!isPublicHttpUrl(currentUrl)) {
                        throw java.io.IOException("Địa chỉ không hợp lệ (mạng nội bộ)")
                    }
                    val c = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 10000
                        readTimeout = 15000
                        instanceFollowRedirects = false
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:136.0) Gecko/136.0 Firefox/136.0")
                    }
                    c.connect()
                    val code = c.responseCode
                    if (code in 300..399 && code != 304) {
                        val loc = c.getHeaderField("Location")
                        c.disconnect()
                        if (loc.isNullOrBlank() || ++hops > 5) {
                            throw java.io.IOException("Chuyển hướng không hợp lệ")
                        }
                        currentUrl = URL(URL(currentUrl), loc).toString()
                        continue
                    }
                    connection = c
                    break
                }
                val conn = connection!!

                val contentDisposition = conn.getHeaderField("Content-Disposition")
                val contentType = conn.contentType?.substringBefore(';')?.trim()
                val inputStream = conn.inputStream

                writeStream(
                    context = context,
                    inputStream = inputStream,
                    uri = url,
                    contentDisposition = contentDisposition,
                    contentType = contentType,
                    onResult = onResult
                )
            } catch (e: Exception) {
                AppLogger.d("DownloadHelper", "Lỗi tải URL: ${e.message}")
                withContext(Dispatchers.Main) {
                    onResult(DownloadResult.Error("Tải lỗi: ${e.message}"))
                }
            }
        }
    }

    private suspend fun writeStream(
        context: Context,
        inputStream: InputStream,
        uri: String,
        contentDisposition: String?,
        contentType: String?,
        onResult: (DownloadResult) -> Unit
    ) {
        val mimeType = contentType?.ifBlank { null } ?: "application/octet-stream"
        val filename = extractFilename(uri, contentDisposition, mimeType)
        val cleanedFilename = sanitizeFilename(filename)

        withContext(Dispatchers.Main) {
            onResult(DownloadResult.Progress("Đang tải $cleanedFilename..."))
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // API 29+: Dùng MediaStore.Downloads với IS_PENDING
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, cleanedFilename)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Aura")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val fileUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (fileUri == null) {
                    inputStream.close()
                    withContext(Dispatchers.Main) {
                        onResult(DownloadResult.Error("Tải lỗi: Không tạo được file trong MediaStore"))
                    }
                    return
                }

                try {
                    resolver.openOutputStream(fileUri)?.use { outputStream ->
                        val buffer = ByteArray(64 * 1024) // 64KB buffer
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                        outputStream.flush()
                    } ?: throw Exception("Không thể mở luồng ghi vào MediaStore")

                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(fileUri, contentValues, null, null)

                    withContext(Dispatchers.Main) {
                        onResult(DownloadResult.Success("Đã tải xong $cleanedFilename", fileUri, mimeType))
                    }
                } catch (e: Exception) {
                    AppLogger.d("DownloadHelper", "Lỗi khi ghi file MediaStore: ${e.message}")
                    resolver.delete(fileUri, null, null)
                    withContext(Dispatchers.Main) {
                        onResult(DownloadResult.Error("Tải lỗi: ${e.message}"))
                    }
                } finally {
                    try { inputStream.close() } catch (_: Exception) {}
                }
            } else {
                // API 24-28: Ghi vào Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS)/Aura
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val auraDir = File(downloadsDir, "Aura")
                if (!auraDir.exists()) {
                    auraDir.mkdirs()
                }

                var targetFile = File(auraDir, cleanedFilename)
                if (targetFile.exists()) {
                    val baseName = cleanedFilename.substringBeforeLast('.')
                    val extension = if (cleanedFilename.contains('.')) ".${cleanedFilename.substringAfterLast('.')}" else ""
                    var counter = 1
                    while (targetFile.exists()) {
                        targetFile = File(auraDir, "$baseName ($counter)$extension")
                        counter++
                    }
                }

                try {
                    FileOutputStream(targetFile).use { outputStream ->
                        val buffer = ByteArray(64 * 1024) // 64KB buffer
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                        outputStream.flush()
                    }

                    withContext(Dispatchers.Main) {
                        onResult(DownloadResult.Success("Đã tải xong: ${targetFile.absolutePath}", null, mimeType))
                    }
                } catch (e: Exception) {
                    AppLogger.d("DownloadHelper", "Lỗi ghi file legacy: ${e.message}")
                    if (targetFile.exists()) {
                        targetFile.delete()
                    }
                    withContext(Dispatchers.Main) {
                        onResult(DownloadResult.Error("Tải lỗi: ${e.message}"))
                    }
                } finally {
                    try { inputStream.close() } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            AppLogger.d("DownloadHelper", "Lỗi tải stream: ${e.message}")
            withContext(Dispatchers.Main) {
                onResult(DownloadResult.Error("Tải lỗi: ${e.message}"))
            }
        }
    }

    private fun findHeader(headers: Map<String, String>?, name: String): String? {
        if (headers == null) return null
        return headers.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value
    }

    private fun extractFilename(uri: String, contentDisposition: String?, mimeType: String?): String {
        // 1. Thử lấy từ header Content-Disposition (filename*= hoặc filename=)
        if (!contentDisposition.isNullOrBlank()) {
            val starPattern = Pattern.compile("filename\\*=(?:UTF-8''|utf-8'')?([^;]+)", Pattern.CASE_INSENSITIVE)
            val starMatcher = starPattern.matcher(contentDisposition)
            if (starMatcher.find()) {
                val raw = starMatcher.group(1)?.trim()?.trim('\"')
                if (!raw.isNullOrBlank()) {
                    return try { URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { raw }
                }
            }

            val normalPattern = Pattern.compile("filename=\"?([^;\"]+)\"?", Pattern.CASE_INSENSITIVE)
            val normalMatcher = normalPattern.matcher(contentDisposition)
            if (normalMatcher.find()) {
                val raw = normalMatcher.group(1)?.trim()?.trim('\"')
                if (!raw.isNullOrBlank()) {
                    return raw
                }
            }
        }

        // 2. Thử lấy đoạn cuối của URL
        try {
            val cleanUrl = uri.substringBefore('?').substringBefore('#').trimEnd('/')
            val lastSegment = cleanUrl.substringAfterLast('/')
            if (lastSegment.isNotBlank()) {
                val decoded = try { URLDecoder.decode(lastSegment, "UTF-8") } catch (_: Exception) { lastSegment }
                if (decoded.isNotBlank()) {
                    return decoded
                }
            }
        } catch (_: Exception) {}

        // 3. Dự phòng theo timestamp + extension từ mimeType
        val timestamp = System.currentTimeMillis()
        val ext = if (!mimeType.isNullOrBlank()) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)?.let { ".$it" } ?: ""
        } else ""

        return "download_$timestamp$ext"
    }

    private fun sanitizeFilename(filename: String): String {
        var sanitized = filename.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim()
        if (sanitized.isBlank()) {
            sanitized = "download_${System.currentTimeMillis()}"
        }
        return sanitized
    }
}
