package com.example.gecko

/**
 * Trạng thái menu ngữ cảnh khi người dùng nhấn giữ lâu trên link hoặc hình ảnh/media.
 */
data class ContextMenuState(
    val tabId: String,
    val linkUri: String?,
    val srcUri: String?,
    val type: Int
)
