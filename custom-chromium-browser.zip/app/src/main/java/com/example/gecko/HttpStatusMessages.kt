package com.example.gecko

import org.mozilla.geckoview.WebRequestError

/**
 * Nhóm mã trạng thái HTTP (1xx–5xx) và lời nhắn tiếng Việt tương ứng,
 * cùng lời nhắn cho các lỗi mạng / HTTPS ở tầng GeckoView.
 */
object HttpStatusMessages {

    data class Info(
        val code: Int,
        val group: String,
        val title: String,
        val message: String
    )

    fun groupOf(code: Int): String = when (code) {
        in 100..199 -> "1xx"
        in 200..299 -> "2xx"
        in 300..399 -> "3xx"
        in 400..499 -> "4xx"
        in 500..599 -> "5xx"
        else -> "?"
    }

    fun isError(code: Int): Boolean = code in 400..599

    private fun groupInfo(code: Int): Pair<String, String> = when (code) {
        in 100..199 -> "Thông tin" to "Máy chủ đang xử lý yêu cầu của bạn."
        in 200..299 -> "Thành công" to "Yêu cầu đã được xử lý thành công."
        in 300..399 -> "Chuyển hướng" to "Trang đã được chuyển sang địa chỉ khác."
        in 400..499 -> "Lỗi yêu cầu" to "Yêu cầu có vấn đề hoặc trang bạn cần không dùng được."
        in 500..599 -> "Lỗi máy chủ" to "Máy chủ của trang web đang gặp sự cố. Hãy thử lại sau."
        else -> "Mã không chuẩn" to "Máy chủ trả về mã trạng thái không xác định."
    }

    private val specific: Map<Int, Pair<String, String>> = mapOf(
        100 to ("Tiếp tục" to "Máy chủ đã nhận phần đầu yêu cầu, hãy gửi tiếp."),
        101 to ("Đổi giao thức" to "Máy chủ đang chuyển sang giao thức khác."),
        200 to ("Thành công" to "Trang tải bình thường."),
        204 to ("Không có nội dung" to "Yêu cầu thành công nhưng không có nội dung để hiển thị."),
        301 to ("Đã chuyển vĩnh viễn" to "Trang đã được chuyển sang địa chỉ mới."),
        302 to ("Chuyển tạm thời" to "Trang đang tạm chuyển sang địa chỉ khác."),
        304 to ("Không thay đổi" to "Trang chưa thay đổi, dùng bản đã lưu."),
        307 to ("Chuyển tạm thời" to "Trang đang tạm chuyển sang địa chỉ khác."),
        308 to ("Đã chuyển vĩnh viễn" to "Trang đã được chuyển sang địa chỉ mới."),
        400 to ("Yêu cầu không hợp lệ" to "Máy chủ không hiểu yêu cầu. Kiểm tra lại địa chỉ."),
        401 to ("Cần đăng nhập" to "Trang này yêu cầu đăng nhập hoặc xác thực."),
        403 to ("Bị từ chối truy cập" to "Bạn không có quyền xem trang này."),
        404 to ("Không tìm thấy trang" to "Địa chỉ không tồn tại hoặc đã bị xoá."),
        405 to ("Phương thức không được phép" to "Trang không chấp nhận kiểu yêu cầu này."),
        408 to ("Hết thời gian chờ" to "Máy chủ chờ yêu cầu quá lâu. Hãy thử lại."),
        410 to ("Trang đã bị gỡ" to "Trang này đã bị xoá vĩnh viễn."),
        413 to ("Dữ liệu quá lớn" to "Dữ liệu gửi lên vượt quá giới hạn của máy chủ."),
        414 to ("Địa chỉ quá dài" to "Địa chỉ (URL) quá dài so với giới hạn của máy chủ."),
        429 to ("Quá nhiều yêu cầu" to "Bạn đã gửi quá nhiều yêu cầu. Hãy chờ một lúc rồi thử lại."),
        451 to ("Bị chặn vì lý do pháp lý" to "Nội dung này không khả dụng do hạn chế pháp lý."),
        500 to ("Lỗi máy chủ nội bộ" to "Máy chủ gặp lỗi không mong muốn. Hãy thử lại sau."),
        501 to ("Chưa hỗ trợ" to "Máy chủ chưa hỗ trợ chức năng được yêu cầu."),
        502 to ("Cổng kết nối lỗi" to "Máy chủ trung gian nhận phản hồi không hợp lệ."),
        503 to ("Dịch vụ không khả dụng" to "Máy chủ đang quá tải hoặc bảo trì. Hãy thử lại sau."),
        504 to ("Cổng hết thời gian chờ" to "Máy chủ trung gian chờ phản hồi quá lâu."),
        520 to ("Lỗi không xác định (Cloudflare)" to "Máy chủ gốc trả về phản hồi không mong đợi."),
        521 to ("Máy chủ ngừng hoạt động (Cloudflare)" to "Máy chủ gốc đang tắt hoặc từ chối kết nối."),
        522 to ("Hết thời gian kết nối (Cloudflare)" to "Máy chủ gốc không phản hồi kịp."),
        523 to ("Không tới được máy chủ (Cloudflare)" to "Cloudflare không kết nối được tới máy chủ gốc."),
        524 to ("Hết thời gian chờ (Cloudflare)" to "Máy chủ gốc phản hồi quá chậm.")
    )

    fun describe(code: Int): Info {
        val group = groupOf(code)
        val s = specific[code]
        if (s != null) {
            return Info(code, group, s.first, s.second)
        }
        val (title, message) = groupInfo(code)
        return Info(code, group, title, message)
    }

    /** Lời nhắn ngắn cho snackbar, ví dụ: "Lỗi 404 (4xx): Không tìm thấy trang". */
    fun snackbarText(code: Int): String {
        val info = describe(code)
        return "Lỗi ${info.code} (${info.group}): ${info.title}"
    }

    private fun errorCodeName(code: Int): String? = when (code) {
        WebRequestError.ERROR_UNKNOWN_HOST -> "ERROR_UNKNOWN_HOST"
        WebRequestError.ERROR_CONNECTION_REFUSED -> "ERROR_CONNECTION_REFUSED"
        WebRequestError.ERROR_NET_TIMEOUT -> "ERROR_NET_TIMEOUT"
        WebRequestError.ERROR_OFFLINE -> "ERROR_OFFLINE"
        WebRequestError.ERROR_SECURITY_BAD_CERT -> "ERROR_SECURITY_BAD_CERT"
        WebRequestError.ERROR_SECURITY_SSL -> "ERROR_SECURITY_SSL"
        WebRequestError.ERROR_MALFORMED_URI -> "ERROR_MALFORMED_URI"
        WebRequestError.ERROR_REDIRECT_LOOP -> "ERROR_REDIRECT_LOOP"
        WebRequestError.ERROR_PORT_BLOCKED -> "ERROR_PORT_BLOCKED"
        else -> null
    }

    /**
     * Dòng thông tin kỹ thuật cho trang lỗi, ví dụ: "Mã lỗi: 67 (ERROR_CONNECTION_REFUSED)".
     * Chỉ ghi số mã lỗi cụ thể, không ghi nhóm.
     */
    fun technicalInfo(error: WebRequestError): String {
        val name = errorCodeName(error.code)
        return if (name != null) "Mã lỗi: ${error.code} ($name)" else "Mã lỗi: ${error.code}"
    }

    /** Lỗi mạng / HTTPS ở tầng GeckoView (trang chưa tải được, chưa có mã HTTP). */
    fun describeNetworkError(error: WebRequestError): Pair<String, String> {
        return when (error.code) {
            WebRequestError.ERROR_UNKNOWN_HOST ->
                "Không tìm thấy máy chủ" to "Không phân giải được tên miền. Kiểm tra lại địa chỉ hoặc kết nối mạng."
            WebRequestError.ERROR_CONNECTION_REFUSED ->
                "Máy chủ từ chối kết nối" to "Máy chủ không nhận kết nối. Có thể trang đang tắt hoặc sai cổng."
            WebRequestError.ERROR_NET_TIMEOUT ->
                "Hết thời gian chờ" to "Máy chủ phản hồi quá chậm. Hãy thử lại."
            WebRequestError.ERROR_OFFLINE ->
                "Không có kết nối mạng" to "Thiết bị đang ngoại tuyến. Hãy bật Wi-Fi hoặc dữ liệu di động."
            WebRequestError.ERROR_SECURITY_BAD_CERT ->
                "Chứng chỉ HTTPS không hợp lệ" to "Kết nối an toàn không thể xác minh. Không nên nhập thông tin cá nhân vào trang này."
            WebRequestError.ERROR_SECURITY_SSL ->
                "Lỗi kết nối bảo mật (HTTPS)" to "Không thể thiết lập kết nối mã hoá với máy chủ."
            WebRequestError.ERROR_MALFORMED_URI ->
                "Địa chỉ không hợp lệ" to "Địa chỉ (URL) sai định dạng. Hãy kiểm tra lại."
            WebRequestError.ERROR_REDIRECT_LOOP ->
                "Chuyển hướng quá nhiều lần" to "Trang bị lặp vô hạn khi chuyển hướng. Thử xoá cookie của trang."
            WebRequestError.ERROR_PORT_BLOCKED ->
                "Cổng bị chặn" to "Cổng kết nối này bị chặn vì lý do an toàn."
            else -> when (error.category) {
                WebRequestError.ERROR_CATEGORY_NETWORK ->
                    "Lỗi mạng" to "Không kết nối được tới máy chủ. Kiểm tra mạng rồi thử lại."
                WebRequestError.ERROR_CATEGORY_SECURITY ->
                    "Lỗi bảo mật (HTTPS)" to "Kết nối an toàn tới trang này không thành công."
                WebRequestError.ERROR_CATEGORY_URI ->
                    "Địa chỉ không hợp lệ" to "Không mở được địa chỉ này."
                WebRequestError.ERROR_CATEGORY_CONTENT ->
                    "Nội dung lỗi" to "Nội dung trang bị hỏng hoặc không được hỗ trợ."
                WebRequestError.ERROR_CATEGORY_PROXY ->
                    "Lỗi proxy" to "Không kết nối được qua máy chủ proxy."
                WebRequestError.ERROR_CATEGORY_SAFEBROWSING ->
                    "Trang không an toàn" to "Trang này bị chặn vì có thể chứa nội dung nguy hiểm."
                else ->
                    "Không thể tải trang" to "Đã xảy ra lỗi khi tải trang này."
            }
        }
    }
}
