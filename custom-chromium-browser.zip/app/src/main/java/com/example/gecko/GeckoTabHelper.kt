package com.example.gecko

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import com.example.data.local.SitePermissionStore
import com.example.data.local.SitePolicyStore
import com.example.util.AppLogger
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.ContentBlockingController
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebRequestError
import java.net.URLEncoder
import java.util.Collections
import java.util.UUID
import java.util.WeakHashMap

class GeckoTabHelper(
    private val context: Context,
    private val sitePermissionStore: SitePermissionStore,
    private val sitePolicyStore: com.example.data.local.SitePolicyStore,
    private val onTabUpdate: (tabId: String, updater: (BrowserTab) -> BrowserTab) -> Unit,
    private val onPageVisited: (title: String, url: String) -> Unit,
    private val isHostBlocked: (host: String) -> Boolean,
    private val onBlockedUrl: (host: String) -> Unit,
    private val isPopupAllowed: (host: String) -> Boolean,
    private val onBlockedPopup: (host: String) -> Unit,
    private val onPopupTabCreated: (BrowserTab) -> Unit,
    private val getCurrentTab: (tabId: String) -> BrowserTab?,
    private val isActiveTab: (tabId: String) -> Boolean,
    private val onTrackerBlocked: (tabId: String) -> Unit,
    private val onPopupBlocked: (tabId: String) -> Unit,
    private val onPageResetStats: (tabId: String) -> Unit,
    private val onDownload: (org.mozilla.geckoview.WebResponse) -> Unit,
    private val onShowPrompt: (PagePrompt) -> Unit,
    private val onClearPrompt: () -> Unit,
    private val onShowPermissionPrompt: (PermissionPrompt) -> Unit,
    private val onClearPermissionPrompt: () -> Unit,
    private val onContextMenuRequested: (tabId: String, linkUri: String?, srcUri: String?, type: Int) -> Unit,
    private val onExternalAppOpened: () -> Unit,
    private val onFullScreenChange: (tabId: String, fullScreen: Boolean) -> Unit,
    private val onSessionLost: (tabId: String) -> Unit,
    private val onMediaEvent: (AuraMediaEvent) -> Unit = {},
    private val onPageStartNavigation: (tabId: String, newUrl: String) -> Unit = { _, _ -> },
    private val onTabLocationChanged: (tabId: String, newUrl: String) -> Unit = { _, _ -> }
) {
    fun createSession(initialUrl: String? = null, isPrivate: Boolean = false): BrowserTab {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(isPrivate)
            .build()
        val session = GeckoSession(settings)
        val tabId = UUID.randomUUID().toString()
        val isStart = initialUrl.isNullOrBlank()

        val tab = BrowserTab(
            id = tabId,
            title = if (isStart) "New Tab" else initialUrl!!,
            url = initialUrl ?: "",
            isStartPage = isStart,
            session = session,
            lastAccessedAt = System.currentTimeMillis(),
            isPrivate = isPrivate
        )

        setupDelegates(session, tabId)

        // Lazy open: Tab created without URL is NOT opened immediately.
        // It will only be opened when loading a URL for the first time or becoming active.
        if (!initialUrl.isNullOrBlank()) {
            val runtime = GeckoEngine.getRuntime(context)
            session.open(runtime)
            session.loadUri(initialUrl)
        }

        return tab
    }

    fun restoreSession(tab: BrowserTab): GeckoSession {
        val runtime = GeckoEngine.getRuntime(context)
        val settingsBuilder = GeckoSessionSettings.Builder()
            .usePrivateMode(tab.isPrivate)
        if (tab.isDesktopMode) {
            settingsBuilder
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
        }
        val session = GeckoSession(settingsBuilder.build())

        setupDelegates(session, tab.id)
        session.open(runtime)
        GeckoEngine.attachSessionMessageDelegate(session, tab.id)

        if (tab.sessionState != null) {
            try {
                session.restoreState(tab.sessionState)
            } catch (e: Exception) {
                AppLogger.d("AuraBrowser", "restoreState failed for tab ${tab.id}: ${e.message}, fallback to loadUri")
                if (tab.url.isNotBlank() && !tab.isStartPage) {
                    session.loadUri(tab.url)
                }
            }
        } else if (tab.url.isNotBlank() && !tab.isStartPage) {
            session.loadUri(tab.url)
        }

        return session
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val popupSessions: MutableSet<GeckoSession> =
        Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap<GeckoSession, Boolean>()))

    private fun createPopupTab(initialUrl: String? = null, isPrivate: Boolean = false): BrowserTab {
        val settings = GeckoSessionSettings.Builder()
            .usePrivateMode(isPrivate)
            .build()
        val popupSession = GeckoSession(settings)
        popupSessions.add(popupSession)
        val tabId = UUID.randomUUID().toString()
        val isStart = initialUrl.isNullOrBlank()

        val tab = BrowserTab(
            id = tabId,
            title = if (isStart) "New Tab" else initialUrl!!,
            url = initialUrl ?: "",
            isStartPage = isStart,
            session = popupSession,
            lastAccessedAt = System.currentTimeMillis(),
            isPrivate = isPrivate
        )

        setupDelegates(popupSession, tabId)
        return tab
    }

    fun isPopupSession(session: GeckoSession?): Boolean {
        return session != null && popupSessions.contains(session)
    }

    fun ensureSessionOpen(session: GeckoSession) {
        if (popupSessions.contains(session)) {
            return
        }
        if (!session.isOpen) {
            val runtime = GeckoEngine.getRuntime(context)
            session.open(runtime)
        }
    }

    fun setSessionActive(tab: BrowserTab?, active: Boolean) {
        val session = tab?.session ?: return
        try {
            if (active && !popupSessions.contains(session)) {
                ensureSessionOpen(session)
            }
            if (session.isOpen) {
                session.setActive(active)
            }
        } catch (_: Exception) {
        }
    }

    private fun setupDelegates(session: GeckoSession, tabId: String) {
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: List<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                val cleanUrl = url ?: ""
                val isBlankLocation = cleanUrl.isBlank() || cleanUrl == "about:blank"
                if (isBlankLocation) {
                    return
                }

                onTabUpdate(tabId) { current ->
                    current.copy(
                        url = cleanUrl,
                        isStartPage = false,
                        lastAccessedAt = System.currentTimeMillis()
                    )
                }
                onTabLocationChanged(tabId, cleanUrl)
            }

            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                onTabUpdate(tabId) { current -> current.copy(canGoBack = canGoBack) }
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                onTabUpdate(tabId) { current -> current.copy(canGoForward = canGoForward) }
            }

            override fun onLoadRequest(
                session: GeckoSession,
                request: GeckoSession.NavigationDelegate.LoadRequest
            ): GeckoResult<AllowOrDeny>? {
                val uri = request.uri
                val lower = uri.lowercase()

                // 1. Các scheme nội bộ Gecko/web cho phép trực tiếp
                if (lower.startsWith("about:") || lower.startsWith("chrome:") ||
                    lower.startsWith("resource:") || lower.startsWith("data:") ||
                    lower.startsWith("blob:") || lower.startsWith("file:") ||
                    lower.startsWith("javascript:") || lower.startsWith("view-source:")
                ) {
                    return GeckoResult.fromValue(AllowOrDeny.ALLOW)
                }

                // 2. Các scheme ứng dụng thông dụng (tel, sms, mailto, geo, market)
                if (lower.startsWith("tel:") || lower.startsWith("sms:") ||
                    lower.startsWith("smsto:") || lower.startsWith("mailto:") ||
                    lower.startsWith("geo:") || lower.startsWith("market:")
                ) {
                    if (request.hasUserGesture) {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                            onExternalAppOpened()
                        } catch (_: Exception) {}
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }

                // 3. Scheme intent://
                if (lower.startsWith("intent:")) {
                    if (request.hasUserGesture) {
                        try {
                            val parsedIntent = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME).apply {
                                flags = 0
                                component = null
                                selector = null
                                addCategory(Intent.CATEGORY_BROWSABLE)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            if (parsedIntent.resolveActivity(context.packageManager) != null) {
                                context.startActivity(parsedIntent)
                                onExternalAppOpened()
                            } else {
                                val fallback = parsedIntent.getStringExtra("browser_fallback_url")
                                if (!fallback.isNullOrBlank() && (fallback.startsWith("http://") || fallback.startsWith("https://"))) {
                                    getCurrentTab(tabId)?.let { tab -> loadUri(tab, fallback) }
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }

                // 4. Các scheme app tuỳ ý khác (không phải http / https)
                if (!lower.startsWith("http://") && !lower.startsWith("https://")) {
                    if (lower.startsWith("content:") || lower.startsWith("android-app:")) {
                        return GeckoResult.fromValue(AllowOrDeny.DENY)
                    }
                    if (request.hasUserGesture) {
                        try {
                            val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            if (appIntent.resolveActivity(context.packageManager) != null) {
                                context.startActivity(appIntent)
                                onExternalAppOpened()
                            }
                        } catch (_: Exception) {}
                    }
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }

                // 5. HTTP / HTTPS: Kiểm tra danh sách đen chặn trang
                val host = SitePolicyStore.normalizeHost(uri)
                if (isHostBlocked(host)) {
                    onBlockedUrl(host)
                    return GeckoResult.fromValue(AllowOrDeny.DENY)
                }

                return GeckoResult.fromValue(AllowOrDeny.ALLOW)
            }

            override fun onLoadError(
                session: GeckoSession,
                uri: String?,
                error: WebRequestError
            ): GeckoResult<String>? {
                AppLogger.d("AuraBrowser", "onLoadError: tabId=$tabId, uri=$uri, error=$error")
                val displayUri = TextUtils.htmlEncode(uri ?: "")
                val html = """
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>
                    body { font-family: -apple-system, Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 85vh; margin: 0; padding: 24px; text-align: center; background: #ffffff; color: #202124; }
                    h2 { margin-bottom: 8px; color: #d93025; font-size: 20px; }
                    p { color: #5f6368; font-size: 14px; margin-bottom: 24px; word-break: break-all; max-width: 90%; }
                    button { background: #1a73e8; color: white; border: none; padding: 12px 28px; border-radius: 24px; font-size: 15px; font-weight: 500; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,0.12); }
                    button:active { background: #174ea6; }
                    </style>
                    </head>
                    <body>
                    <h2>Không thể tải trang</h2>
                    <p>Đã xảy ra lỗi khi tải: $displayUri</p>
                    <button onclick="location.reload()">Thử lại</button>
                    </body>
                    </html>
                """.trimIndent()
                val dataUri = "data:text/html;charset=utf-8," + URLEncoder.encode(html, "UTF-8")
                return GeckoResult.fromValue(dataUri)
            }

            override fun onNewSession(
                session: GeckoSession,
                uri: String
            ): GeckoResult<GeckoSession>? {
                val currentTab = getCurrentTab(tabId)
                val currentHost = SitePolicyStore.normalizeHost(currentTab?.url ?: "")

                return if (isPopupAllowed(currentHost)) {
                    try {
                        val popupTab = createPopupTab(
                            initialUrl = uri,
                            isPrivate = currentTab?.isPrivate == true
                        )
                        val popupSession = popupTab.session
                        if (popupSession == null) {
                            AppLogger.d("AuraBrowser", "popup failed: tabId=${popupTab.id} (null session)")
                            return GeckoResult.fromValue(null)
                        }

                        // Chờ GeckoView tự mở session (kiểm tra mỗi 50ms trên main looper, tối đa 2 giây)
                        val startWait = System.currentTimeMillis()
                        val checkRunnable = object : Runnable {
                            override fun run() {
                                try {
                                    if (popupSession.isOpen) {
                                        AppLogger.d("AuraBrowser", "popup session opened: tabId=${popupTab.id}")
                                        onPopupTabCreated(popupTab)
                                    } else if (System.currentTimeMillis() - startWait < 2000L) {
                                        mainHandler.postDelayed(this, 50L)
                                    } else {
                                        popupSessions.remove(popupSession)
                                        AppLogger.d("AuraBrowser", "popup failed: tabId=${popupTab.id} (timeout waiting for session.isOpen)")
                                    }
                                } catch (e: Exception) {
                                    popupSessions.remove(popupSession)
                                    AppLogger.d("AuraBrowser", "popup failed: tabId=${popupTab.id} (${e.message})")
                                }
                            }
                        }
                        mainHandler.postDelayed(checkRunnable, 50L)

                        GeckoResult.fromValue(popupSession)
                    } catch (e: Exception) {
                        AppLogger.d("AuraBrowser", "popup failed: fromTabId=$tabId (${e.message})")
                        GeckoResult.fromValue(null)
                    }
                } else {
                    val displayHost = currentHost.ifBlank { SitePolicyStore.normalizeHost(uri) }
                    onBlockedPopup(displayHost)
                    onPopupBlocked(tabId)
                    GeckoResult.fromValue(null)
                }
            }
        }

        session.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                AppLogger.d("AuraBrowser", "onPageStart: tabId=$tabId, url=$url")
                if (isActiveTab(tabId) && session.isOpen) {
                    session.setActive(true)
                }

                val isBlankLocation = url.isBlank() || url == "about:blank"
                if (isBlankLocation) {
                    return
                }

                // Reset per-tab protection stats for top-level page start
                onPageResetStats(tabId)
                onPageStartNavigation(tabId, url)

                onTabUpdate(tabId) { current ->
                    current.copy(
                        isLoading = true,
                        progress = 15,
                        url = url,
                        isSecure = false,
                        isStartPage = false,
                        lastAccessedAt = System.currentTimeMillis()
                    )
                }
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                val currentTab = getCurrentTab(tabId)
                if (currentTab != null) {
                    val shouldUpdate = progress == 0 || progress == 100 || (progress - currentTab.progress >= 5)
                    if (!shouldUpdate || currentTab.progress == progress) return
                }
                onTabUpdate(tabId) { current ->
                    // Throttle: chỉ cập nhật _tabs khi progress tăng ít nhất 5 điểm so với lần trước, hoặc ở giá trị 0 và 100
                    if (progress == 0 || progress == 100 || (progress - current.progress >= 5)) {
                        current.copy(
                            progress = progress,
                            isLoading = progress < 100
                        )
                    } else {
                        current
                    }
                }
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                AppLogger.d("AuraBrowser", "onPageStop: tabId=$tabId, success=$success")
                if (isActiveTab(tabId) && session.isOpen) {
                    session.setActive(true)
                }

                onTabUpdate(tabId) { current ->
                    current.copy(
                        isLoading = false,
                        progress = 100,
                        isStartPage = if (current.url.isBlank() || current.url == "about:blank") current.isStartPage else false
                    )
                }
            }

            override fun onSecurityChange(
                session: GeckoSession,
                securityInfo: GeckoSession.ProgressDelegate.SecurityInformation
            ) {
                val secure = securityInfo.isSecure
                onTabUpdate(tabId) { current -> current.copy(isSecure = secure) }
            }

            override fun onSessionStateChange(
                session: GeckoSession,
                sessionState: GeckoSession.SessionState
            ) {
                onTabUpdate(tabId) { current ->
                    current.copy(sessionState = sessionState)
                }
            }
        }

        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                val pageTitle = title?.takeIf { it.isNotBlank() } ?: "Page"
                onTabUpdate(tabId) { current ->
                    current.copy(title = pageTitle)
                }
            }

            override fun onCrash(session: GeckoSession) {
                AppLogger.d("AuraBrowser", "onCrash: tabId=$tabId")
                onSessionLost(tabId)
            }

            override fun onKill(session: GeckoSession) {
                AppLogger.d("AuraBrowser", "onKill: tabId=$tabId")
                onSessionLost(tabId)
            }

            override fun onExternalResponse(session: GeckoSession, response: org.mozilla.geckoview.WebResponse) {
                onDownload(response)
            }

            override fun onContextMenu(
                session: GeckoSession,
                screenX: Int,
                screenY: Int,
                element: GeckoSession.ContentDelegate.ContextElement
            ) {
                onContextMenuRequested(tabId, element.linkUri, element.srcUri, element.type)
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                onFullScreenChange(tabId, fullScreen)
            }
        }

        session.promptDelegate = AuraPromptDelegate(
            context = context,
            tabId = tabId,
            getTabUrl = { getCurrentTab(tabId)?.url ?: "" },
            onShowPrompt = onShowPrompt,
            onClearPrompt = onClearPrompt
        )

        session.permissionDelegate = AuraPermissionDelegate(
            tabId = tabId,
            sitePermissionStore = sitePermissionStore,
            sitePolicyStore = sitePolicyStore,
            getTabUrl = { getCurrentTab(tabId)?.url ?: "" },
            onShowPermissionPrompt = onShowPermissionPrompt,
            onClearPermissionPrompt = onClearPermissionPrompt
        )

        session.setMediaSessionDelegate(
            AuraMediaDelegate(
                tabId = tabId,
                onMediaEvent = onMediaEvent
            )
        )

        GeckoEngine.attachSessionMessageDelegate(session, tabId)

        session.contentBlockingDelegate = object : ContentBlocking.Delegate {
            override fun onContentBlocked(
                session: GeckoSession,
                event: ContentBlocking.BlockEvent
            ) {
                if (event.isBlocking) {
                    onTrackerBlocked(tabId)
                }
            }
        }

        session.historyDelegate = object : GeckoSession.HistoryDelegate {
            override fun onVisited(
                session: GeckoSession,
                url: String,
                lastVisitedURL: String?,
                flags: Int
            ): GeckoResult<Boolean>? {
                val isTopLevel = (flags and GeckoSession.HistoryDelegate.VISIT_TOP_LEVEL) != 0
                val isRedirectSource = (flags and GeckoSession.HistoryDelegate.VISIT_REDIRECT_SOURCE) != 0 ||
                        (flags and GeckoSession.HistoryDelegate.VISIT_REDIRECT_SOURCE_PERMANENT) != 0
                val isHttp = url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)

                if (isTopLevel && !isRedirectSource && isHttp) {
                    val currentTab = getCurrentTab(tabId)
                    if (currentTab?.isPrivate != true) {
                        val title = currentTab?.title?.takeIf { it.isNotBlank() && it != "New Tab" } ?: url
                        onPageVisited(title, url)
                    }
                }
                return GeckoResult.fromValue(true)
            }
        }
    }

    fun refreshContentBlockingLog(tab: BrowserTab, onResult: (Int) -> Unit) {
        val session = tab.session ?: return
        if (!session.isOpen) return
        try {
            ContentBlockingController().getLog(session).accept({ logEntries ->
                if (logEntries != null) {
                    var totalBlocked = 0
                    for (entry in logEntries) {
                        for (data in entry.blockingData) {
                            if (data.blocked) {
                                totalBlocked += data.count
                            }
                        }
                    }
                    onResult(totalBlocked)
                }
            }, {
                // ignore
            })
        } catch (_: Exception) {
        }
    }

    fun loadUri(tab: BrowserTab, uri: String) {
        if (uri.isNotBlank()) {
            val session = tab.session ?: return
            ensureSessionOpen(session)
            session.loadUri(uri)
        }
    }

    fun reload(tab: BrowserTab) {
        val session = tab.session ?: return
        ensureSessionOpen(session)
        session.reload()
    }

    fun stop(tab: BrowserTab) {
        tab.session?.stop()
    }

    fun goBack(tab: BrowserTab): Boolean {
        if (tab.canGoBack) {
            tab.session?.goBack()
            return true
        }
        return false
    }

    fun goForward(tab: BrowserTab): Boolean {
        if (tab.canGoForward) {
            tab.session?.goForward()
            return true
        }
        return false
    }

    fun toggleDesktopMode(tab: BrowserTab): Boolean {
        val session = tab.session ?: return tab.isDesktopMode
        ensureSessionOpen(session)
        val newMode = !tab.isDesktopMode
        session.settings.userAgentMode = if (newMode) {
            GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        } else {
            GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        }
        session.settings.viewportMode = if (newMode) {
            GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
        } else {
            GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        }
        session.reload()
        return newMode
    }

    fun closeTab(tab: BrowserTab) {
        try {
            tab.session?.close()
        } catch (_: Exception) {
        }
    }
}
