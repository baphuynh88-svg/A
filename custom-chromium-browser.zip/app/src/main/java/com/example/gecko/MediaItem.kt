package com.example.gecko

import androidx.compose.runtime.Immutable
import java.util.UUID

enum class MediaKind {
    VIDEO,
    AUDIO,
    HLS,
    DASH;

    companion object {
        fun fromRaw(raw: String?): MediaKind {
            return when (raw?.trim()?.lowercase()) {
                "audio" -> AUDIO
                "hls" -> HLS
                "dash" -> DASH
                else -> VIDEO
            }
        }
    }
}

@Immutable
data class MediaItem(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val kind: MediaKind,
    val pageUrl: String,
    val pageTitle: String,
    val isProtected: Boolean,
    val durationSec: Double,
    val sizeBytes: Long? = null
) {
    /**
     * Với mục isProtected = true (DRM / EME mediaKeys): vẫn lưu nhưng đánh dấu
     * không cho phép tải xuống (nội dung bảo vệ bản quyền).
     */
    val isDownloadAllowed: Boolean
        get() = !isProtected
}

data class SaviorMediaPayload(
    val tabId: String?,
    val url: String,
    val kind: MediaKind,
    val pageUrl: String,
    val pageTitle: String,
    val isProtected: Boolean,
    val durationSec: Double
)
