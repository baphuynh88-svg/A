package com.example.gecko

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import java.io.File
import com.example.data.local.SitePolicyStore
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PromptDelegate
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AlertPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ButtonPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ChoicePrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.FilePrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse
import org.mozilla.geckoview.GeckoSession.PromptDelegate.TextPrompt

/**
 * Xử lý các yêu cầu prompt từ GeckoView:
 * 1. Chọn file (input type=file) thông qua FilePickerBridge.
 * 2. Hộp thoại JavaScript/HTML: alert, confirm, prompt, thẻ <select> dropdown.
 */
class AuraPromptDelegate(
    private val context: Context,
    private val tabId: String,
    private val getTabUrl: () -> String,
    private val onShowPrompt: (PagePrompt) -> Unit,
    private val onClearPrompt: () -> Unit
) : PromptDelegate {

    override fun onFilePrompt(
        session: GeckoSession,
        prompt: FilePrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                FilePickerBridge.inProgress = false
                try {
                    result.complete(response)
                    AppLogger.flag("PICKER", "AuraPromptDelegate", "đã chuyển kết quả chọn file cho GeckoView")
                } catch (e: Exception) {
                    AppLogger.flag("PICKER", "AuraPromptDelegate", "chuyển kết quả cho GeckoView LỖI: ${e.message}")
                }
            }
        }

        val launcher = FilePickerBridge.launcher
        if (launcher == null) {
            AppLogger.flag("PICKER", "AuraPromptDelegate", "FilePickerBridge launcher chưa sẵn sàng (Activity chưa/không còn tồn tại)")
            completeOnce(prompt.dismiss())
            return result
        }

        // EXTRA_MIME_TYPES chỉ nhận MIME hợp lệ (có dấu '/'); đuôi file như ".lrc" phải đổi sang MIME hoặc bỏ
        val rawTypes = prompt.mimeTypes?.toList().orEmpty()
        val validTypes = rawTypes.mapNotNull { t ->
            val x = t.trim().lowercase()
            when {
                x.contains("/") -> x
                x.startsWith(".") -> android.webkit.MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(x.removePrefix("."))
                else -> null
            }
        }.distinct()

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            // Chỉ lọc khi MỌI mục đều đổi được sang MIME; nếu có đuôi lạ (.lrc) thì cho chọn tất cả để không ẩn mất file
            if (validTypes.isNotEmpty() && validTypes.size == rawTypes.size) {
                putExtra(Intent.EXTRA_MIME_TYPES, validTypes.toTypedArray())
            }
            if (prompt.type == FilePrompt.Type.MULTIPLE) {
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
        }
        AppLogger.flag("PICKER", "AuraPromptDelegate", "web yêu cầu mimeTypes=$rawTypes -> lọc=$validTypes, kiểu=${prompt.type}")

        FilePickerBridge.inProgress = true
        try {
            launcher(intent) { resultCode, data ->
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val picked = ArrayList<Uri>()
                    val clipData = data.clipData
                    if (clipData != null && clipData.itemCount > 0) {
                        for (i in 0 until clipData.itemCount) clipData.getItemAt(i).uri?.let { picked.add(it) }
                    } else {
                        data.data?.let { picked.add(it) }
                    }
                    AppLogger.flag("PICKER", "AuraPromptDelegate", "nhận ${picked.size} uri: ${picked.joinToString { it.toString() }}")
                    if (picked.isEmpty()) {
                        completeOnce(prompt.dismiss())
                    } else {
                        // Tự sao chép về cache (luồng nền) để chắc chắn đọc được và log được kích thước
                        Thread {
                            val files = picked.mapNotNull { copyPickedToCache(it) }
                            Handler(Looper.getMainLooper()).post {
                                if (files.isEmpty()) {
                                    AppLogger.flag("PICKER", "AuraPromptDelegate", "KHÔNG đọc được file đã chọn -> huỷ")
                                    completeOnce(prompt.dismiss())
                                } else {
                                    try {
                                        completeOnce(prompt.confirm(context, files.toTypedArray()))
                                    } catch (e: Exception) {
                                        AppLogger.flag("PICKER", "AuraPromptDelegate", "prompt.confirm LỖI: ${e.message}")
                                        completeOnce(prompt.dismiss())
                                    }
                                }
                            }
                        }.start()
                    }
                } else {
                    completeOnce(prompt.dismiss())
                }
            }
        } catch (e: Exception) {
            AppLogger.d("AuraPromptDelegate", "Lỗi mở bộ chọn file: ${e.message}")
            completeOnce(prompt.dismiss())
        }

        return result
    }

    /** Sao chép file đã chọn vào cache/picked/<id>/<tên gốc>; trả về Uri file:// hoặc null nếu lỗi. */
    private fun copyPickedToCache(uri: Uri): Uri? {
        return try {
            if (uri.scheme == "file") return uri
            val root = File(context.cacheDir, "picked")
            val limit = System.currentTimeMillis() - 24L * 60 * 60 * 1000
            root.listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }

            var name: String? = null
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
            } catch (_: Exception) {
            }
            val safe = (name ?: uri.lastPathSegment ?: "file").replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" }
            val dir = File(root, System.nanoTime().toString()).apply { mkdirs() }
            val out = File(dir, safe)
            val input = context.contentResolver.openInputStream(uri)
            if (input == null) {
                AppLogger.flag("PICKER", "AuraPromptDelegate", "openInputStream trả null: $uri")
                return null
            }
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            AppLogger.flag("PICKER", "AuraPromptDelegate", "đã sao chép '$safe' ${out.length()} byte")
            Uri.fromFile(out)
        } catch (e: Exception) {
            AppLogger.flag("PICKER", "AuraPromptDelegate", "sao chép file LỖI: ${e.javaClass.simpleName} ${e.message}")
            null
        }
    }

    override fun onAlertPrompt(
        session: GeckoSession,
        prompt: AlertPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val alertPrompt = PagePrompt.Alert(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Thông báo",
            message = prompt.message ?: "",
            onConfirm = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(alertPrompt)
        return result
    }

    override fun onButtonPrompt(
        session: GeckoSession,
        prompt: ButtonPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val confirmPrompt = PagePrompt.Confirm(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Xác nhận",
            message = prompt.message ?: "",
            onPositive = {
                completeOnce(prompt.confirm(ButtonPrompt.Type.POSITIVE))
                onClearPrompt()
            },
            onNegative = {
                completeOnce(prompt.confirm(ButtonPrompt.Type.NEGATIVE))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(confirmPrompt)
        return result
    }

    override fun onTextPrompt(
        session: GeckoSession,
        prompt: TextPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val textPrompt = PagePrompt.Text(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Nhập văn bản",
            message = prompt.message ?: "",
            defaultValue = prompt.defaultValue ?: "",
            onConfirm = { value ->
                completeOnce(prompt.confirm(value))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(textPrompt)
        return result
    }

    override fun onChoicePrompt(
        session: GeckoSession,
        prompt: ChoicePrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val validChoices = prompt.choices
            ?.filter { !it.disabled && !it.separator }
            ?.map {
                PagePrompt.ChoiceItem(
                    id = it.id,
                    label = it.label ?: it.id,
                    isSelected = it.selected
                )
            } ?: emptyList()

        val isMultiple = prompt.type == ChoicePrompt.Type.MULTIPLE
        val choicePrompt = PagePrompt.Choice(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Lựa chọn",
            message = prompt.message ?: "",
            isMultiple = isMultiple,
            choices = validChoices,
            onConfirmSingle = { selectedId ->
                completeOnce(prompt.confirm(selectedId))
                onClearPrompt()
            },
            onConfirmMultiple = { selectedIds ->
                completeOnce(prompt.confirm(selectedIds))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(choicePrompt)
        return result
    }

    private fun getDisplayHost(): String {
        val raw = getTabUrl()
        val host = SitePolicyStore.normalizeHost(raw)
        return host.ifBlank { "trang web" }
    }
}
