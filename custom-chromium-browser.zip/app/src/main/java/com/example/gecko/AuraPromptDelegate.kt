package com.example.gecko

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.SitePolicyStore
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PromptDelegate
import org.mozilla.geckoview.GeckoSession.PromptDelegate.AlertPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ButtonPrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.ChoicePrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.FilePrompt
import org.mozilla.geckoview.GeckoSession.PromptDelegate.PromptResponse
import org.mozilla.geckoview.GeckoSession.PromptDelegate.TextPrompt

/**
 * Xử lý các yêu cầu prompt từ GeckoView:
 * 1. Chọn file (input type=file) thông qua FilePickerBridge.
 * 2. Hộp thoại JavaScript/HTML: alert, confirm, prompt, thẻ <select> dropdown.
 */
class AuraPromptDelegate(
    private val context: Context,
    private val tabId: String,
    private val getTabUrl: () -> String,
    private val onShowPrompt: (PagePrompt) -> Unit,
    private val onClearPrompt: () -> Unit
) : PromptDelegate {

    override fun onFilePrompt(
        session: GeckoSession,
        prompt: FilePrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val launcher = FilePickerBridge.launcher
        if (launcher == null) {
            AppLogger.d("AuraPromptDelegate", "FilePickerBridge launcher chưa sẵn sàng")
            completeOnce(prompt.dismiss())
            return result
        }

        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            if (!prompt.mimeTypes.isNullOrEmpty()) {
                putExtra(Intent.EXTRA_MIME_TYPES, prompt.mimeTypes)
            }
            if (prompt.type == FilePrompt.Type.MULTIPLE) {
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
        }

        try {
            launcher(intent) { resultCode, data ->
                if (resultCode == Activity.RESULT_OK && data != null) {
                    val clipData = data.clipData
                    val singleUri: Uri? = data.data

                    if (clipData != null && clipData.itemCount > 0) {
                        val uris = Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                        completeOnce(prompt.confirm(context, uris))
                    } else if (singleUri != null) {
                        completeOnce(prompt.confirm(context, singleUri))
                    } else {
                        completeOnce(prompt.dismiss())
                    }
                } else {
                    completeOnce(prompt.dismiss())
                }
            }
        } catch (e: Exception) {
            AppLogger.d("AuraPromptDelegate", "Lỗi mở bộ chọn file: ${e.message}")
            completeOnce(prompt.dismiss())
        }

        return result
    }

    override fun onAlertPrompt(
        session: GeckoSession,
        prompt: AlertPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val alertPrompt = PagePrompt.Alert(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Thông báo",
            message = prompt.message ?: "",
            onConfirm = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(alertPrompt)
        return result
    }

    override fun onButtonPrompt(
        session: GeckoSession,
        prompt: ButtonPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val confirmPrompt = PagePrompt.Confirm(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Xác nhận",
            message = prompt.message ?: "",
            onPositive = {
                completeOnce(prompt.confirm(ButtonPrompt.Type.POSITIVE))
                onClearPrompt()
            },
            onNegative = {
                completeOnce(prompt.confirm(ButtonPrompt.Type.NEGATIVE))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(confirmPrompt)
        return result
    }

    override fun onTextPrompt(
        session: GeckoSession,
        prompt: TextPrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val textPrompt = PagePrompt.Text(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Nhập văn bản",
            message = prompt.message ?: "",
            defaultValue = prompt.defaultValue ?: "",
            onConfirm = { value ->
                completeOnce(prompt.confirm(value))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(textPrompt)
        return result
    }

    override fun onChoicePrompt(
        session: GeckoSession,
        prompt: ChoicePrompt
    ): GeckoResult<PromptResponse> {
        val result = GeckoResult<PromptResponse>()
        var isCompleted = false

        fun completeOnce(response: PromptResponse) {
            if (!isCompleted) {
                isCompleted = true
                result.complete(response)
            }
        }

        val host = getDisplayHost()
        val validChoices = prompt.choices
            ?.filter { !it.disabled && !it.separator }
            ?.map {
                PagePrompt.ChoiceItem(
                    id = it.id,
                    label = it.label ?: it.id,
                    isSelected = it.selected
                )
            } ?: emptyList()

        val isMultiple = prompt.type == ChoicePrompt.Type.MULTIPLE
        val choicePrompt = PagePrompt.Choice(
            tabId = tabId,
            host = host,
            title = prompt.title ?: "Lựa chọn",
            message = prompt.message ?: "",
            isMultiple = isMultiple,
            choices = validChoices,
            onConfirmSingle = { selectedId ->
                completeOnce(prompt.confirm(selectedId))
                onClearPrompt()
            },
            onConfirmMultiple = { selectedIds ->
                completeOnce(prompt.confirm(selectedIds))
                onClearPrompt()
            },
            onDismiss = {
                completeOnce(prompt.dismiss())
                onClearPrompt()
            }
        )

        onShowPrompt(choicePrompt)
        return result
    }

    private fun getDisplayHost(): String {
        val raw = getTabUrl()
        val host = SitePolicyStore.normalizeHost(raw)
        return host.ifBlank { "trang web" }
    }
}
