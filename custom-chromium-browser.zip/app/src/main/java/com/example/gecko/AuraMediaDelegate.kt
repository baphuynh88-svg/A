package com.example.gecko

import android.graphics.Bitmap
import android.os.SystemClock
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.MediaSession

data class MediaState(
    val tabId: String,
    val title: String = "",
    val artist: String = "",
    val artwork: Bitmap? = null,
    val isPlaying: Boolean = false,
    val mediaSession: MediaSession,
    val album: String = "",
    val features: Long = 0L,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val playbackRate: Float = 1.0f,
    val positionUpdatedAtElapsedMs: Long = SystemClock.elapsedRealtime()
) {
    fun currentPositionMs(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Long {
        val raw = if (isPlaying && positionUpdatedAtElapsedMs > 0L && nowElapsedMs > positionUpdatedAtElapsedMs) {
            positionMs + ((nowElapsedMs - positionUpdatedAtElapsedMs) * playbackRate).toLong()
        } else {
            positionMs
        }
        return if (durationMs > 0L) raw.coerceIn(0L, durationMs) else raw.coerceAtLeast(0L)
    }
}

sealed class AuraMediaEvent {
    data class Activated(val tabId: String, val mediaSession: MediaSession) : AuraMediaEvent()
    data class Deactivated(val tabId: String, val mediaSession: MediaSession) : AuraMediaEvent()
    data class MetadataChanged(
        val tabId: String,
        val mediaSession: MediaSession,
        val title: String,
        val artist: String,
        val album: String,
        val artwork: Bitmap?
    ) : AuraMediaEvent()
    data class FeaturesChanged(
        val tabId: String,
        val mediaSession: MediaSession,
        val features: Long
    ) : AuraMediaEvent()
    data class PositionStateChanged(
        val tabId: String,
        val mediaSession: MediaSession,
        val durationMs: Long,
        val positionMs: Long,
        val playbackRate: Float
    ) : AuraMediaEvent()
    data class Play(val tabId: String, val mediaSession: MediaSession) : AuraMediaEvent()
    data class Pause(val tabId: String, val mediaSession: MediaSession) : AuraMediaEvent()
    data class Stop(val tabId: String, val mediaSession: MediaSession) : AuraMediaEvent()
}

class AuraMediaDelegate(
    private val tabId: String,
    private val onMediaEvent: (AuraMediaEvent) -> Unit
) : MediaSession.Delegate {

    override fun onActivated(session: GeckoSession, mediaSession: MediaSession) {
        AppLogger.d("AuraMediaDelegate", "activated: tabId=$tabId")
        onMediaEvent(AuraMediaEvent.Activated(tabId, mediaSession))
    }

    override fun onDeactivated(session: GeckoSession, mediaSession: MediaSession) {
        AppLogger.d("AuraMediaDelegate", "deactivated: tabId=$tabId")
        onMediaEvent(AuraMediaEvent.Deactivated(tabId, mediaSession))
    }

    override fun onMetadata(
        session: GeckoSession,
        mediaSession: MediaSession,
        meta: MediaSession.Metadata
    ) {
        val title = meta.title ?: ""
        val artist = meta.artist ?: ""
        val album = meta.album ?: ""
        AppLogger.d("AuraMediaDelegate", "metadata: tabId=$tabId, title=$title, artist=$artist, album=$album")

        onMediaEvent(
            AuraMediaEvent.MetadataChanged(
                tabId = tabId,
                mediaSession = mediaSession,
                title = title,
                artist = artist,
                album = album,
                artwork = null
            )
        )

        try {
            meta.artwork?.getBitmap(256)?.accept({ bitmap ->
                if (bitmap != null) {
                    onMediaEvent(
                        AuraMediaEvent.MetadataChanged(
                            tabId = tabId,
                            mediaSession = mediaSession,
                            title = title,
                            artist = artist,
                            album = album,
                            artwork = bitmap
                        )
                    )
                }
            }, {
                // Lỗi lấy ảnh bìa thì bỏ qua
            })
        } catch (_: Exception) {
        }
    }

    override fun onFeatures(session: GeckoSession, mediaSession: MediaSession, features: Long) {
        AppLogger.d("AuraMediaDelegate", "features: tabId=$tabId, features=$features")
        onMediaEvent(AuraMediaEvent.FeaturesChanged(tabId, mediaSession, features))
    }

    override fun onPositionState(
        session: GeckoSession,
        mediaSession: MediaSession,
        state: MediaSession.PositionState
    ) {
        val durationMs = if (state.duration.isFinite() && state.duration > 0.0) {
            (state.duration * 1000.0).toLong()
        } else {
            0L
        }
        val positionMs = if (state.position.isFinite() && state.position >= 0.0) {
            (state.position * 1000.0).toLong()
        } else {
            0L
        }
        val playbackRate = if (state.playbackRate.isFinite() && state.playbackRate > 0.0) {
            state.playbackRate.toFloat()
        } else {
            1.0f
        }
        onMediaEvent(
            AuraMediaEvent.PositionStateChanged(
                tabId = tabId,
                mediaSession = mediaSession,
                durationMs = durationMs,
                positionMs = positionMs,
                playbackRate = playbackRate
            )
        )
    }

    override fun onPlay(session: GeckoSession, mediaSession: MediaSession) {
        AppLogger.d("AuraMediaDelegate", "play: tabId=$tabId")
        onMediaEvent(AuraMediaEvent.Play(tabId, mediaSession))
    }

    override fun onPause(session: GeckoSession, mediaSession: MediaSession) {
        AppLogger.d("AuraMediaDelegate", "pause: tabId=$tabId")
        onMediaEvent(AuraMediaEvent.Pause(tabId, mediaSession))
    }

    override fun onStop(session: GeckoSession, mediaSession: MediaSession) {
        AppLogger.d("AuraMediaDelegate", "stop: tabId=$tabId")
        onMediaEvent(AuraMediaEvent.Stop(tabId, mediaSession))
    }
}
