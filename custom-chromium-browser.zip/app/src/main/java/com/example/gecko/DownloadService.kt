package com.example.gecko

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.util.AppLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

enum class SaviorDownloadStatus {
    QUEUED,
    DOWNLOADING,
    EXTRACTING_AUDIO,
    MUXING
}

data class SaviorItemDownloadState(
    val itemId: String,
    val fileName: String,
    val audioOnly: Boolean,
    val status: SaviorDownloadStatus,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long? = null,
    val explicitProgressFraction: Float? = null
) {
    val progressFraction: Float?
        get() {
            if (explicitProgressFraction != null) {
                return explicitProgressFraction.coerceIn(0f, 1f)
            }
            val total = totalBytes
            return if (total != null && total > 0L) {
                (downloadedBytes.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            } else {
                null
            }
        }
}

private sealed class QueuedDownloadRequest(open val taskId: String) {
    data class DirectMedia(
        val item: MediaItem,
        val audioOnly: Boolean
    ) : QueuedDownloadRequest(item.id)

    data class YouTubeMedia(
        override val taskId: String,
        val pageUrl: String,
        val videoTitle: String,
        val option: YtOption
    ) : QueuedDownloadRequest(taskId)
}

class DownloadService : Service() {

    @Volatile
    private var isInForeground: Boolean = false

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                val targetItemId = intent.getStringExtra(EXTRA_ITEM_ID)
                if (!targetItemId.isNullOrBlank()) {
                    cancelDownload(this, targetItemId)
                } else {
                    cancelAllDownloads(this)
                }
            }
            ACTION_SYNC -> {
                refreshForegroundNotification()
            }
            else -> {
                refreshForegroundNotification()
            }
        }
        return START_NOT_STICKY
    }

    internal fun refreshForegroundNotification() {
        val states = _downloadStates.value.values.toList()
        if (states.isEmpty()) {
            if (!isInForeground) {
                val fallback = buildSummaryProgressNotification(this, emptyList())
                tryStartForeground(fallback)
            }
            stopForegroundAndSelf()
            return
        }

        val notification = buildSummaryProgressNotification(this, states)
        if (!isInForeground) {
            tryStartForeground(notification)
        } else {
            postNotification(this, FOREGROUND_NOTIFICATION_ID, notification)
        }
    }

    private fun tryStartForeground(notification: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    FOREGROUND_NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                )
            } else {
                startForeground(FOREGROUND_NOTIFICATION_ID, notification)
            }
            isInForeground = true
            true
        } catch (e: Exception) {
            AppLogger.d("DownloadService", "startForeground fallback to normal notification: ${e.message}")
            postNotification(this, FOREGROUND_NOTIFICATION_ID, notification)
            false
        }
    }

    @Suppress("DEPRECATION")
    internal fun stopForegroundAndSelf() {
        isInForeground = false
        try {
            stopForeground(true)
        } catch (_: Exception) {}
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(FOREGROUND_NOTIFICATION_ID)
        } catch (_: Exception) {}
        try {
            stopSelf()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        isInForeground = false
        if (activeInstance === this) {
            activeInstance = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "savior_downloads"
        const val FOREGROUND_NOTIFICATION_ID = 3001
        const val MAX_CONCURRENT_DOWNLOADS = 2

        const val ACTION_SYNC = "com.example.gecko.action.SAVIOR_DOWNLOAD_SYNC"
        const val ACTION_CANCEL = "com.example.gecko.action.SAVIOR_DOWNLOAD_CANCEL"
        const val EXTRA_ITEM_ID = "extra_savior_item_id"

        private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        private val queueLock = Any()
        private val pendingQueue = ConcurrentLinkedQueue<QueuedDownloadRequest>()
        private val activeJobs = ConcurrentHashMap<String, Job>()
        private val completionNotificationCounter = AtomicInteger(3100)

        private val _downloadStates = MutableStateFlow<Map<String, SaviorItemDownloadState>>(emptyMap())
        val downloadStates: StateFlow<Map<String, SaviorItemDownloadState>> = _downloadStates.asStateFlow()

        @Volatile
        private var activeInstance: DownloadService? = null

        @Volatile
        var onDownloadCompleted: ((DownloadedMediaFile) -> Unit)? = null

        @Volatile
        var onDownloadError: ((String) -> Unit)? = null

        @Volatile
        var onAudioExtractionFailed: ((MediaItem, AudioExtractionFallback) -> Unit)? = null

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "Tải xuống Savior",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "Tiến trình và kết quả tải video/âm thanh từ Savior"
                        setShowBadge(false)
                    }
                    nm.createNotificationChannel(channel)
                }
            }
        }

        fun enqueueDownload(context: Context, item: MediaItem, audioOnly: Boolean) {
            val appContext = context.applicationContext
            if (item.isProtected) {
                onDownloadError?.invoke("Nội dung được bảo vệ, không thể tải")
                return
            }

            synchronized(queueLock) {
                if (_downloadStates.value.containsKey(item.id)) {
                    return
                }
                val ext = if (audioOnly && item.kind != MediaKind.AUDIO) {
                    "m4a"
                } else {
                    MediaDownloader.resolveExtension(item.url, null, item.kind)
                }
                val baseTitle = MediaDownloader.sanitizeBaseTitle(item.pageTitle, item.url)
                val initialName = "$baseTitle.$ext"

                _downloadStates.update { map ->
                    map + (
                        item.id to SaviorItemDownloadState(
                            itemId = item.id,
                            fileName = initialName,
                            audioOnly = audioOnly,
                            status = SaviorDownloadStatus.QUEUED,
                            downloadedBytes = 0L,
                            totalBytes = item.sizeBytes
                        )
                    )
                }
                pendingQueue.add(QueuedDownloadRequest.DirectMedia(item = item, audioOnly = audioOnly))
            }

            startOrUpdateService(appContext)
            pumpQueue(appContext)
        }

        fun enqueueYouTubeDownload(
            context: Context,
            pageUrl: String,
            videoTitle: String,
            option: YtOption
        ): String {
            val appContext = context.applicationContext
            val videoId = YouTubeExtractorRepo.extractVideoId(pageUrl) ?: pageUrl.hashCode().toString()
            val taskId = "yt_${videoId}_${option.id}"

            synchronized(queueLock) {
                if (_downloadStates.value.containsKey(taskId)) {
                    return taskId
                }
                val (finalExt, _) = YtDownloader.resolveFinalExtAndMime(option)
                val baseTitleWithTag = YtDownloader.buildBaseTitleWithLabel(videoTitle, pageUrl, option.label)
                val initialName = "$baseTitleWithTag.$finalExt"

                _downloadStates.update { map ->
                    map + (
                        taskId to SaviorItemDownloadState(
                            itemId = taskId,
                            fileName = initialName,
                            audioOnly = option.kind == MediaKind.AUDIO,
                            status = SaviorDownloadStatus.QUEUED,
                            downloadedBytes = 0L,
                            totalBytes = option.sizeBytes,
                            explicitProgressFraction = if (option.sizeBytes != null) 0f else null
                        )
                    )
                }
                pendingQueue.add(
                    QueuedDownloadRequest.YouTubeMedia(
                        taskId = taskId,
                        pageUrl = pageUrl,
                        videoTitle = videoTitle,
                        option = option
                    )
                )
            }

            startOrUpdateService(appContext)
            pumpQueue(appContext)
            return taskId
        }

        fun cancelDownload(context: Context, itemId: String) {
            val appContext = context.applicationContext
            synchronized(queueLock) {
                val iterator = pendingQueue.iterator()
                while (iterator.hasNext()) {
                    if (iterator.next().taskId == itemId) {
                        iterator.remove()
                    }
                }
                activeJobs.remove(itemId)?.cancel()
                _downloadStates.update { it - itemId }
            }
            AppLogger.d("DownloadService", "Đã huỷ tải itemId=$itemId")
            notifyOrStopService(appContext)
            pumpQueue(appContext)
        }

        fun cancelAllDownloads(context: Context) {
            val appContext = context.applicationContext
            synchronized(queueLock) {
                pendingQueue.clear()
                activeJobs.values.forEach { it.cancel() }
                activeJobs.clear()
                _downloadStates.value = emptyMap()
            }
            notifyOrStopService(appContext)
        }

        private fun pumpQueue(context: Context) {
            val appContext = context.applicationContext
            while (true) {
                val nextRequest: QueuedDownloadRequest = synchronized(queueLock) {
                    if (activeJobs.size >= MAX_CONCURRENT_DOWNLOADS) {
                        return
                    }
                    val polled = pendingQueue.poll() ?: return
                    if (!_downloadStates.value.containsKey(polled.taskId)) {
                        return@synchronized null
                    }
                    polled
                } ?: continue

                val taskId = nextRequest.taskId

                val job = serviceScope.launch {
                    try {
                        _downloadStates.update { map ->
                            val current = map[taskId] ?: return@update map
                            map + (taskId to current.copy(status = SaviorDownloadStatus.DOWNLOADING))
                        }
                        notifyOrStopService(appContext)

                        var lastNotificationUpdateAt = 0L
                        val progressFlow = when (nextRequest) {
                            is QueuedDownloadRequest.DirectMedia -> {
                                MediaDownloader.downloadMedia(appContext, nextRequest.item, nextRequest.audioOnly)
                            }
                            is QueuedDownloadRequest.YouTubeMedia -> {
                                YtDownloader.downloadYouTube(
                                    context = appContext,
                                    pageUrl = nextRequest.pageUrl,
                                    videoTitle = nextRequest.videoTitle,
                                    initialOption = nextRequest.option
                                )
                            }
                        }

                        progressFlow.collect { progress ->
                            val status = when {
                                progress.isMuxing -> SaviorDownloadStatus.MUXING
                                progress.isExtractingAudio -> SaviorDownloadStatus.EXTRACTING_AUDIO
                                else -> SaviorDownloadStatus.DOWNLOADING
                            }
                            _downloadStates.update { map ->
                                val current = map[taskId] ?: return@update map
                                map + (
                                    taskId to current.copy(
                                        fileName = progress.fileName.ifBlank { current.fileName },
                                        status = status,
                                        downloadedBytes = progress.downloaded,
                                        totalBytes = progress.total ?: current.totalBytes,
                                        explicitProgressFraction = progress.progressFraction
                                    )
                                )
                            }

                            val now = System.currentTimeMillis()
                            if (now - lastNotificationUpdateAt >= 300L || progress.isExtractingAudio || progress.isMuxing) {
                                lastNotificationUpdateAt = now
                                notifyOrStopService(appContext)
                            }

                            if (progress.completedFile != null) {
                                val done = progress.completedFile
                                AppLogger.d("DownloadService", "Đã tải xong: ${done.fileName}, uri=${done.uri}")
                                postCompletedNotification(appContext, done)
                                onDownloadCompleted?.invoke(done)
                            }

                            if (progress.audioExtractionFallback != null && nextRequest is QueuedDownloadRequest.DirectMedia) {
                                val fallback = progress.audioExtractionFallback
                                AppLogger.d("DownloadService", "Không tách được âm thanh cho ${nextRequest.item.url}, hỏi lưu cả video")
                                onAudioExtractionFailed?.invoke(nextRequest.item, fallback)
                            }
                        }
                    } catch (_: CancellationException) {
                        // Đã xoá file dở/tạm trong MediaDownloader / YtDownloader
                    } catch (e: YtDownloader.UnsupportedMuxCodecException) {
                        AppLogger.d("DownloadService", "Lỗi ghép codec ($taskId): ${e.message}")
                        onDownloadError?.invoke(e.message ?: YtDownloader.UNSUPPORTED_MUX_MESSAGE)
                    } catch (e: Exception) {
                        AppLogger.d("DownloadService", "Lỗi tải ($taskId): ${e.message}")
                        val msg = e.message ?: "Không thể tải file"
                        if (msg.startsWith("Không đủ bộ nhớ") || msg.startsWith("Định dạng này")) {
                            onDownloadError?.invoke(msg)
                        } else {
                            onDownloadError?.invoke("Tải lỗi: $msg")
                        }
                    } finally {
                        synchronized(queueLock) {
                            activeJobs.remove(taskId)
                            _downloadStates.update { it - taskId }
                        }
                        notifyOrStopService(appContext)
                        pumpQueue(appContext)
                    }
                }

                synchronized(queueLock) {
                    if (_downloadStates.value.containsKey(taskId)) {
                        activeJobs[taskId] = job
                    } else {
                        job.cancel()
                    }
                }
            }
        }

        private fun startOrUpdateService(context: Context) {
            val appContext = context.applicationContext
            val instance = activeInstance
            if (instance != null) {
                instance.refreshForegroundNotification()
                return
            }
            val intent = Intent(appContext, DownloadService::class.java).apply {
                action = ACTION_SYNC
            }
            try {
                ContextCompat.startForegroundService(appContext, intent)
            } catch (e: Exception) {
                AppLogger.d("DownloadService", "startForegroundService failed in background: ${e.message}")
                ensureChannel(appContext)
                val states = _downloadStates.value.values.toList()
                if (states.isNotEmpty()) {
                    val notification = buildSummaryProgressNotification(appContext, states)
                    postNotification(appContext, FOREGROUND_NOTIFICATION_ID, notification)
                }
            }
        }

        private fun notifyOrStopService(context: Context) {
            val appContext = context.applicationContext
            val states = _downloadStates.value.values.toList()
            val instance = activeInstance
            if (states.isEmpty()) {
                if (instance != null) {
                    instance.stopForegroundAndSelf()
                } else {
                    try {
                        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                        nm.cancel(FOREGROUND_NOTIFICATION_ID)
                        appContext.stopService(Intent(appContext, DownloadService::class.java))
                    } catch (_: Exception) {}
                }
            } else {
                if (instance != null) {
                    instance.refreshForegroundNotification()
                } else {
                    startOrUpdateService(appContext)
                }
            }
        }

        internal fun postCompletedNotification(context: Context, completed: DownloadedMediaFile) {
            ensureChannel(context)
            val viewIntent = if (completed.uri != null) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(completed.uri, completed.mimeType)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                }
            }

            val reqCode = completionNotificationCounter.incrementAndGet()
            val pendingIntent = PendingIntent.getActivity(
                context,
                reqCode,
                viewIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Đã tải xong")
                .setContentText(completed.fileName)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()

            postNotification(context, reqCode, notification)
        }

        private fun buildSummaryProgressNotification(
            context: Context,
            states: List<SaviorItemDownloadState>
        ): Notification {
            ensureChannel(context)
            val primary = states.firstOrNull { it.status != SaviorDownloadStatus.QUEUED } ?: states.firstOrNull()
            val title = primary?.fileName ?: "Đang tải xuống..."

            val fraction = primary?.progressFraction
            val isIndeterminate = fraction == null ||
                primary.status == SaviorDownloadStatus.QUEUED ||
                primary.status == SaviorDownloadStatus.EXTRACTING_AUDIO
            val progressInt = ((fraction ?: 0f) * 100).toInt().coerceIn(0, 100)

            val statusLine = when {
                primary == null -> "Đang chuẩn bị tải..."
                primary.status == SaviorDownloadStatus.MUXING -> "Đang ghép video và âm thanh ($progressInt%)..."
                primary.status == SaviorDownloadStatus.EXTRACTING_AUDIO -> "Đang tách âm thanh (.m4a)..."
                primary.status == SaviorDownloadStatus.QUEUED -> "Đang chờ trong hàng đợi..."
                else -> {
                    val dlMb = String.format(Locale.US, "%.1f MB", primary.downloadedBytes / (1024.0 * 1024.0))
                    val totalMb = primary.totalBytes?.takeIf { it > 0L }?.let {
                        String.format(Locale.US, " / %.1f MB (%d%%)", it / (1024.0 * 1024.0), progressInt)
                    } ?: ""
                    val extraCount = if (states.size > 1) " (+${states.size - 1} mục)" else ""
                    "$dlMb$totalMb$extraCount"
                }
            }

            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context,
                300,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val cancelIntent = Intent(context, DownloadService::class.java).apply {
                action = ACTION_CANCEL
                if (primary != null) {
                    putExtra(EXTRA_ITEM_ID, primary.itemId)
                }
            }
            val cancelPendingIntent = PendingIntent.getService(
                context,
                301,
                cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setContentText(statusLine)
                .setContentIntent(contentPendingIntent)
                .setOnlyAlertOnce(true)
                .setOngoing(true)
                .setProgress(100, progressInt, isIndeterminate)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .addAction(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "Huỷ",
                    cancelPendingIntent
                )
                .build()
        }

        private fun postNotification(context: Context, id: Int, notification: Notification) {
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(id, notification)
            } catch (e: SecurityException) {
                AppLogger.d("DownloadService", "Không có quyền POST_NOTIFICATIONS: ${e.message}")
            } catch (e: Exception) {
                AppLogger.d("DownloadService", "Lỗi hiển thị thông báo: ${e.message}")
            }
        }
    }
}
