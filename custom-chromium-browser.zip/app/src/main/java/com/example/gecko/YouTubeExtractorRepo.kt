package com.example.gecko

import android.net.Uri
import com.example.util.AppLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.exceptions.AgeRestrictedContentException
import org.schabi.newpipe.extractor.exceptions.ContentNotAvailableException
import org.schabi.newpipe.extractor.exceptions.ContentNotSupportedException
import org.schabi.newpipe.extractor.exceptions.GeographicRestrictionException
import org.schabi.newpipe.extractor.exceptions.PaidContentException
import org.schabi.newpipe.extractor.exceptions.PrivateContentException
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.exceptions.YoutubeMusicPremiumContentException
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

data class YtMedia(
    val title: String,
    val durationSec: Long,
    val options: List<YtOption>
)

data class YtOption(
    val id: String,
    val label: String,
    val kind: MediaKind,
    val videoStream: VideoStream?,
    val audioStream: AudioStream?,
    val sizeBytes: Long?,
    val needsMux: Boolean,
    val ext: String
)

object YouTubeExtractorRepo {

    private const val TAG = "YouTubeExtractor"
    private const val CACHE_TTL_MS = 10 * 60 * 1000L // 10 phút

    private data class CachedEntry(
        val media: YtMedia,
        val timestampMs: Long
    )

    private val cacheByVideoId = ConcurrentHashMap<String, CachedEntry>()

    private val clenRegex = Regex("""(?:[?&]clen=|/clen/)(\d+)""")
    private val resolutionHeightRegex = Regex("""(\d{3,4})p""", RegexOption.IGNORE_CASE)
    private val resolutionFpsRegex = Regex("""\d{3,4}p(\d{2,3})""", RegexOption.IGNORE_CASE)
    private val youtubeIdRegex = Regex(
        """(?:v=|youtu\.be/|/shorts/|/embed/|/live/|/v/)([A-Za-z0-9_-]{11})"""
    )

    @Volatile
    private var isInitialized = false

    /**
     * Khởi tạo NewPipe.init(AuraDownloader, Localization("vi", "VN")) đúng 1 lần (lazy, thread-safe).
     */
    fun ensureInitialized() {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    NewPipe.init(AuraDownloader, Localization("vi", "VN"))
                    isInitialized = true
                    AppLogger.d(TAG, "Đã khởi tạo NewPipeExtractor với Localization(vi, VN)")
                }
            }
        }
    }

    /**
     * Trích xuất thông tin video/audio từ URL YouTube.
     * Nếu forceRefresh = true (ví dụ khi link cũ bị HTTP 403 hết hạn), bỏ qua cache và lấy link mới.
     */
    suspend fun load(url: String, forceRefresh: Boolean = false): Result<YtMedia> = withContext(Dispatchers.IO) {
        var canonicalUrl = url
        try {
            ensureInitialized()

            val preExtractedId = extractVideoId(url)
            canonicalUrl = if (!preExtractedId.isNullOrBlank()) {
                "https://www.youtube.com/watch?v=$preExtractedId"
            } else {
                url
            }

            if (!preExtractedId.isNullOrBlank()) {
                if (forceRefresh) {
                    cacheByVideoId.remove(preExtractedId)
                } else {
                    getFromCacheIfFresh(preExtractedId)?.let { cached ->
                        AppLogger.d(
                            TAG,
                            "Lấy từ cache YouTube videoId=$preExtractedId: ${cached.options.size} lựa chọn"
                        )
                        return@withContext Result.success(cached)
                    }
                }
            }

            AppLogger.d(TAG, "Trích xuất YouTube: url=$url, canonicalUrl=$canonicalUrl")
            val streamInfo = StreamInfo.getInfo(ServiceList.YouTube, canonicalUrl)

            // Kiểm tra video trực tiếp (live)
            if (isLiveStreamType(streamInfo.streamType)) {
                val msg = "Video đang phát trực tiếp (Live), không hỗ trợ tải xuống"
                AppLogger.d(TAG, "Lỗi trích xuất (url=$url, canonicalUrl=$canonicalUrl): $msg")
                return@withContext Result.failure(IllegalStateException(msg))
            }

            val resolvedVideoId = streamInfo.id.ifBlank { preExtractedId ?: "" }
            if (resolvedVideoId.isNotBlank()) {
                if (forceRefresh) {
                    cacheByVideoId.remove(resolvedVideoId)
                } else {
                    getFromCacheIfFresh(resolvedVideoId)?.let { cached ->
                        AppLogger.d(
                            TAG,
                            "Lấy từ cache YouTube videoId=$resolvedVideoId: ${cached.options.size} lựa chọn"
                        )
                        return@withContext Result.success(cached)
                    }
                }
            }

            val options = buildOptionsWithSizes(streamInfo)
            if (options.isEmpty()) {
                val msg = "Không tìm thấy luồng video hoặc âm thanh khả dụng"
                AppLogger.d(TAG, "Lỗi trích xuất (url=$url, canonicalUrl=$canonicalUrl): $msg")
                return@withContext Result.failure(IllegalStateException(msg))
            }

            val media = YtMedia(
                title = streamInfo.name?.trim().orEmpty().ifBlank { "YouTube Video" },
                durationSec = streamInfo.duration.coerceAtLeast(0L),
                options = options
            )

            if (resolvedVideoId.isNotBlank()) {
                cacheByVideoId[resolvedVideoId] = CachedEntry(
                    media = media,
                    timestampMs = System.currentTimeMillis()
                )
            }

            AppLogger.d(
                TAG,
                "Trích xuất thành công videoId=${resolvedVideoId.ifBlank { "?" }} (${media.title}): ${options.size} option (${options.joinToString { "${it.label}/${it.ext}" }})"
            )
            Result.success(media)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            val friendlyMsg = mapExceptionToVietnameseMessage(e)
            AppLogger.d(
                TAG,
                "Lỗi trích xuất YouTube (url=$url, canonicalUrl=$canonicalUrl): ${e.javaClass.simpleName}: ${e.message} -> \"$friendlyMsg\""
            )
            Result.failure(Exception(friendlyMsg, e))
        }
    }

    internal fun clearCacheForTesting() {
        cacheByVideoId.clear()
    }

    private fun getFromCacheIfFresh(videoId: String): YtMedia? {
        val entry = cacheByVideoId[videoId] ?: return null
        val ageMs = System.currentTimeMillis() - entry.timestampMs
        return if (ageMs in 0..CACHE_TTL_MS) {
            entry.media
        } else {
            cacheByVideoId.remove(videoId)
            null
        }
    }

    internal fun extractVideoId(url: String): String? {
        val trimmed = url.trim()
        if (trimmed.isBlank()) return null

        youtubeIdRegex.find(trimmed)?.groupValues?.getOrNull(1)?.takeIf { it.isNotBlank() }?.let {
            return it
        }

        return try {
            ensureInitialized()
            ServiceList.YouTube.streamLHFactory.getId(trimmed)?.takeIf { it.isNotBlank() }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * Nhận biết link video YouTube:
     * - host youtube.com / m.youtube.com / music.youtube.com với đường dẫn /watch?v= hoặc /shorts/<id>
     * - host youtu.be với đường dẫn youtu.be/<id>
     */
    fun isYouTubeVideoUrl(url: String?): Boolean {
        val trimmed = url?.trim().orEmpty()
        if (trimmed.isBlank()) return false
        if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            return false
        }

        return try {
            val uri = Uri.parse(trimmed)
            val rawHost = uri.host?.lowercase(Locale.ROOT)?.trimEnd('.').orEmpty()
            val host = rawHost.removePrefix("www.")
            val path = uri.path.orEmpty()

            when (host) {
                "youtube.com", "m.youtube.com", "music.youtube.com" -> {
                    when {
                        path == "/watch" || path.startsWith("/watch/") -> {
                            val vParam = try {
                                uri.getQueryParameter("v")
                            } catch (_: Throwable) {
                                null
                            }
                            !vParam.isNullOrBlank()
                        }
                        path.startsWith("/shorts/") -> {
                            val shortId = path.removePrefix("/shorts/").trim('/')
                            shortId.isNotBlank()
                        }
                        else -> false
                    }
                }
                "youtu.be" -> {
                    val videoId = path.trim('/')
                    videoId.isNotBlank()
                }
                else -> false
            }
        } catch (_: Throwable) {
            false
        }
    }

    internal fun extractOptionResolutionHeight(option: YtOption): Int {
        option.videoStream?.let { vs ->
            val h = resolveVideoHeight(vs)
            if (h > 0) return h
        }
        val match = resolutionHeightRegex.find(option.label)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    }

    /**
     * Mặc định chọn 720p, nếu không có thì chọn độ phân giải cao nhất không vượt 720p.
     */
    fun pickDefaultOptionId(options: List<YtOption>): String? {
        if (options.isEmpty()) return null
        val videoOptions = options.filter { it.kind == MediaKind.VIDEO }
        if (videoOptions.isEmpty()) {
            return options.first().id
        }

        val withHeight = videoOptions.map { it to extractOptionResolutionHeight(it) }

        // 1. Ưu tiên đúng 720p (nếu có cả 720p và 720p60 thì ưu tiên nhãn "720p" trước)
        val exact720 = withHeight
            .filter { (_, h) -> h == 720 }
            .sortedWith(compareBy<Pair<YtOption, Int>> { it.first.label.lowercase(Locale.ROOT) != "720p" })
            .firstOrNull()
        if (exact720 != null) {
            return exact720.first.id
        }

        // 2. Nếu không có 720p thì chọn độ phân giải cao nhất không vượt 720p
        val highestUnder720 = withHeight
            .filter { (_, h) -> h in 1..720 }
            .maxByOrNull { (_, h) -> h }
        if (highestUnder720 != null) {
            return highestUnder720.first.id
        }

        // 3. Nếu mọi luồng video đều > 720p thì chọn luồng video thấp nhất hoặc option đầu tiên
        val lowestVideo = withHeight
            .filter { (_, h) -> h > 0 }
            .minByOrNull { (_, h) -> h }
        return lowestVideo?.first?.id ?: videoOptions.first().id
    }

    private fun isLiveStreamType(streamType: StreamType?): Boolean {
        return streamType == StreamType.LIVE_STREAM ||
            streamType == StreamType.AUDIO_LIVE_STREAM
    }

    internal fun mapExceptionToVietnameseMessage(error: Throwable): String {
        val rawMsg = (error.message ?: "").lowercase(Locale.ROOT)
        return when {
            error is AgeRestrictedContentException ||
                rawMsg.contains("age-restricted") ||
                rawMsg.contains("confirm your age") ||
                rawMsg.contains("age restricted") -> {
                "Video bị giới hạn độ tuổi, không thể tải"
            }

            error is GeographicRestrictionException ||
                rawMsg.contains("not available in your country") ||
                rawMsg.contains("geographic") ||
                rawMsg.contains("geo-restricted") ||
                rawMsg.contains("blocked in your country") -> {
                "Video bị chặn tại khu vực của bạn"
            }

            error is PrivateContentException ||
                rawMsg.contains("private video") ||
                rawMsg.contains("video is private") -> {
                "Video ở chế độ riêng tư, không thể tải"
            }

            error is PaidContentException ||
                error is YoutubeMusicPremiumContentException ||
                rawMsg.contains("members-only") ||
                rawMsg.contains("music premium") -> {
                "Video yêu cầu gói hội viên hoặc trả phí, không thể tải"
            }

            rawMsg.contains("live stream") ||
                rawMsg.contains("livestream") ||
                rawMsg.contains("premieres in") -> {
                "Video đang phát trực tiếp (Live), không hỗ trợ tải xuống"
            }

            error is ContentNotSupportedException -> {
                "Định dạng video này chưa được hỗ trợ"
            }

            error is ContentNotAvailableException ||
                rawMsg.contains("video unavailable") ||
                rawMsg.contains("not available") ||
                rawMsg.contains("has been removed") -> {
                "Video không khả dụng hoặc đã bị xoá"
            }

            error is ReCaptchaException || error is IOException -> {
                "Không lấy được thông tin video, thử lại sau"
            }

            else -> {
                "Không lấy được thông tin video, thử lại sau"
            }
        }
    }

    private data class CandidateVideo(
        val stream: VideoStream,
        val height: Int,
        val fps: Int,
        val label: String,
        val isH264Mp4: Boolean,
        val isVp9Webm: Boolean,
        val needsMux: Boolean,
        val pairedAudio: AudioStream?,
        val ext: String
    )

    private data class PendingOption(
        val id: String,
        val label: String,
        val kind: MediaKind,
        val videoStream: VideoStream?,
        val audioStream: AudioStream?,
        val needsMux: Boolean,
        val ext: String
    )

    private suspend fun buildOptionsWithSizes(streamInfo: StreamInfo): List<YtOption> {
        val validAudioStreams = streamInfo.audioStreams
            .orEmpty()
            .filter { it.isUrl && it.content.startsWith("http", ignoreCase = true) }

        val m4aStreams = validAudioStreams.filter { isM4aAudioStream(it) }
        val opusStreams = validAudioStreams.filter { isWebmOpusAudioStream(it) }

        // Audio ưu tiên m4a/AAC có bitrate gần 128kbps nhất; nếu không có m4a thì lấy webm/opus
        val selectedAudioForOption: Pair<AudioStream, String>? = when {
            m4aStreams.isNotEmpty() -> {
                val chosen = m4aStreams.minWithOrNull(
                    compareBy<AudioStream> { abs(resolveAudioBitrateKbps(it) - 128) }
                        .thenByDescending { resolveAudioBitrateKbps(it) }
                )
                chosen?.let { it to "m4a" }
            }
            opusStreams.isNotEmpty() -> {
                val chosen = opusStreams.minWithOrNull(
                    compareBy<AudioStream> { abs(resolveAudioBitrateKbps(it) - 128) }
                        .thenByDescending { resolveAudioBitrateKbps(it) }
                )
                chosen?.let { it to "opus" }
            }
            else -> null
        }

        // Audio tốt nhất cho từng họ khi cần ghép (mp4 -> m4a, webm -> opus)
        val bestM4aForMux: AudioStream? = m4aStreams.maxWithOrNull(
            compareBy<AudioStream> {
                // Ưu tiên bitrate gần 128kbps hoặc cao nhất
                resolveAudioBitrateKbps(it)
            }
        )
        val bestOpusForMux: AudioStream? = opusStreams.maxWithOrNull(
            compareBy<AudioStream> {
                resolveAudioBitrateKbps(it)
            }
        )

        val pendingOptions = mutableListOf<PendingOption>()

        // (a) Thêm option Audio
        if (selectedAudioForOption != null) {
            val (audioStream, audioExt) = selectedAudioForOption
            val bitrateKbps = resolveAudioBitrateKbps(audioStream)
            pendingOptions.add(
                PendingOption(
                    id = "audio_${audioExt}_${bitrateKbps}",
                    label = "Audio ${bitrateKbps}kbps",
                    kind = MediaKind.AUDIO,
                    videoStream = null,
                    audioStream = audioStream,
                    needsMux = false,
                    ext = audioExt
                )
            )
        }

        // (b) Gộp videoStreams (đã có âm thanh) và videoOnlyStreams (chỉ có hình)
        val candidates = mutableListOf<CandidateVideo>()

        val progressiveStreams = streamInfo.videoStreams
            .orEmpty()
            .filter { it.isUrl && it.content.startsWith("http", ignoreCase = true) }

        val videoOnlyStreams = streamInfo.videoOnlyStreams
            .orEmpty()
            .filter { it.isUrl && it.content.startsWith("http", ignoreCase = true) }

        fun collectCandidate(stream: VideoStream, isVideoOnly: Boolean) {
            if (isAv1VideoStream(stream)) return
            val h264Mp4 = isH264Mp4VideoStream(stream)
            val vp9Webm = !h264Mp4 && isVp9WebmVideoStream(stream)
            if (!h264Mp4 && !vp9Webm) return

            val height = resolveVideoHeight(stream)
            if (height <= 0) return
            val fps = resolveVideoFps(stream)
            val normalizedFps = if (fps > 30) fps else 30
            val label = if (normalizedFps > 30) "${height}p${normalizedFps}" else "${height}p"
            val ext = if (h264Mp4) "mp4" else "webm"

            val pairedAudio: AudioStream? = if (isVideoOnly) {
                if (h264Mp4) {
                    bestM4aForMux ?: bestOpusForMux
                } else {
                    bestOpusForMux ?: bestM4aForMux
                }
            } else {
                null
            }

            // Nếu là video-only mà không tìm được bất kỳ luồng audio nào để ghép thì bỏ qua
            if (isVideoOnly && pairedAudio == null) return

            candidates.add(
                CandidateVideo(
                    stream = stream,
                    height = height,
                    fps = normalizedFps,
                    label = label,
                    isH264Mp4 = h264Mp4,
                    isVp9Webm = vp9Webm,
                    needsMux = isVideoOnly,
                    pairedAudio = pairedAudio,
                    ext = ext
                )
            )
        }

        progressiveStreams.forEach { collectCandidate(it, isVideoOnly = false) }
        videoOnlyStreams.forEach { collectCandidate(it, isVideoOnly = true) }

        // Mỗi độ phân giải (và fps nếu > 30) chỉ giữ 1 stream:
        // Ưu tiên H.264/mp4 trước, sau đó VP9/webm; cùng codec thì ưu tiên bản đã có sẵn tiếng (!needsMux) rồi đến bitrate cao hơn
        val selectedVideos = candidates
            .groupBy { it.height to it.fps }
            .values
            .mapNotNull { group ->
                group.maxWithOrNull(
                    compareBy<CandidateVideo> { it.isH264Mp4 }
                        .thenBy { !it.needsMux }
                        .thenBy { it.stream.bitrate }
                )
            }
            .sortedWith(compareBy<CandidateVideo> { it.height }.thenBy { it.fps })

        for (video in selectedVideos) {
            pendingOptions.add(
                PendingOption(
                    id = "video_${video.label}_${video.ext}",
                    label = video.label,
                    kind = MediaKind.VIDEO,
                    videoStream = video.stream,
                    audioStream = video.pairedAudio,
                    needsMux = video.needsMux,
                    ext = video.ext
                )
            )
        }

        // Tính dung lượng cho từng stream (ưu tiên tham số "clen" trong URL, nếu không có thì gửi HEAD song song timeout 4s)
        val allStreamUrls = mutableSetOf<String>()
        for (opt in pendingOptions) {
            opt.videoStream?.content?.takeIf { it.isNotBlank() }?.let { allStreamUrls.add(it) }
            opt.audioStream?.content?.takeIf { it.isNotBlank() }?.let { allStreamUrls.add(it) }
        }

        val resolvedSizesByUrl = resolveStreamSizesConcurrently(allStreamUrls)

        return pendingOptions.map { opt ->
            val sizeBytes: Long? = if (opt.needsMux) {
                val vUrl = opt.videoStream?.content
                val aUrl = opt.audioStream?.content
                val vSize = vUrl?.let { resolvedSizesByUrl[it] }
                val aSize = aUrl?.let { resolvedSizesByUrl[it] }
                if (vSize != null && aSize != null) vSize + aSize else null
            } else if (opt.kind == MediaKind.AUDIO) {
                opt.audioStream?.content?.let { resolvedSizesByUrl[it] }
            } else {
                opt.videoStream?.content?.let { resolvedSizesByUrl[it] }
            }

            YtOption(
                id = opt.id,
                label = opt.label,
                kind = opt.kind,
                videoStream = opt.videoStream,
                audioStream = opt.audioStream,
                sizeBytes = sizeBytes,
                needsMux = opt.needsMux,
                ext = opt.ext
            )
        }
    }

    internal fun extractClenFromUrl(url: String): Long? {
        if (url.isBlank()) return null
        try {
            val clenParam = Uri.parse(url).getQueryParameter("clen")?.toLongOrNull()
            if (clenParam != null && clenParam > 0L) {
                return clenParam
            }
        } catch (_: Throwable) {}

        val match = clenRegex.find(url)
        val fromRegex = match?.groupValues?.getOrNull(1)?.toLongOrNull()
        return fromRegex?.takeIf { it > 0L }
    }

    private suspend fun resolveStreamSizesConcurrently(urls: Set<String>): Map<String, Long?> = coroutineScope {
        val result = ConcurrentHashMap<String, Long?>()
        val urlsNeedingHead = mutableListOf<String>()

        for (url in urls) {
            val clen = extractClenFromUrl(url)
            if (clen != null) {
                result[url] = clen
            } else {
                urlsNeedingUrlsAdd(urlsNeedingHead, url)
            }
        }

        if (urlsNeedingHead.isNotEmpty()) {
            urlsNeedingHead.map { targetUrl ->
                async(Dispatchers.IO) {
                    val headSize = fetchContentLengthViaHead(targetUrl)
                    if (headSize != null && headSize > 0L) {
                        result[targetUrl] = headSize
                    }
                }
            }.awaitAll()
        }

        result
    }

    private fun urlsNeedingUrlsAdd(list: MutableList<String>, url: String) {
        if (url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)) {
            list.add(url)
        }
    }

    private fun fetchContentLengthViaHead(url: String): Long? {
        return try {
            val req = okhttp3.Request.Builder()
                .url(url)
                .head()
                .header("User-Agent", AuraDownloader.USER_AGENT)
                .build()
            AuraDownloader.headClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    resp.header("Content-Length")?.trim()?.toLongOrNull()?.takeIf { it > 0L }
                } else {
                    null
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    internal fun resolveAudioBitrateKbps(stream: AudioStream): Int {
        val avg = stream.averageBitrate
        if (avg > 0) return avg
        val bps = stream.bitrate
        if (bps > 0) return (bps / 1000).coerceAtLeast(1)
        val itagBitrate = stream.itagItem?.bitrate ?: -1
        if (itagBitrate > 0) return (itagBitrate / 1000).coerceAtLeast(1)
        return 128
    }

    internal fun isM4aAudioStream(stream: AudioStream): Boolean {
        val format = stream.format
        val codec = (stream.codec ?: stream.itagItem?.codec ?: "").lowercase(Locale.ROOT)
        if (format == MediaFormat.M4A) return true
        if (format?.suffix.equals("m4a", ignoreCase = true)) return true
        if (format?.mimeType?.contains("mp4", ignoreCase = true) == true) return true
        return codec.startsWith("mp4a") || codec.contains("aac")
    }

    internal fun isWebmOpusAudioStream(stream: AudioStream): Boolean {
        val format = stream.format
        val codec = (stream.codec ?: stream.itagItem?.codec ?: "").lowercase(Locale.ROOT)
        if (format == MediaFormat.WEBMA || format == MediaFormat.WEBMA_OPUS) return true
        if (format?.suffix.equals("webm", ignoreCase = true) || format?.suffix.equals("opus", ignoreCase = true)) {
            return true
        }
        return codec.contains("opus") || codec.contains("vorbis")
    }

    internal fun isAv1VideoStream(stream: VideoStream): Boolean {
        val codec = (stream.codec ?: stream.itagItem?.codec ?: "").lowercase(Locale.ROOT)
        return codec.startsWith("av01") || codec.contains("av1")
    }

    internal fun isH264Mp4VideoStream(stream: VideoStream): Boolean {
        if (isAv1VideoStream(stream)) return false
        val format = stream.format
        val codec = (stream.codec ?: stream.itagItem?.codec ?: "").lowercase(Locale.ROOT)
        val isMp4Format = format == MediaFormat.MPEG_4 ||
            format?.suffix.equals("mp4", ignoreCase = true) ||
            format?.mimeType?.contains("mp4", ignoreCase = true) == true
        val isH264Codec = codec.startsWith("avc1") || codec.contains("h264") || codec.contains("avc")
        val isVp9Codec = codec.startsWith("vp9") || codec.startsWith("vp09") || codec.contains("vp9")
        return (isH264Codec && (isMp4Format || format == null)) || (isMp4Format && !isVp9Codec)
    }

    internal fun isVp9WebmVideoStream(stream: VideoStream): Boolean {
        if (isAv1VideoStream(stream)) return false
        val format = stream.format
        val codec = (stream.codec ?: stream.itagItem?.codec ?: "").lowercase(Locale.ROOT)
        val isWebmFormat = format == MediaFormat.WEBM ||
            format?.suffix.equals("webm", ignoreCase = true) ||
            format?.mimeType?.contains("webm", ignoreCase = true) == true
        val isVp9Codec = codec.startsWith("vp9") || codec.startsWith("vp09") || codec.contains("vp9")
        val isH264Codec = codec.startsWith("avc1") || codec.contains("h264") || codec.contains("avc")
        return (isVp9Codec && (isWebmFormat || format == null)) || (isWebmFormat && !isH264Codec)
    }

    internal fun resolveVideoHeight(stream: VideoStream): Int {
        if (stream.height > 0) return stream.height
        val itagHeight = stream.itagItem?.height ?: 0
        if (itagHeight > 0) return itagHeight
        val res = stream.resolution ?: ""
        val match = resolutionHeightRegex.find(res)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    }

    internal fun resolveVideoFps(stream: VideoStream): Int {
        if (stream.fps > 0) return stream.fps
        val itagFps = stream.itagItem?.fps ?: 0
        if (itagFps > 0) return itagFps
        val res = stream.resolution ?: ""
        val match = resolutionFpsRegex.find(res)
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 30
    }
}
