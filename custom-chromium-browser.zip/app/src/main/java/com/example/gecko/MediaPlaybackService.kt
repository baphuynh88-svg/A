package com.example.gecko

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle
import com.example.MainActivity
import com.example.util.AppLogger

data class MediaNotificationData(
    val tabId: String,
    val title: String,
    val artistOrHost: String,
    val artwork: Bitmap?,
    val isPlaying: Boolean,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val playbackRate: Float = 1.0f,
    val positionUpdatedAtElapsedMs: Long = SystemClock.elapsedRealtime()
) {
    fun currentPositionMs(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Long {
        val raw = if (isPlaying && positionUpdatedAtElapsedMs > 0L && nowElapsedMs > positionUpdatedAtElapsedMs) {
            positionMs + ((nowElapsedMs - positionUpdatedAtElapsedMs) * playbackRate).toLong()
        } else {
            positionMs
        }
        return if (durationMs > 0L) raw.coerceIn(0L, durationMs) else raw.coerceAtLeast(0L)
    }
}

/**
 * Object trung gian giữ callback điều khiển media của ViewModel, không giữ tham chiếu cứng tới Activity.
 */
object MediaController {
    @Volatile
    var onPlay: (() -> Unit)? = null

    @Volatile
    var onPause: (() -> Unit)? = null

    @Volatile
    var onStop: (() -> Unit)? = null

    @Volatile
    var onSeekTo: ((Long) -> Unit)? = null

    @Volatile
    var onSelectTab: ((String) -> Unit)? = null

    @Volatile
    var currentData: MediaNotificationData? = null
}

class MediaPlaybackService : Service() {

    private var mediaSessionCompat: MediaSessionCompat? = null

    @Volatile
    private var isInForeground: Boolean = false

    private val progressTicker = object : Runnable {
        override fun run() {
            val data = MediaController.currentData
            if (data != null && data.isPlaying) {
                updateMediaSessionState(data)
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        ensureChannel(this)
        initMediaSessionCompat()
    }

    private fun initMediaSessionCompat() {
        try {
            val session = MediaSessionCompat(this, "AuraMediaSession").apply {
                setCallback(object : MediaSessionCompat.Callback() {
                    override fun onPlay() {
                        MediaController.onPlay?.invoke()
                    }

                    override fun onPause() {
                        MediaController.onPause?.invoke()
                    }

                    override fun onStop() {
                        MediaController.onStop?.invoke()
                    }

                    override fun onSeekTo(pos: Long) {
                        MediaController.onSeekTo?.invoke(pos)
                    }
                })
                isActive = true
            }
            mediaSessionCompat = session
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "MediaSessionCompat init error: ${e.message}")
        }
    }

    private fun tryStartForegroundWithNotification(notification: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            isInForeground = true
            true
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "startForeground fallback to normal notification: ${e.message}")
            postNormalNotification(this, notification)
            false
        }
    }

    private fun syncProgressTicker(isPlaying: Boolean) {
        mainHandler.removeCallbacks(progressTicker)
        if (isPlaying) {
            mainHandler.postDelayed(progressTicker, 1000L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                MediaController.onPlay?.invoke()
            }
            ACTION_PAUSE -> {
                MediaController.onPause?.invoke()
            }
            ACTION_STOP -> {
                MediaController.onStop?.invoke()
            }
            ACTION_DISMISS -> {
                if (!isInForeground) {
                    val fallbackData = MediaController.currentData ?: MediaNotificationData(
                        tabId = "",
                        title = "Đang phát media",
                        artistOrHost = "",
                        artwork = null,
                        isPlaying = false
                    )
                    val notification = buildNotification(this, fallbackData, mediaSessionCompat?.sessionToken)
                    tryStartForegroundWithNotification(notification)
                }
                stopForegroundAndSelf()
                return START_NOT_STICKY
            }
            else -> {
                val data = MediaController.currentData
                if (data != null) {
                    updateMediaSessionState(data)
                    val notification = buildNotification(this, data, mediaSessionCompat?.sessionToken)
                    tryStartForegroundWithNotification(notification)
                    syncProgressTicker(data.isPlaying)
                } else {
                    // Đảm bảo luôn gọi startForeground trước khi stopSelf nếu được gọi qua startForegroundService
                    if (!isInForeground) {
                        val fallbackNotification = buildNotification(
                            this,
                            MediaNotificationData(
                                tabId = "",
                                title = "Đang phát media",
                                artistOrHost = "",
                                artwork = null,
                                isPlaying = false
                            ),
                            mediaSessionCompat?.sessionToken
                        )
                        tryStartForegroundWithNotification(fallbackNotification)
                    }
                    stopForegroundAndSelf()
                }
            }
        }
        return START_STICKY
    }

    internal fun updateNotificationInternal(data: MediaNotificationData) {
        updateMediaSessionState(data)
        val notification = buildNotification(this, data, mediaSessionCompat?.sessionToken)
        if (data.isPlaying && !isInForeground) {
            tryStartForegroundWithNotification(notification)
        } else {
            postNormalNotification(this, notification)
        }
        syncProgressTicker(data.isPlaying)
    }

    internal fun updateSessionStateOnly(data: MediaNotificationData) {
        updateMediaSessionState(data)
        syncProgressTicker(data.isPlaying)
    }

    private fun updateMediaSessionState(data: MediaNotificationData) {
        val session = mediaSessionCompat ?: return
        try {
            val metadataBuilder = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, data.title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, data.artistOrHost)
            if (data.durationMs > 0L) {
                metadataBuilder.putLong(MediaMetadataCompat.METADATA_KEY_DURATION, data.durationMs)
            }
            if (data.artwork != null) {
                metadataBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, data.artwork)
            }
            session.setMetadata(metadataBuilder.build())

            val state = if (data.isPlaying) {
                PlaybackStateCompat.STATE_PLAYING
            } else {
                PlaybackStateCompat.STATE_PAUSED
            }
            val nowElapsed = SystemClock.elapsedRealtime()
            val currentPos = data.currentPositionMs(nowElapsed)
            val speed = if (data.isPlaying) data.playbackRate.coerceAtLeast(0.1f) else 0f

            var actions = PlaybackStateCompat.ACTION_PLAY or
                PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_PLAY_PAUSE or
                PlaybackStateCompat.ACTION_STOP
            if (data.durationMs > 0L) {
                actions = actions or PlaybackStateCompat.ACTION_SEEK_TO
            }

            val playbackState = PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, currentPos, speed, nowElapsed)
                .build()
            session.setPlaybackState(playbackState)
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    internal fun stopForegroundAndSelf() {
        mainHandler.removeCallbacks(progressTicker)
        isNotificationShowing = false
        isInForeground = false
        try {
            stopForeground(true)
        } catch (_: Exception) {
        }
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIFICATION_ID)
        } catch (_: Exception) {
        }
        try {
            stopSelf()
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(progressTicker)
        isInForeground = false
        isNotificationShowing = false
        if (activeInstance === this) {
            activeInstance = null
        }
        try {
            mediaSessionCompat?.isActive = false
            mediaSessionCompat?.release()
        } catch (_: Exception) {
        }
        mediaSessionCompat = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "aura_media"
        const val NOTIFICATION_ID = 2001

        const val ACTION_START_OR_UPDATE = "com.example.gecko.action.MEDIA_START_OR_UPDATE"
        const val ACTION_PLAY = "com.example.gecko.action.MEDIA_PLAY"
        const val ACTION_PAUSE = "com.example.gecko.action.MEDIA_PAUSE"
        const val ACTION_STOP = "com.example.gecko.action.MEDIA_STOP"
        const val ACTION_DISMISS = "com.example.gecko.action.MEDIA_DISMISS"

        const val EXTRA_TAB_ID = "extra_media_tab_id"

        @Volatile
        private var activeInstance: MediaPlaybackService? = null

        @Volatile
        private var isNotificationShowing: Boolean = false

        private val mainHandler = Handler(Looper.getMainLooper())
        private var pendingDismissRunnable: Runnable? = null

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val existing = nm.getNotificationChannel(CHANNEL_ID)
                if (existing == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "Phát media",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "Điều khiển phát video và âm thanh trong trình duyệt"
                        setShowBadge(false)
                    }
                    nm.createNotificationChannel(channel)
                }
            }
        }

        fun cancelScheduledDismiss() {
            pendingDismissRunnable?.let { mainHandler.removeCallbacks(it) }
            pendingDismissRunnable = null
        }

        fun updateProgress(
            durationMs: Long,
            positionMs: Long,
            playbackRate: Float,
            positionUpdatedAtElapsedMs: Long
        ) {
            val prev = MediaController.currentData ?: return
            val updated = prev.copy(
                durationMs = if (durationMs > 0L) durationMs else prev.durationMs,
                positionMs = positionMs,
                playbackRate = playbackRate,
                positionUpdatedAtElapsedMs = positionUpdatedAtElapsedMs
            )
            MediaController.currentData = updated
            activeInstance?.updateSessionStateOnly(updated)
        }

        fun startOrUpdate(
            context: Context,
            data: MediaNotificationData,
            onlySessionState: Boolean = false
        ) {
            val appContext = context.applicationContext
            cancelScheduledDismiss()
            val prevData = MediaController.currentData
            MediaController.currentData = data

            // Chỉ bắt đầu hiển thị thông báo khi media bắt đầu phát (isPlaying = true)
            // hoặc khi thông báo đã hiển thị sẵn (cập nhật sang trạng thái Pause / đổi metadata)
            if (!isNotificationShowing && !data.isPlaying) {
                return
            }

            val instance = activeInstance
            if (onlySessionState && isNotificationShowing && instance != null && prevData?.durationMs == data.durationMs) {
                instance.updateSessionStateOnly(data)
                return
            }

            if (!isNotificationShowing || (instance == null && data.isPlaying)) {
                isNotificationShowing = true
                AppLogger.d("AuraBrowser", "media notification start (tabId=${data.tabId})")
                val serviceIntent = Intent(appContext, MediaPlaybackService::class.java).apply {
                    action = ACTION_START_OR_UPDATE
                }
                try {
                    ContextCompat.startForegroundService(appContext, serviceIntent)
                } catch (e: Exception) {
                    // Android 12+ cấm bật foreground service khi app ở nền -> fallback thông báo thường
                    AppLogger.d("AuraBrowser", "startForegroundService failed in background, posting normal notification: ${e.message}")
                    ensureChannel(appContext)
                    val notification = buildNotification(appContext, data, activeInstance?.mediaSessionCompat?.sessionToken)
                    postNormalNotification(appContext, notification)
                }
            } else {
                AppLogger.d("AuraBrowser", "media notification update (tabId=${data.tabId}, isPlaying=${data.isPlaying})")
                if (instance != null) {
                    instance.updateNotificationInternal(data)
                }
            }
        }

        fun scheduleDismissIn5s(context: Context) {
            if (!isNotificationShowing && activeInstance == null && MediaController.currentData == null) {
                return
            }
            val appContext = context.applicationContext
            cancelScheduledDismiss()
            AppLogger.d("AuraBrowser", "media notification dismiss in 5s")
            val runnable = Runnable {
                pendingDismissRunnable = null
                dismissNow(appContext)
            }
            pendingDismissRunnable = runnable
            mainHandler.postDelayed(runnable, 5000L)
        }

        fun dismissNow(context: Context) {
            val appContext = context.applicationContext
            cancelScheduledDismiss()
            isNotificationShowing = false
            MediaController.currentData = null

            val instance = activeInstance
            if (instance != null) {
                instance.stopForegroundAndSelf()
            } else {
                try {
                    val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.cancel(NOTIFICATION_ID)
                    appContext.stopService(Intent(appContext, MediaPlaybackService::class.java))
                } catch (_: Exception) {
                }
            }
            AppLogger.d("AuraBrowser", "media notification dismissed")
        }

        private fun postNormalNotification(context: Context, notification: Notification) {
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, notification)
            } catch (e: SecurityException) {
                AppLogger.d("AuraBrowser", "Notification permission not granted: ${e.message}")
            } catch (e: Exception) {
                AppLogger.d("AuraBrowser", "Notification error: ${e.message}")
            }
        }

        internal fun buildNotification(
            context: Context,
            data: MediaNotificationData,
            sessionToken: MediaSessionCompat.Token?
        ): Notification {
            ensureChannel(context)

            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(EXTRA_TAB_ID, data.tabId)
            }
            val contentPendingIntent = PendingIntent.getActivity(
                context,
                100,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val playPauseAction = if (data.isPlaying) {
                val pauseIntent = Intent(context, MediaPlaybackService::class.java).apply {
                    action = ACTION_PAUSE
                }
                val pausePendingIntent = PendingIntent.getService(
                    context,
                    101,
                    pauseIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                NotificationCompat.Action(
                    android.R.drawable.ic_media_pause,
                    "Tạm dừng",
                    pausePendingIntent
                )
            } else {
                val playIntent = Intent(context, MediaPlaybackService::class.java).apply {
                    action = ACTION_PLAY
                }
                val playPendingIntent = PendingIntent.getService(
                    context,
                    102,
                    playIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                NotificationCompat.Action(
                    android.R.drawable.ic_media_play,
                    "Phát",
                    playPendingIntent
                )
            }

            val stopIntent = Intent(context, MediaPlaybackService::class.java).apply {
                action = ACTION_STOP
            }
            val stopPendingIntent = PendingIntent.getService(
                context,
                103,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val stopAction = NotificationCompat.Action(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Dừng",
                stopPendingIntent
            )

            val mediaStyle = MediaStyle().setShowActionsInCompactView(0, 1)
            if (sessionToken != null) {
                mediaStyle.setMediaSession(sessionToken)
            }

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(
                    if (data.isPlaying) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause
                )
                .setContentTitle(data.title.ifBlank { "Đang phát media" })
                .setContentText(data.artistOrHost)
                .setLargeIcon(data.artwork)
                .setContentIntent(contentPendingIntent)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setOngoing(data.isPlaying)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .addAction(playPauseAction)
                .addAction(stopAction)
                .setStyle(mediaStyle)
                .build()
        }
    }
}
