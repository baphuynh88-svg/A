package com.example.gecko

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.StatFs
import com.example.util.AppLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Logic tải và ghép (mux) stream YouTube cho Savior.
 */
object YtDownloader {

    private const val TAG = "YtDownloader"
    const val CHUNK_SIZE_BYTES = 4L * 1024L * 1024L // 4 MB mỗi khúc Range
    const val MAX_CHUNK_RETRIES = 3
    const val YOUTUBE_REFERER = "https://www.youtube.com/"
    private const val DEFAULT_MUX_BUFFER_SIZE = 1024 * 1024 // 1 MB

    const val UNSUPPORTED_MUX_MESSAGE =
        "Định dạng này không ghép được trên máy, hãy thử độ phân giải thấp hơn"

    private class Http403ExpiredException(message: String) : IOException(message)
    class UnsupportedMuxCodecException(message: String = UNSUPPORTED_MUX_MESSAGE, cause: Throwable? = null) :
        Exception(message, cause)

    private val contentRangeTotalRegex = Regex("""bytes\s+\d+-\d+/(\d+)""", RegexOption.IGNORE_CASE)

    /**
     * Tạo tên cơ sở theo mẫu "<tên video làm sạch ký tự cấm> [<label>]" và đuôi file (.mp4 / .webm / .m4a).
     */
    fun resolveFinalExtAndMime(option: YtOption): Pair<String, String> {
        return if (option.kind == MediaKind.AUDIO) {
            // Audio-only: lưu trực tiếp thành .m4a (hoặc .webm nếu chỉ có opus)
            if (option.ext.equals("m4a", ignoreCase = true)) {
                "m4a" to "audio/mp4"
            } else {
                "webm" to "audio/webm"
            }
        } else {
            if (option.ext.equals("webm", ignoreCase = true)) {
                "webm" to "video/webm"
            } else {
                "mp4" to "video/mp4"
            }
        }
    }

    fun buildBaseTitleWithLabel(videoTitle: String, pageUrl: String, optionLabel: String): String {
        val cleanTitle = MediaDownloader.sanitizeBaseTitle(videoTitle, pageUrl)
        val cleanLabel = optionLabel.trim()
        return "$cleanTitle [$cleanLabel]"
    }

    /**
     * Tải (và ghép nếu cần) một YtOption từ YouTube, báo tiến trình qua Flow<DownloadProgress>.
     */
    fun downloadYouTube(
        context: Context,
        pageUrl: String,
        videoTitle: String,
        initialOption: YtOption
    ): Flow<DownloadProgress> = flow {
        val appContext = context.applicationContext
        val (finalExt, finalMime) = resolveFinalExtAndMime(initialOption)
        val baseTitleWithTag = buildBaseTitleWithLabel(videoTitle, pageUrl, initialOption.label)
        val targetFileName = MediaDownloader.buildUniqueFileName(appContext, baseTitleWithTag, finalExt)

        val tempDir = File(appContext.cacheDir, "savior_yt_temp").apply { mkdirs() }
        val uniqueSuffix = "${System.currentTimeMillis()}_${initialOption.id.hashCode()}"
        val tempPrimaryFile = File(tempDir, "yt_primary_$uniqueSuffix.tmp")
        val tempAudioFile = File(tempDir, "yt_audio_$uniqueSuffix.tmp")
        val tempMuxedFile = File(tempDir, "yt_muxed_$uniqueSuffix.$finalExt")

        var completedSuccessfully = false
        try {
            var currentOption = initialOption
            var hasRetried403 = false

            while (true) {
                try {
                    val vUrl = currentOption.videoStream?.content.orEmpty()
                    val aUrl = currentOption.audioStream?.content.orEmpty()

                    val vClen = YouTubeExtractorRepo.extractClenFromUrl(vUrl)
                    val aClen = YouTubeExtractorRepo.extractClenFromUrl(aUrl)
                    val estimatedTotalBytes: Long? = when {
                        currentOption.sizeBytes != null && currentOption.sizeBytes > 0L -> currentOption.sizeBytes
                        currentOption.needsMux && vClen != null && aClen != null -> vClen + aClen
                        currentOption.kind == MediaKind.AUDIO -> aClen
                        else -> vClen
                    }

                    // Kiểm tra dung lượng trống (StatFs) >= 2 lần kích thước trước khi tải
                    ensureEnoughDiskSpace(appContext, estimatedTotalBytes)

                    emit(
                        DownloadProgress(
                            downloaded = 0L,
                            total = estimatedTotalBytes,
                            fileName = targetFileName,
                            progressFraction = if (estimatedTotalBytes != null) 0f else null
                        )
                    )

                    if (currentOption.kind == MediaKind.AUDIO) {
                        if (aUrl.isBlank()) {
                            throw IllegalStateException("Không tìm thấy đường dẫn luồng âm thanh")
                        }
                        val actualBytes = downloadStreamInChunks(
                            url = aUrl,
                            destFile = tempAudioFile,
                            knownSize = estimatedTotalBytes,
                            onBytesDownloaded = { downloaded, resolvedTotal ->
                                val total = resolvedTotal ?: estimatedTotalBytes
                                val frac = if (total != null && total > 0L) {
                                    (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    null
                                }
                                emit(
                                    DownloadProgress(
                                        downloaded = downloaded,
                                        total = total,
                                        fileName = targetFileName,
                                        progressFraction = frac
                                    )
                                )
                            }
                        )

                        currentCoroutineContext().ensureActive()
                        FileInputStream(tempAudioFile).use { input ->
                            val saved = MediaDownloader.streamToSaviorDownloads(
                                context = appContext,
                                inputStream = input,
                                fileName = targetFileName,
                                mimeType = finalMime,
                                totalBytes = actualBytes,
                                onProgress = {}
                            )
                            completedSuccessfully = true
                            emit(
                                DownloadProgress(
                                    downloaded = saved.second,
                                    total = saved.second,
                                    fileName = targetFileName,
                                    progressFraction = 1f,
                                    completedFile = saved.first
                                )
                            )
                        }
                    } else if (!currentOption.needsMux) {
                        // Video có sẵn tiếng (needsMux = false): tải và lưu thẳng thành .mp4/.webm
                        if (vUrl.isBlank()) {
                            throw IllegalStateException("Không tìm thấy đường dẫn luồng video")
                        }
                        val actualBytes = downloadStreamInChunks(
                            url = vUrl,
                            destFile = tempPrimaryFile,
                            knownSize = estimatedTotalBytes,
                            onBytesDownloaded = { downloaded, resolvedTotal ->
                                val total = resolvedTotal ?: estimatedTotalBytes
                                val frac = if (total != null && total > 0L) {
                                    (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    null
                                }
                                emit(
                                    DownloadProgress(
                                        downloaded = downloaded,
                                        total = total,
                                        fileName = targetFileName,
                                        progressFraction = frac
                                    )
                                )
                            }
                        )

                        currentCoroutineContext().ensureActive()
                        FileInputStream(tempPrimaryFile).use { input ->
                            val saved = MediaDownloader.streamToSaviorDownloads(
                                context = appContext,
                                inputStream = input,
                                fileName = targetFileName,
                                mimeType = finalMime,
                                totalBytes = actualBytes,
                                onProgress = {}
                            )
                            completedSuccessfully = true
                            emit(
                                DownloadProgress(
                                    downloaded = saved.second,
                                    total = saved.second,
                                    fileName = targetFileName,
                                    progressFraction = 1f,
                                    completedFile = saved.first
                                )
                            )
                        }
                    } else {
                        // Video cần ghép (needsMux = true):
                        // 0–90% cho việc tải (tổng byte video + audio), 90–100% cho việc ghép.
                        if (vUrl.isBlank() || aUrl.isBlank()) {
                            throw IllegalStateException("Thiếu luồng hình hoặc tiếng để ghép video")
                        }

                        var videoTotalKnown = vClen
                        val audioTotalKnown = aClen
                        var videoDownloaded = 0L

                        val actualVideoBytes = downloadStreamInChunks(
                            url = vUrl,
                            destFile = tempPrimaryFile,
                            knownSize = videoTotalKnown,
                            onBytesDownloaded = { dlVideo, resolvedVTotal ->
                                videoDownloaded = dlVideo
                                if (resolvedVTotal != null && resolvedVTotal > 0L) {
                                    videoTotalKnown = resolvedVTotal
                                }
                                val combinedTotal = if (videoTotalKnown != null && audioTotalKnown != null) {
                                    videoTotalKnown!! + audioTotalKnown
                                } else {
                                    estimatedTotalBytes
                                }
                                val dlFraction = if (combinedTotal != null && combinedTotal > 0L) {
                                    ((dlVideo.toFloat() / combinedTotal.toFloat()).coerceIn(0f, 1f)) * 0.90f
                                } else {
                                    null
                                }
                                emit(
                                    DownloadProgress(
                                        downloaded = dlVideo,
                                        total = combinedTotal,
                                        fileName = targetFileName,
                                        progressFraction = dlFraction
                                    )
                                )
                            }
                        )

                        val actualAudioBytes = downloadStreamInChunks(
                            url = aUrl,
                            destFile = tempAudioFile,
                            knownSize = audioTotalKnown,
                            onBytesDownloaded = { dlAudio, resolvedATotal ->
                                val aTotal = resolvedATotal ?: audioTotalKnown
                                val combinedTotal = if (aTotal != null) {
                                    actualVideoBytes + aTotal
                                } else {
                                    estimatedTotalBytes
                                }
                                val totalDlSoFar = actualVideoBytes + dlAudio
                                val dlFraction = if (combinedTotal != null && combinedTotal > 0L) {
                                    ((totalDlSoFar.toFloat() / combinedTotal.toFloat()).coerceIn(0f, 1f)) * 0.90f
                                } else {
                                    null
                                }
                                emit(
                                    DownloadProgress(
                                        downloaded = totalDlSoFar,
                                        total = combinedTotal,
                                        fileName = targetFileName,
                                        progressFraction = dlFraction
                                    )
                                )
                            }
                        )

                        val totalDownloadedBytes = actualVideoBytes + actualAudioBytes
                        currentCoroutineContext().ensureActive()

                        // Bắt đầu giai đoạn ghép (90% -> 100%)
                        emit(
                            DownloadProgress(
                                downloaded = totalDownloadedBytes,
                                total = totalDownloadedBytes,
                                fileName = targetFileName,
                                isMuxing = true,
                                progressFraction = 0.90f
                            )
                        )

                        var lastMuxEmitAt = 0L
                        muxVideoAndAudio(
                            videoFile = tempPrimaryFile,
                            audioFile = tempAudioFile,
                            outputFile = tempMuxedFile,
                            isWebm = finalExt == "webm",
                            onMuxProgress = { muxFraction ->
                                val now = System.currentTimeMillis()
                                if (now - lastMuxEmitAt >= 150L || muxFraction >= 0.99f) {
                                    lastMuxEmitAt = now
                                    val combinedFrac = (0.90f + 0.10f * muxFraction.coerceIn(0f, 1f)).coerceIn(0.90f, 0.99f)
                                    emit(
                                        DownloadProgress(
                                            downloaded = totalDownloadedBytes,
                                            total = totalDownloadedBytes,
                                            fileName = targetFileName,
                                            isMuxing = true,
                                            progressFraction = combinedFrac
                                        )
                                    )
                                }
                            }
                        )

                        // Xoá ngay 2 file thành phần sau khi ghép xong để giải phóng bộ nhớ tạm
                        safeDelete(tempPrimaryFile)
                        safeDelete(tempAudioFile)

                        currentCoroutineContext().ensureActive()
                        FileInputStream(tempMuxedFile).use { muxedInput ->
                            val saved = MediaDownloader.streamToSaviorDownloads(
                                context = appContext,
                                inputStream = muxedInput,
                                fileName = targetFileName,
                                mimeType = finalMime,
                                totalBytes = tempMuxedFile.length(),
                                onProgress = {}
                            )
                            completedSuccessfully = true
                            emit(
                                DownloadProgress(
                                    downloaded = saved.second,
                                    total = saved.second,
                                    fileName = targetFileName,
                                    progressFraction = 1f,
                                    completedFile = saved.first
                                )
                            )
                        }
                    }

                    break
                } catch (e: Http403ExpiredException) {
                    safeDelete(tempPrimaryFile)
                    safeDelete(tempAudioFile)
                    safeDelete(tempMuxedFile)

                    if (!hasRetried403 && pageUrl.isNotBlank()) {
                        hasRetried403 = true
                        AppLogger.d(
                            TAG,
                            "Gặp HTTP 403 (link hết hạn), lấy lại link mới bằng YouTubeExtractorRepo (bỏ cache) cho $pageUrl"
                        )
                        val refreshedMedia = YouTubeExtractorRepo.load(pageUrl, forceRefresh = true).getOrNull()
                        val refreshedOption = refreshedMedia?.options?.find {
                            it.id == currentOption.id || (it.label == currentOption.label && it.kind == currentOption.kind)
                        }
                        if (refreshedOption != null) {
                            currentOption = refreshedOption
                            continue
                        }
                    }
                    throw IOException("Liên kết tải video đã hết hạn (HTTP 403), hãy thử lại", e)
                }
            }
        } catch (e: CancellationException) {
            AppLogger.d(TAG, "Đã huỷ tải YouTube: $targetFileName")
            throw e
        } finally {
            safeDelete(tempPrimaryFile)
            safeDelete(tempAudioFile)
            safeDelete(tempMuxedFile)
            if (!completedSuccessfully) {
                MediaDownloader.releaseReservedFileName(targetFileName)
            }
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Kiểm tra dung lượng trống (StatFs) >= 2 lần kích thước trước khi tải.
     */
    internal fun ensureEnoughDiskSpace(context: Context, expectedSizeBytes: Long?) {
        val required = expectedSizeBytes?.takeIf { it > 0L }?.let { it * 2L } ?: (32L * 1024L * 1024L)
        val statFs = StatFs(context.cacheDir.absolutePath)
        val available = statFs.availableBytes
        if (available < required) {
            val reqMb = String.format(Locale.US, "%.1f MB", required / (1024.0 * 1024.0))
            val availMb = String.format(Locale.US, "%.1f MB", available / (1024.0 * 1024.0))
            throw IllegalStateException("Không đủ bộ nhớ trống (cần $reqMb, còn trống $availMb)")
        }
    }

    /**
     * Tải một stream theo từng khúc 4MB bằng header "Range: bytes=a-b", mỗi khúc retry tối đa 3 lần.
     */
    private suspend fun downloadStreamInChunks(
        url: String,
        destFile: File,
        knownSize: Long?,
        onBytesDownloaded: suspend (downloadedBytes: Long, totalBytes: Long?) -> Unit
    ): Long {
        safeDelete(destFile)
        var totalSize: Long? = knownSize?.takeIf { it > 0L } ?: YouTubeExtractorRepo.extractClenFromUrl(url)
        var currentOffset = 0L

        RandomAccessFile(destFile, "rw").use { raf ->
            while (true) {
                currentCoroutineContext().ensureActive()

                val totalSnapshot = totalSize
                if (totalSnapshot != null && currentOffset >= totalSnapshot) {
                    break
                }

                val rangeEnd = if (totalSnapshot != null) {
                    minOf(currentOffset + CHUNK_SIZE_BYTES - 1L, totalSnapshot - 1L)
                } else {
                    currentOffset + CHUNK_SIZE_BYTES - 1L
                }
                val expectedChunkLen = rangeEnd - currentOffset + 1L

                var attempt = 0
                var chunkCompleted = false
                var reachedEofWithoutKnownTotal = false

                while (!chunkCompleted) {
                    currentCoroutineContext().ensureActive()
                    attempt++
                    try {
                        raf.seek(currentOffset)

                        val request = Request.Builder()
                            .url(url)
                            .get()
                            .header("User-Agent", AuraDownloader.USER_AGENT)
                            .header("Referer", YOUTUBE_REFERER)
                            .header("Range", "bytes=$currentOffset-$rangeEnd")
                            .build()

                        var bytesReadInChunk = 0L
                        var lastProgressEmitTime = 0L

                        AuraDownloader.client.newCall(request).execute().use { response ->
                            val code = response.code
                            if (code == 403) {
                                throw Http403ExpiredException("HTTP 403 Forbidden for YouTube stream")
                            }
                            if (code == 416) {
                                // Range Not Satisfiable -> đã chạm cuối file
                                reachedEofWithoutKnownTotal = true
                                chunkCompleted = true
                                return@use
                            }
                            if (code !in 200..299) {
                                throw IOException("HTTP $code khi tải khúc $currentOffset-$rangeEnd")
                            }

                            if (code == 206 && totalSize == null) {
                                val contentRange = response.header("Content-Range").orEmpty()
                                val match = contentRangeTotalRegex.find(contentRange)
                                val parsedTotal = match?.groupValues?.getOrNull(1)?.toLongOrNull()
                                if (parsedTotal != null && parsedTotal > 0L) {
                                    totalSize = parsedTotal
                                }
                            } else if (code == 200 && currentOffset == 0L && totalSize == null) {
                                val contentLen = response.body?.contentLength() ?: -1L
                                if (contentLen > 0L) {
                                    totalSize = contentLen
                                }
                            }

                            val bodyStream = response.body?.byteStream()
                                ?: throw IOException("Phản hồi rỗng từ máy chủ YouTube")

                            val buffer = ByteArray(64 * 1024)
                            var read: Int
                            while (bodyStream.read(buffer).also { read = it } != -1) {
                                currentCoroutineContext().ensureActive()
                                raf.write(buffer, 0, read)
                                bytesReadInChunk += read
                                val now = System.currentTimeMillis()
                                if (now - lastProgressEmitTime >= 150L) {
                                    lastProgressEmitTime = now
                                    onBytesDownloaded(currentOffset + bytesReadInChunk, totalSize)
                                }
                            }

                            // Nếu server trả 200 OK (bỏ qua Range) ngay từ byte 0 thì đã tải hết toàn bộ luồng
                            if (code == 200 && currentOffset == 0L) {
                                currentOffset += bytesReadInChunk
                                totalSize = currentOffset
                                onBytesDownloaded(currentOffset, totalSize)
                                reachedEofWithoutKnownTotal = true
                                chunkCompleted = true
                                return@use
                            }
                        }

                        if (!chunkCompleted) {
                            currentOffset += bytesReadInChunk
                            onBytesDownloaded(currentOffset, totalSize)

                            if (totalSize == null && bytesReadInChunk < expectedChunkLen) {
                                reachedEofWithoutKnownTotal = true
                            }
                            chunkCompleted = true
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Http403ExpiredException) {
                        throw e
                    } catch (e: Exception) {
                        if (attempt >= MAX_CHUNK_RETRIES) {
                            AppLogger.d(
                                TAG,
                                "Tải khúc $currentOffset-$rangeEnd thất bại sau $attempt lần thử: ${e.message}"
                            )
                            throw e
                        }
                        AppLogger.d(
                            TAG,
                            "Thử lại khúc $currentOffset-$rangeEnd (lần $attempt/$MAX_CHUNK_RETRIES) do: ${e.message}"
                        )
                        delay(400L * attempt)
                    }
                }

                if (reachedEofWithoutKnownTotal) {
                    break
                }
            }
        }

        if (currentOffset <= 0L || !destFile.exists() || destFile.length() <= 0L) {
            throw IOException("Không nhận được dữ liệu từ luồng YouTube")
        }
        return currentOffset
    }

    /**
     * Ghép file video tạm và file audio tạm bằng MediaExtractor + MediaMuxer:
     * - H.264 + AAC -> MUXER_OUTPUT_MPEG_4 (.mp4)
     * - VP9 + Opus -> MUXER_OUTPUT_WEBM (.webm)
     */
    internal suspend fun muxVideoAndAudio(
        videoFile: File,
        audioFile: File,
        outputFile: File,
        isWebm: Boolean,
        onMuxProgress: suspend (Float) -> Unit
    ) {
        safeDelete(outputFile)
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null

        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            audioExtractor.setDataSource(audioFile.absolutePath)

            var videoTrackIndex = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until videoExtractor.trackCount) {
                val format = videoExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/", ignoreCase = true)) {
                    videoTrackIndex = i
                    videoFormat = format
                    break
                }
            }

            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until audioExtractor.trackCount) {
                val format = audioExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/", ignoreCase = true)) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (videoTrackIndex < 0 || videoFormat == null || audioTrackIndex < 0 || audioFormat == null) {
                throw UnsupportedMuxCodecException()
            }

            videoExtractor.selectTrack(videoTrackIndex)
            audioExtractor.selectTrack(audioTrackIndex)

            val outputFormat = if (isWebm) {
                MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
            } else {
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            }

            val createdMuxer = try {
                MediaMuxer(outputFile.absolutePath, outputFormat)
            } catch (e: Throwable) {
                throw UnsupportedMuxCodecException(cause = e)
            }
            muxer = createdMuxer

            val muxVideoTrack: Int
            val muxAudioTrack: Int
            try {
                muxVideoTrack = createdMuxer.addTrack(videoFormat)
                muxAudioTrack = createdMuxer.addTrack(audioFormat)
                createdMuxer.start()
            } catch (e: Throwable) {
                throw UnsupportedMuxCodecException(cause = e)
            }

            val vMaxInput = if (videoFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                videoFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else {
                DEFAULT_MUX_BUFFER_SIZE
            }
            val aMaxInput = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else {
                DEFAULT_MUX_BUFFER_SIZE
            }
            val bufferSize = maxOf(vMaxInput, aMaxInput, DEFAULT_MUX_BUFFER_SIZE)
            val buffer = java.nio.ByteBuffer.allocate(bufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            val totalExpectedBytes = (videoFile.length() + audioFile.length()).coerceAtLeast(1L)
            var bytesProcessed = 0L

            // 1. Chép toàn bộ sample của video track
            while (true) {
                currentCoroutineContext().ensureActive()
                bufferInfo.offset = 0
                val sampleSize = videoExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                val sampleTime = videoExtractor.sampleTime
                if (sampleTime < 0L) {
                    videoExtractor.advance()
                    continue
                }

                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTime
                bufferInfo.flags = mapSampleFlagsToCodecFlags(videoExtractor.sampleFlags)
                try {
                    createdMuxer.writeSampleData(muxVideoTrack, buffer, bufferInfo)
                } catch (e: Throwable) {
                    throw UnsupportedMuxCodecException(cause = e)
                }

                bytesProcessed += sampleSize
                onMuxProgress((bytesProcessed.toFloat() / totalExpectedBytes.toFloat()).coerceIn(0f, 1f))
                videoExtractor.advance()
            }

            // 2. Chép toàn bộ sample của audio track
            while (true) {
                currentCoroutineContext().ensureActive()
                bufferInfo.offset = 0
                val sampleSize = audioExtractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                val sampleTime = audioExtractor.sampleTime
                if (sampleTime < 0L) {
                    audioExtractor.advance()
                    continue
                }

                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTime
                bufferInfo.flags = mapSampleFlagsToCodecFlags(audioExtractor.sampleFlags)
                try {
                    createdMuxer.writeSampleData(muxAudioTrack, buffer, bufferInfo)
                } catch (e: Throwable) {
                    throw UnsupportedMuxCodecException(cause = e)
                }

                bytesProcessed += sampleSize
                onMuxProgress((bytesProcessed.toFloat() / totalExpectedBytes.toFloat()).coerceIn(0f, 1f))
                audioExtractor.advance()
            }

            try {
                createdMuxer.stop()
            } catch (e: Throwable) {
                throw UnsupportedMuxCodecException(cause = e)
            }

            if (!outputFile.exists() || outputFile.length() <= 0L) {
                throw UnsupportedMuxCodecException()
            }
        } catch (e: CancellationException) {
            safeDelete(outputFile)
            throw e
        } catch (e: UnsupportedMuxCodecException) {
            AppLogger.d(TAG, "MediaMuxer không hỗ trợ codec: ${e.cause?.message ?: e.message}")
            safeDelete(outputFile)
            throw e
        } catch (e: Throwable) {
            AppLogger.d(TAG, "Lỗi khi ghép video/audio bằng MediaMuxer: ${e.message}")
            safeDelete(outputFile)
            throw UnsupportedMuxCodecException(cause = e)
        } finally {
            try {
                muxer?.release()
            } catch (_: Throwable) {}
            try {
                videoExtractor.release()
            } catch (_: Throwable) {}
            try {
                audioExtractor.release()
            } catch (_: Throwable) {}
        }
    }

    private fun mapSampleFlagsToCodecFlags(sampleFlags: Int): Int {
        var codecFlags = 0
        if ((sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
            codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_KEY_FRAME
        }
        if ((sampleFlags and MediaExtractor.SAMPLE_FLAG_PARTIAL_FRAME) != 0) {
            codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_PARTIAL_FRAME
        }
        return codecFlags
    }

    private fun safeDelete(file: File?) {
        try {
            if (file != null && file.exists()) {
                file.delete()
            }
        } catch (_: Throwable) {}
    }
}
