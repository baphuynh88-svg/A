package com.example.gecko

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.example.util.AppLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.Locale

data class DownloadedMediaFile(
    val fileName: String,
    val uri: Uri?,
    val mimeType: String
)

data class AudioExtractionFallback(
    val tempVideoFile: File,
    val baseTitle: String,
    val videoExtension: String,
    val videoMimeType: String
)

data class DownloadProgress(
    val downloaded: Long,
    val total: Long?,
    val fileName: String = "",
    val isExtractingAudio: Boolean = false,
    val isMuxing: Boolean = false,
    val progressFraction: Float? = null,
    val completedFile: DownloadedMediaFile? = null,
    val audioExtractionFallback: AudioExtractionFallback? = null
)

object MediaDownloader {

    const val FIREFOX_ANDROID_USER_AGENT =
        "Mozilla/5.0 (Android 14; Mobile; rv:136.0) Gecko/136.0 Firefox/136.0"

    private const val RELATIVE_SAVIOR_DIR = "Download/Aura/Savior"

    private val FORBIDDEN_FILENAME_CHARS = Regex("""[/\\:*?"<>|\u0000-\u001F]""")
    private val KNOWN_EXT_REGEX =
        Regex("""\.(mp4|webm|m4v|mov|mp3|m4a|aac|ogg|opus|wav|flac)$""", RegexOption.IGNORE_CASE)

    private val reservedNamesInSession = HashSet<String>()

    /**
     * Làm sạch pageTitle để tạo tên file hợp lệ.
     */
    fun sanitizeBaseTitle(rawTitle: String, fallbackUrl: String): String {
        val candidate = rawTitle
            .replace(FORBIDDEN_FILENAME_CHARS, "_")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .trim('.', '_')
            .take(120)

        if (candidate.isNotBlank()) {
            return candidate
        }

        val lastSeg = try {
            Uri.parse(fallbackUrl).lastPathSegment
                ?.substringBeforeLast('.')
                ?.replace(FORBIDDEN_FILENAME_CHARS, "_")
                ?.trim()
        } catch (_: Exception) {
            null
        }
        return if (!lastSeg.isNullOrBlank()) {
            lastSeg.take(80)
        } else {
            "media_${System.currentTimeMillis()}"
        }
    }

    /**
     * Đoán đuôi file từ URL hoặc Content-Type.
     */
    fun resolveExtension(url: String, contentType: String?, kind: MediaKind): String {
        val cleanPath = try {
            Uri.parse(url).path ?: url.substringBefore('?').substringBefore('#')
        } catch (_: Exception) {
            url.substringBefore('?').substringBefore('#')
        }
        val match = KNOWN_EXT_REGEX.find(cleanPath)
        if (match != null) {
            return match.groupValues[1].lowercase(Locale.ROOT)
        }

        val cleanMime = contentType?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT) ?: ""
        val fromMime = when (cleanMime) {
            "video/mp4" -> "mp4"
            "video/webm" -> "webm"
            "video/quicktime" -> "mov"
            "video/x-m4v" -> "m4v"
            "audio/mpeg", "audio/mp3" -> "mp3"
            "audio/mp4", "audio/x-m4a", "audio/m4a" -> "m4a"
            "audio/aac" -> "aac"
            "audio/ogg", "application/ogg" -> "ogg"
            "audio/opus" -> "opus"
            "audio/wav", "audio/x-wav" -> "wav"
            "audio/flac" -> "flac"
            else -> MimeTypeMap.getSingleton().getExtensionFromMimeType(cleanMime)
        }
        if (!fromMime.isNullOrBlank()) {
            return fromMime.lowercase(Locale.ROOT)
        }

        return if (kind == MediaKind.AUDIO) "mp3" else "mp4"
    }

    fun resolveMimeType(extension: String, serverContentType: String?, kind: MediaKind): String {
        return when (extension.lowercase(Locale.ROOT)) {
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "m4v" -> "video/x-m4v"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "opus" -> "audio/opus"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            else -> {
                val clean = serverContentType?.substringBefore(';')?.trim()
                if (!clean.isNullOrBlank() && clean != "application/octet-stream") {
                    clean
                } else if (kind == MediaKind.AUDIO) {
                    "audio/mpeg"
                } else {
                    "video/mp4"
                }
            }
        }
    }

    /**
     * Tạo tên file không trùng trong thư mục Downloads/Aura/Savior (nếu trùng thêm " (1)", " (2)"...).
     */
    @Synchronized
    fun buildUniqueFileName(context: Context, baseTitle: String, extension: String): String {
        val extClean = extension.trimStart('.').lowercase(Locale.ROOT)
        val cleanBase = if (baseTitle.lowercase(Locale.ROOT).endsWith(".$extClean")) {
            baseTitle.dropLast(extClean.length + 1).trim()
        } else {
            baseTitle.trim()
        }.ifBlank { "media_${System.currentTimeMillis()}" }

        var candidate = "$cleanBase.$extClean"
        var index = 1
        while (doesFileExistInSaviorDownloads(context, candidate) || reservedNamesInSession.contains(candidate.lowercase(Locale.ROOT))) {
            candidate = "$cleanBase ($index).$extClean"
            index++
        }
        reservedNamesInSession.add(candidate.lowercase(Locale.ROOT))
        return candidate
    }

    @Synchronized
    internal fun releaseReservedFileName(fileName: String) {
        reservedNamesInSession.remove(fileName.lowercase(Locale.ROOT))
    }

    private fun doesFileExistInSaviorDownloads(context: Context, displayName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val projection = arrayOf(MediaStore.MediaColumns._ID)
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
                val selectionArgs = arrayOf(displayName, "$RELATIVE_SAVIOR_DIR%")
                context.contentResolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    null
                )?.use { cursor ->
                    cursor.moveToFirst()
                } ?: false
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val saviorDir = File(File(downloadsDir, "Aura"), "Savior")
                File(saviorDir, displayName).exists()
            }
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Tải MediaItem (video hoặc âm thanh) và phát tiến trình qua Flow<DownloadProgress>.
     */
    fun downloadMedia(
        context: Context,
        item: MediaItem,
        audioOnly: Boolean
    ): Flow<DownloadProgress> = flow {
        val appContext = context.applicationContext
        val baseTitle = sanitizeBaseTitle(item.pageTitle, item.url)

        val needsAudioExtractionFromVideo = audioOnly && item.kind != MediaKind.AUDIO

        var connection: HttpURLConnection? = null
        try {
            connection = (URL(item.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 20000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", FIREFOX_ANDROID_USER_AGENT)
                if (item.pageUrl.isNotBlank()) {
                    setRequestProperty("Referer", item.pageUrl)
                }
            }
            connection.connect()

            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw IllegalStateException("HTTP $responseCode khi tải media")
            }

            val contentType = connection.contentType?.substringBefore(';')?.trim()
            val rawLength = connection.contentLengthLong
            val totalBytes: Long? = if (rawLength > 0L) rawLength else item.sizeBytes?.takeIf { it > 0L }

            val detectedExt = resolveExtension(item.url, contentType, item.kind)
            val detectedMime = resolveMimeType(detectedExt, contentType, item.kind)

            if (!needsAudioExtractionFromVideo) {
                // Tải thẳng vào Downloads/Aura/Savior
                val targetFileName = buildUniqueFileName(appContext, baseTitle, detectedExt)
                emit(DownloadProgress(downloaded = 0L, total = totalBytes, fileName = targetFileName))

                connection.inputStream.use { inputStream ->
                    val savedFile = streamToSaviorDownloads(
                        context = appContext,
                        inputStream = inputStream,
                        fileName = targetFileName,
                        mimeType = detectedMime,
                        totalBytes = totalBytes,
                        onProgress = { downloaded ->
                            emit(
                                DownloadProgress(
                                    downloaded = downloaded,
                                    total = totalBytes,
                                    fileName = targetFileName
                                )
                            )
                        }
                    )
                    emit(
                        DownloadProgress(
                            downloaded = totalBytes ?: savedFile.second,
                            total = totalBytes ?: savedFile.second,
                            fileName = targetFileName,
                            completedFile = savedFile.first
                        )
                    )
                }
            } else {
                // Tải về file tạm trong cacheDir rồi tách track âm thanh bằng MediaExtractor + MediaMuxer
                val tempDir = File(appContext.cacheDir, "savior_temp").apply { mkdirs() }
                val tempVideoFile = File(tempDir, "temp_video_${System.currentTimeMillis()}_${item.id.hashCode()}.$detectedExt")
                val previewAudioName = "$baseTitle.m4a"
                emit(DownloadProgress(downloaded = 0L, total = totalBytes, fileName = previewAudioName))

                var downloadedBytes = 0L
                try {
                    connection.inputStream.use { input ->
                        FileOutputStream(tempVideoFile).use { output ->
                            val buffer = ByteArray(64 * 1024)
                            var lastEmitTime = 0L
                            var read: Int
                            while (input.read(buffer).also { read = it } != -1) {
                                currentCoroutineContext().ensureActive()
                                output.write(buffer, 0, read)
                                downloadedBytes += read
                                val now = System.currentTimeMillis()
                                if (now - lastEmitTime >= 150L) {
                                    lastEmitTime = now
                                    emit(
                                        DownloadProgress(
                                            downloaded = downloadedBytes,
                                            total = totalBytes,
                                            fileName = previewAudioName
                                        )
                                    )
                                }
                            }
                            output.flush()
                        }
                    }
                } catch (e: Exception) {
                    try {
                        if (tempVideoFile.exists()) tempVideoFile.delete()
                    } catch (_: Exception) {}
                    throw e
                }

                currentCoroutineContext().ensureActive()
                emit(
                    DownloadProgress(
                        downloaded = downloadedBytes,
                        total = totalBytes ?: downloadedBytes,
                        fileName = previewAudioName,
                        isExtractingAudio = true
                    )
                )

                val isMp4Family = detectedExt in setOf("mp4", "m4v", "mov") ||
                    detectedMime in setOf("video/mp4", "video/quicktime", "video/x-m4v")

                val tempM4aFile = File(tempDir, "temp_audio_${System.currentTimeMillis()}_${item.id.hashCode()}.m4a")
                val extractedOk = if (isMp4Family) {
                    extractAudioTrackToM4a(tempVideoFile, tempM4aFile)
                } else {
                    false
                }

                if (extractedOk && tempM4aFile.exists() && tempM4aFile.length() > 0L) {
                    // Xoá file video tạm ngay lập tức và lưu file .m4a vào Downloads/Aura/Savior
                    try {
                        if (tempVideoFile.exists()) tempVideoFile.delete()
                    } catch (_: Exception) {}

                    val m4aFileName = buildUniqueFileName(appContext, baseTitle, "m4a")
                    try {
                        FileInputStream(tempM4aFile).use { m4aInput ->
                            val savedM4a = streamToSaviorDownloads(
                                context = appContext,
                                inputStream = m4aInput,
                                fileName = m4aFileName,
                                mimeType = "audio/mp4",
                                totalBytes = tempM4aFile.length(),
                                onProgress = {}
                            )
                            emit(
                                DownloadProgress(
                                    downloaded = savedM4a.second,
                                    total = savedM4a.second,
                                    fileName = m4aFileName,
                                    completedFile = savedM4a.first
                                )
                            )
                        }
                    } finally {
                        try {
                            if (tempM4aFile.exists()) tempM4aFile.delete()
                        } catch (_: Exception) {}
                    }
                } else {
                    try {
                        if (tempM4aFile.exists()) tempM4aFile.delete()
                    } catch (_: Exception) {}

                    // Báo "Không tách được âm thanh" và cho phép người dùng chọn lưu cả video từ file tạm
                    emit(
                        DownloadProgress(
                            downloaded = downloadedBytes,
                            total = totalBytes ?: downloadedBytes,
                            fileName = "$baseTitle.$detectedExt",
                            audioExtractionFallback = AudioExtractionFallback(
                                tempVideoFile = tempVideoFile,
                                baseTitle = baseTitle,
                                videoExtension = detectedExt,
                                videoMimeType = detectedMime
                            )
                        )
                    )
                }
            }
        } catch (e: CancellationException) {
            AppLogger.d("MediaDownloader", "Đã huỷ tải: ${item.url}")
            throw e
        } finally {
            try {
                connection?.disconnect()
            } catch (_: Exception) {}
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Tách track âm thanh từ file mp4/m4v/mov sang file .m4a bằng MediaExtractor + MediaMuxer (MUXER_OUTPUT_MPEG_4).
     */
    fun extractAudioTrackToM4a(sourceVideoFile: File, destM4aFile: File): Boolean {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        return try {
            extractor.setDataSource(sourceVideoFile.absolutePath)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/", ignoreCase = true)) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex < 0 || audioFormat == null) {
                AppLogger.d("MediaDownloader", "Không tìm thấy track audio trong file video")
                return false
            }

            extractor.selectTrack(audioTrackIndex)
            muxer = MediaMuxer(destM4aFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            val bufferCapacity = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(64 * 1024)
            } else {
                256 * 1024
            }
            val buffer = ByteBuffer.allocate(bufferCapacity)
            val bufferInfo = MediaCodec.BufferInfo()
            var hasWrittenSample = false

            while (true) {
                bufferInfo.offset = 0
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = extractor.sampleTime
                val sampleFlags = extractor.sampleFlags
                var codecFlags = 0
                if ((sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                    codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_KEY_FRAME
                }
                if ((sampleFlags and MediaExtractor.SAMPLE_FLAG_PARTIAL_FRAME) != 0) {
                    codecFlags = codecFlags or MediaCodec.BUFFER_FLAG_PARTIAL_FRAME
                }
                bufferInfo.flags = codecFlags
                muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                hasWrittenSample = true
                extractor.advance()
            }

            muxer.stop()
            hasWrittenSample && destM4aFile.exists() && destM4aFile.length() > 0L
        } catch (e: Exception) {
            AppLogger.d("MediaDownloader", "Lỗi tách âm thanh MediaMuxer: ${e.message}")
            try {
                if (destM4aFile.exists()) destM4aFile.delete()
            } catch (_: Exception) {}
            false
        } finally {
            try {
                muxer?.release()
            } catch (_: Exception) {}
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    /**
     * Lưu file video tạm (khi không tách được âm thanh nhưng người dùng đồng ý lưu cả video) vào Downloads/Aura/Savior.
     */
    suspend fun saveFallbackTempVideo(
        context: Context,
        fallback: AudioExtractionFallback
    ): DownloadedMediaFile? = withContext(Dispatchers.IO) {
        val tempFile = fallback.tempVideoFile
        if (!tempFile.exists()) return@withContext null
        val fileName = buildUniqueFileName(context, fallback.baseTitle, fallback.videoExtension)
        try {
            FileInputStream(tempFile).use { input ->
                val result = streamToSaviorDownloads(
                    context = context,
                    inputStream = input,
                    fileName = fileName,
                    mimeType = fallback.videoMimeType,
                    totalBytes = tempFile.length(),
                    onProgress = {}
                )
                result.first
            }
        } catch (e: Exception) {
            AppLogger.d("MediaDownloader", "Lỗi lưu video dự phòng: ${e.message}")
            releaseReservedFileName(fileName)
            null
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Exception) {}
        }
    }

    fun discardFallbackTempVideo(fallback: AudioExtractionFallback) {
        try {
            if (fallback.tempVideoFile.exists()) {
                fallback.tempVideoFile.delete()
            }
        } catch (_: Exception) {}
    }

    internal suspend fun streamToSaviorDownloads(
        context: Context,
        inputStream: InputStream,
        fileName: String,
        mimeType: String,
        totalBytes: Long?,
        onProgress: suspend (Long) -> Unit
    ): Pair<DownloadedMediaFile, Long> {
        var totalWritten = 0L
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, RELATIVE_SAVIOR_DIR)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val fileUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                ?: run {
                    releaseReservedFileName(fileName)
                    throw IllegalStateException("Không tạo được file trong MediaStore ($RELATIVE_SAVIOR_DIR)")
                }

            try {
                resolver.openOutputStream(fileUri)?.use { outputStream ->
                    val buffer = ByteArray(64 * 1024)
                    var lastEmitTime = 0L
                    var bytesRead: Int
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        currentCoroutineContext().ensureActive()
                        outputStream.write(buffer, 0, bytesRead)
                        totalWritten += bytesRead
                        val now = System.currentTimeMillis()
                        if (now - lastEmitTime >= 150L || (totalBytes != null && totalWritten >= totalBytes)) {
                            lastEmitTime = now
                            onProgress(totalWritten)
                        }
                    }
                    outputStream.flush()
                } ?: throw IllegalStateException("Không thể mở luồng ghi vào MediaStore")

                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(fileUri, contentValues, null, null)

                return DownloadedMediaFile(
                    fileName = fileName,
                    uri = fileUri,
                    mimeType = mimeType
                ) to totalWritten
            } catch (e: Exception) {
                // Xoá file dở khi huỷ hoặc lỗi
                try {
                    resolver.delete(fileUri, null, null)
                } catch (_: Exception) {}
                releaseReservedFileName(fileName)
                throw e
            }
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val saviorDir = File(File(downloadsDir, "Aura"), "Savior")
            if (!saviorDir.exists()) {
                saviorDir.mkdirs()
            }
            val targetFile = File(saviorDir, fileName)
            try {
                FileOutputStream(targetFile).use { outputStream ->
                    val buffer = ByteArray(64 * 1024)
                    var lastEmitTime = 0L
                    var bytesRead: Int
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        currentCoroutineContext().ensureActive()
                        outputStream.write(buffer, 0, bytesRead)
                        totalWritten += bytesRead
                        val now = System.currentTimeMillis()
                        if (now - lastEmitTime >= 150L || (totalBytes != null && totalWritten >= totalBytes)) {
                            lastEmitTime = now
                            onProgress(totalWritten)
                        }
                    }
                    outputStream.flush()
                }
                return DownloadedMediaFile(
                    fileName = fileName,
                    uri = Uri.fromFile(targetFile),
                    mimeType = mimeType
                ) to totalWritten
            } catch (e: Exception) {
                // Xoá file dở khi huỷ hoặc lỗi
                try {
                    if (targetFile.exists()) targetFile.delete()
                } catch (_: Exception) {}
                releaseReservedFileName(fileName)
                throw e
            }
        }
    }
}
