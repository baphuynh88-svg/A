package com.example.gecko

import android.content.Context
import android.util.Log
import com.example.util.AppLogger
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.util.Collections
import java.util.WeakHashMap

object GeckoEngine {
    const val UBLOCK_EXTENSION_ID = "uBlock0@raymondhill.net"
    const val UBLOCK_DOWNLOAD_URL = "https://addons.mozilla.org/firefox/downloads/latest/ublock-origin/latest.xpi"

    const val CLEAN_OVERLAY_EXTENSION_ID = "cleanoverlay@aura.browser"
    const val CLEAN_OVERLAY_ASSET_URI = "resource://android/assets/extensions/cleanoverlay/"

    const val HIDE_BLOCKED_EXTENSION_ID = "hideblocked@aura.browser"
    const val HIDE_BLOCKED_ASSET_URI = "resource://android/assets/extensions/hideblocked/"

    const val BG_PLAY_EXTENSION_ID = "bgplay@aura.browser"
    const val BG_PLAY_ASSET_URI = "resource://android/assets/extensions/bgplay/"

    const val SAVIOR_EXTENSION_ID = "savior@aura.browser"
    const val SAVIOR_ASSET_URI = "resource://android/assets/extensions/savior/"

    const val NATIVE_APP_NAME = "browser"

    @Volatile
    private var runtime: GeckoRuntime? = null

    @Volatile
    private var isInstallingUblock = false

    @Volatile
    private var cleanOverlayExtension: WebExtension? = null

    @Volatile
    private var hideBlockedExtension: WebExtension? = null

    @Volatile
    private var bgPlayExtension: WebExtension? = null

    @Volatile
    private var saviorExtension: WebExtension? = null

    @Volatile
    private var isSaviorEnabledFlag: Boolean = true

    @Volatile
    var actionDelegateCallback: ((GeckoSession?, String?) -> Unit)? = null

    @Volatile
    var onOverlayRemovedCallback: ((host: String) -> Unit)? = null

    @Volatile
    var getBlockedHostsCallback: (() -> Set<String>)? = null

    @Volatile
    var onSaviorMediaDetectedCallback: ((SaviorMediaPayload) -> Unit)? = null

    private val attachedSessions: MutableSet<GeckoSession> =
        Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap<GeckoSession, Boolean>()))

    private val sessionTabIds: MutableMap<GeckoSession, String> =
        Collections.synchronizedMap(WeakHashMap<GeckoSession, String>())

    private val hideBlockedPorts: MutableSet<WebExtension.Port> =
        Collections.synchronizedSet(Collections.newSetFromMap(WeakHashMap<WebExtension.Port, Boolean>()))

    private val cleanOverlayMessageDelegate = object : WebExtension.MessageDelegate {
        override fun onMessage(
            nativeApp: String,
            message: Any,
            sender: WebExtension.MessageSender
        ): GeckoResult<Any>? {
            try {
                when (message) {
                    is JSONObject -> {
                        if (message.optString("type") == "overlay_removed") {
                            val host = message.optString("host", "")
                            AppLogger.d("GeckoEngine", "Clean Overlay: nhận overlay_removed, host=$host")
                            onOverlayRemovedCallback?.invoke(host)
                        }
                    }
                    is String -> {
                        val json = JSONObject(message)
                        if (json.optString("type") == "overlay_removed") {
                            val host = json.optString("host", "")
                            AppLogger.d("GeckoEngine", "Clean Overlay: nhận overlay_removed, host=$host")
                            onOverlayRemovedCallback?.invoke(host)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("GeckoEngine", "Failed to handle Clean Overlay message", e)
            }
            return null
        }
    }

    private fun setupCleanOverlayMessageDelegate(extension: WebExtension) {
        try {
            extension.setMessageDelegate(cleanOverlayMessageDelegate, NATIVE_APP_NAME)
        } catch (e: Exception) {
            Log.e("GeckoEngine", "Failed to set extension message delegate", e)
        }
        synchronized(attachedSessions) {
            for (session in attachedSessions) {
                try {
                    session.webExtensionController.setMessageDelegate(
                        extension,
                        cleanOverlayMessageDelegate,
                        NATIVE_APP_NAME
                    )
                } catch (_: Exception) {}
            }
        }
    }

    private val hideBlockedMessageDelegate = object : WebExtension.MessageDelegate {
        override fun onMessage(
            nativeApp: String,
            message: Any,
            sender: WebExtension.MessageSender
        ): GeckoResult<Any>? {
            try {
                val type = when (message) {
                    is JSONObject -> message.optString("type")
                    is String -> JSONObject(message).optString("type")
                    else -> ""
                }
                if (type == "get_blocked") {
                    val hosts = getBlockedHostsCallback?.invoke() ?: emptySet()
                    AppLogger.d("GeckoEngine", "Hide Blocked: nhận get_blocked, số host=${hosts.size}")
                    val response = JSONObject().apply {
                        put("hosts", JSONArray(hosts.toList()))
                    }
                    return GeckoResult.fromValue(response)
                }
            } catch (e: Exception) {
                Log.e("GeckoEngine", "Failed to handle Hide Blocked message", e)
            }
            return null
        }

        // Hỗ trợ thêm kết nối qua Port (connectNative) làm phương án dự phòng nếu sendNativeMessage không nhận được phản hồi trực tiếp
        override fun onConnect(port: WebExtension.Port) {
            hideBlockedPorts.add(port)
            val initialHosts = getBlockedHostsCallback?.invoke() ?: emptySet()
            AppLogger.d("GeckoEngine", "Hide Blocked: nhận get_blocked, số host=${initialHosts.size}")
            port.setDelegate(object : WebExtension.PortDelegate {
                override fun onPortMessage(message: Any, port: WebExtension.Port) {
                    val hosts = getBlockedHostsCallback?.invoke() ?: emptySet()
                    AppLogger.d("GeckoEngine", "Hide Blocked: nhận get_blocked, số host=${hosts.size}")
                    sendBlockedHostsToPort(port)
                }

                override fun onDisconnect(port: WebExtension.Port) {
                    hideBlockedPorts.remove(port)
                }
            })
            sendBlockedHostsToPort(port)
        }
    }

    private fun sendBlockedHostsToPort(port: WebExtension.Port) {
        try {
            val hosts = getBlockedHostsCallback?.invoke() ?: emptySet()
            val payload = JSONObject().apply {
                put("type", "blocked_hosts")
                put("hosts", JSONArray(hosts.toList()))
            }
            port.postMessage(payload)
        } catch (e: Exception) {
            Log.e("GeckoEngine", "Failed to post blocked hosts to port", e)
        }
    }

    fun notifyBlockedHostsChanged() {
        synchronized(hideBlockedPorts) {
            for (port in hideBlockedPorts) {
                sendBlockedHostsToPort(port)
            }
        }
    }

    private fun setupHideBlockedMessageDelegate(extension: WebExtension) {
        try {
            extension.setMessageDelegate(hideBlockedMessageDelegate, NATIVE_APP_NAME)
        } catch (e: Exception) {
            Log.e("GeckoEngine", "Failed to set Hide Blocked extension message delegate", e)
        }
        synchronized(attachedSessions) {
            for (session in attachedSessions) {
                try {
                    session.webExtensionController.setMessageDelegate(
                        extension,
                        hideBlockedMessageDelegate,
                        NATIVE_APP_NAME
                    )
                } catch (_: Exception) {}
            }
        }
    }

    private fun parseAndDispatchSaviorMessage(
        message: Any,
        knownTabId: String?,
        sender: WebExtension.MessageSender
    ) {
        if (!isSaviorEnabledFlag) return
        try {
            val json = when (message) {
                is JSONObject -> message
                is String -> JSONObject(message)
                else -> return
            }
            if (json.optString("type") != "media") return

            val rawUrl = json.optString("url", "").trim()
            if (rawUrl.isBlank() ||
                rawUrl.startsWith("blob:", ignoreCase = true) ||
                rawUrl.startsWith("data:", ignoreCase = true)
            ) {
                return
            }

            val kind = MediaKind.fromRaw(json.optString("kind", "video"))
            val isProtected = json.optBoolean("protected", false)
            val durationRaw = json.optDouble("duration", 0.0)
            val durationSec = if (durationRaw.isFinite() && durationRaw > 0.0) durationRaw else 0.0
            val pageUrl = json.optString("tabUrl", "").ifBlank { json.optString("page", "") }
            val pageTitle = json.optString("title", "")

            val resolvedTabId = knownTabId ?: sender.session?.let { sessionTabIds[it] }

            onSaviorMediaDetectedCallback?.invoke(
                SaviorMediaPayload(
                    tabId = resolvedTabId,
                    url = rawUrl,
                    kind = kind,
                    pageUrl = pageUrl,
                    pageTitle = pageTitle,
                    isProtected = isProtected,
                    durationSec = durationSec
                )
            )
        } catch (e: Exception) {
            Log.e("GeckoEngine", "Failed to handle Savior message", e)
        }
    }

    private fun createSaviorSessionMessageDelegate(
        session: GeckoSession,
        tabId: String?
    ): WebExtension.MessageDelegate {
        return object : WebExtension.MessageDelegate {
            override fun onMessage(
                nativeApp: String,
                message: Any,
                sender: WebExtension.MessageSender
            ): GeckoResult<Any>? {
                val resolvedTabId = tabId ?: sessionTabIds[session]
                parseAndDispatchSaviorMessage(message, resolvedTabId, sender)
                return null
            }
        }
    }

    // Đường dự phòng ở cấp extension nếu tin nhắn được background.js chuyển tiếp
    private val saviorExtensionMessageDelegate = object : WebExtension.MessageDelegate {
        override fun onMessage(
            nativeApp: String,
            message: Any,
            sender: WebExtension.MessageSender
        ): GeckoResult<Any>? {
            val resolvedTabId = sender.session?.let { sessionTabIds[it] }
            parseAndDispatchSaviorMessage(message, resolvedTabId, sender)
            return null
        }
    }

    private fun setupSaviorMessageDelegate(extension: WebExtension) {
        try {
            extension.setMessageDelegate(saviorExtensionMessageDelegate, NATIVE_APP_NAME)
        } catch (e: Exception) {
            Log.e("GeckoEngine", "Failed to set Savior extension message delegate", e)
        }
        synchronized(attachedSessions) {
            for (session in attachedSessions) {
                try {
                    val tabId = sessionTabIds[session]
                    session.webExtensionController.setMessageDelegate(
                        extension,
                        createSaviorSessionMessageDelegate(session, tabId),
                        NATIVE_APP_NAME
                    )
                } catch (_: Exception) {}
            }
        }
    }

    fun attachSessionMessageDelegate(session: GeckoSession, tabId: String? = null) {
        attachedSessions.add(session)
        if (tabId != null) {
            sessionTabIds[session] = tabId
        }
        cleanOverlayExtension?.let { ext ->
            try {
                session.webExtensionController.setMessageDelegate(
                    ext,
                    cleanOverlayMessageDelegate,
                    NATIVE_APP_NAME
                )
            } catch (e: Exception) {
                Log.e("GeckoEngine", "Failed to attach Clean Overlay session message delegate", e)
            }
        }
        hideBlockedExtension?.let { ext ->
            try {
                session.webExtensionController.setMessageDelegate(
                    ext,
                    hideBlockedMessageDelegate,
                    NATIVE_APP_NAME
                )
            } catch (e: Exception) {
                Log.e("GeckoEngine", "Failed to attach Hide Blocked session message delegate", e)
            }
        }
        saviorExtension?.let { ext ->
            try {
                session.webExtensionController.setMessageDelegate(
                    ext,
                    createSaviorSessionMessageDelegate(session, sessionTabIds[session]),
                    NATIVE_APP_NAME
                )
            } catch (e: Exception) {
                Log.e("GeckoEngine", "Failed to attach Savior session message delegate", e)
            }
        }
    }

    private fun setupActionDelegate(extension: WebExtension) {
        extension.setActionDelegate(object : WebExtension.ActionDelegate {
            override fun onBrowserAction(
                extension: WebExtension,
                session: GeckoSession?,
                action: WebExtension.Action
            ) {
                actionDelegateCallback?.invoke(session, action.badgeText)
            }

            override fun onPageAction(
                extension: WebExtension,
                session: GeckoSession?,
                action: WebExtension.Action
            ) {
                actionDelegateCallback?.invoke(session, action.badgeText)
            }
        })
    }

    fun getRuntime(
        context: Context,
        blockThirdPartyCookies: Boolean = false,
        ublockEnabled: Boolean = true,
        cleanOverlayEnabled: Boolean = true,
        backgroundPlayEnabled: Boolean = true,
        saviorEnabled: Boolean = true,
        onUblockInstallError: ((String) -> Unit)? = null
    ): GeckoRuntime {
        isSaviorEnabledFlag = saviorEnabled
        return runtime ?: synchronized(this) {
            runtime ?: run {
                val cookieBehavior = if (blockThirdPartyCookies) {
                    ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY
                } else {
                    ContentBlocking.CookieBehavior.ACCEPT_ALL
                }
                val cbSettings = ContentBlocking.Settings.Builder()
                    .cookieBehavior(cookieBehavior)
                    .build()

                val settings = GeckoRuntimeSettings.Builder()
                    .contentBlocking(cbSettings)
                    .build()

                val newRuntime = GeckoRuntime.create(context.applicationContext, settings)
                runtime = newRuntime

                val controller = newRuntime.webExtensionController
                setupPromptDelegate(controller)
                initUblockOrigin(controller, ublockEnabled, onUblockInstallError)
                initCleanOverlay(controller, cleanOverlayEnabled)
                initHideBlocked(controller)
                initBackgroundPlay(controller, backgroundPlayEnabled)
                initSavior(controller, saviorEnabled)

                newRuntime
            }
        }
    }

    private fun isTrustedExtension(extension: WebExtension): Boolean {
        return extension.id == UBLOCK_EXTENSION_ID ||
                extension.id == CLEAN_OVERLAY_EXTENSION_ID ||
                extension.id == HIDE_BLOCKED_EXTENSION_ID ||
                extension.id == BG_PLAY_EXTENSION_ID ||
                extension.id == SAVIOR_EXTENSION_ID
    }

    private fun setupPromptDelegate(controller: WebExtensionController) {
        controller.promptDelegate = object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<out String>,
                origins: Array<out String>,
                dataCollectionPermissions: Array<out String>
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                val allowed = isTrustedExtension(extension)
                return GeckoResult.fromValue(
                    WebExtension.PermissionPromptResponse(
                        allowed,
                        allowed,
                        allowed
                    )
                )
            }

            override fun onUpdatePrompt(
                extension: WebExtension,
                permissions: Array<out String>,
                origins: Array<out String>,
                dataCollectionPermissions: Array<out String>
            ): GeckoResult<AllowOrDeny>? {
                return if (isTrustedExtension(extension)) {
                    GeckoResult.fromValue(AllowOrDeny.ALLOW)
                } else {
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                }
            }

            override fun onOptionalPrompt(
                extension: WebExtension,
                permissions: Array<out String>,
                origins: Array<out String>,
                dataCollectionPermissions: Array<out String>
            ): GeckoResult<AllowOrDeny>? {
                return if (isTrustedExtension(extension)) {
                    GeckoResult.fromValue(AllowOrDeny.ALLOW)
                } else {
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                }
            }
        }
    }

    // Ghi chú GeckoView 136: WebExtensionController.ensureBuiltIn(uri, id) và installBuiltIn(uri)
    // không còn nhận tham số cờ WebExtension.Flags.ALLOW_CONTENT_MESSAGING (cờ này thuộc constructor
    // WebExtension cũ đã bị loại bỏ). Việc cho phép content script gọi sendNativeMessage / connectNative
    // trên GeckoView 136 được quyết định hoàn toàn bởi quyền "nativeMessagingFromContent" (cùng với
    // "nativeMessaging" và "geckoViewAddons") khai báo trong manifest.json.
    fun initCleanOverlay(
        controller: WebExtensionController,
        desiredEnabled: Boolean
    ) {
        controller.ensureBuiltIn(CLEAN_OVERLAY_ASSET_URI, CLEAN_OVERLAY_EXTENSION_ID).accept({ ext ->
            if (ext != null) {
                cleanOverlayExtension = ext
                setupCleanOverlayMessageDelegate(ext)
                if (desiredEnabled && !ext.metaData.enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER).accept({ enabledExt ->
                        if (enabledExt != null) {
                            cleanOverlayExtension = enabledExt
                            setupCleanOverlayMessageDelegate(enabledExt)
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to enable Clean Overlay", err)
                    })
                } else if (!desiredEnabled && ext.metaData.enabled) {
                    controller.disable(ext, WebExtensionController.EnableSource.USER).accept({ disabledExt ->
                        if (disabledExt != null) {
                            cleanOverlayExtension = disabledExt
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to disable Clean Overlay", err)
                    })
                }
            }
        }, { error ->
            Log.e("GeckoEngine", "ensureBuiltIn failed for Clean Overlay, fallback to installBuiltIn", error)
            controller.installBuiltIn(CLEAN_OVERLAY_ASSET_URI).accept({ installedExt ->
                if (installedExt != null) {
                    cleanOverlayExtension = installedExt
                    setupCleanOverlayMessageDelegate(installedExt)
                    if (!desiredEnabled) {
                        controller.disable(installedExt, WebExtensionController.EnableSource.USER)
                    }
                }
            }, { installErr ->
                Log.e("GeckoEngine", "Failed to installBuiltIn Clean Overlay", installErr)
            })
        })
    }

    fun setCleanOverlayEnabled(enabled: Boolean, onComplete: ((Boolean) -> Unit)? = null) {
        val currentRuntime = runtime ?: run {
            onComplete?.invoke(false)
            return
        }
        val controller = currentRuntime.webExtensionController

        controller.list().accept({ extensions ->
            val ext = extensions?.find { it.id == CLEAN_OVERLAY_EXTENSION_ID } ?: cleanOverlayExtension
            if (ext != null) {
                val result = if (enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER)
                } else {
                    controller.disable(ext, WebExtensionController.EnableSource.USER)
                }
                result.accept({ updatedExt ->
                    if (updatedExt != null) {
                        cleanOverlayExtension = updatedExt
                        setupCleanOverlayMessageDelegate(updatedExt)
                    }
                    onComplete?.invoke(true)
                }, { err ->
                    Log.e("GeckoEngine", "Failed to toggle Clean Overlay state", err)
                    onComplete?.invoke(false)
                })
            } else {
                initCleanOverlay(controller, enabled)
                onComplete?.invoke(true)
            }
        }, { err ->
            Log.e("GeckoEngine", "Failed to list extensions for Clean Overlay", err)
            onComplete?.invoke(false)
        })
    }

    fun initHideBlocked(controller: WebExtensionController) {
        controller.ensureBuiltIn(HIDE_BLOCKED_ASSET_URI, HIDE_BLOCKED_EXTENSION_ID).accept({ ext ->
            if (ext != null) {
                hideBlockedExtension = ext
                setupHideBlockedMessageDelegate(ext)
                if (!ext.metaData.enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER).accept({ enabledExt ->
                        if (enabledExt != null) {
                            hideBlockedExtension = enabledExt
                            setupHideBlockedMessageDelegate(enabledExt)
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to enable Hide Blocked", err)
                    })
                }
            }
        }, { error ->
            Log.e("GeckoEngine", "ensureBuiltIn failed for Hide Blocked, fallback to installBuiltIn", error)
            controller.installBuiltIn(HIDE_BLOCKED_ASSET_URI).accept({ installedExt ->
                if (installedExt != null) {
                    hideBlockedExtension = installedExt
                    setupHideBlockedMessageDelegate(installedExt)
                }
            }, { installErr ->
                Log.e("GeckoEngine", "Failed to installBuiltIn Hide Blocked", installErr)
            })
        })
    }

    // Ghi chú cơ chế nhận tin nhắn Savior trên GeckoView 136:
    // 1. Đường chính: manifest.json của Savior khai báo quyền "nativeMessagingFromContent" và "geckoViewAddons"
    //    nên content.js gọi trực tiếp browser.runtime.sendNativeMessage("browser", ...) và được nhận bởi
    //    session.webExtensionController.setMessageDelegate(extension, delegate, "browser") của đúng GeckoSession/tabId.
    // 2. Đường dự phòng: nếu sendNativeMessage từ content script bị từ chối/lỗi, content.js chuyển qua
    //    browser.runtime.sendMessage tới background.js để gửi tiếp bằng sendNativeMessage kèm tabUrl,
    //    và được nhận ở cấp extension (extension.setMessageDelegate) rồi ghép tab theo URL trang đang mở.
    fun initSavior(
        controller: WebExtensionController,
        desiredEnabled: Boolean = true
    ) {
        isSaviorEnabledFlag = desiredEnabled
        controller.ensureBuiltIn(SAVIOR_ASSET_URI, SAVIOR_EXTENSION_ID).accept({ ext ->
            if (ext != null) {
                saviorExtension = ext
                setupSaviorMessageDelegate(ext)
                if (desiredEnabled && !ext.metaData.enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER).accept({ enabledExt ->
                        if (enabledExt != null) {
                            saviorExtension = enabledExt
                            setupSaviorMessageDelegate(enabledExt)
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to enable Savior", err)
                    })
                } else if (!desiredEnabled && ext.metaData.enabled) {
                    controller.disable(ext, WebExtensionController.EnableSource.USER).accept({ disabledExt ->
                        if (disabledExt != null) {
                            saviorExtension = disabledExt
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to disable Savior", err)
                    })
                }
            }
        }, { error ->
            Log.e("GeckoEngine", "ensureBuiltIn failed for Savior, fallback to installBuiltIn", error)
            controller.installBuiltIn(SAVIOR_ASSET_URI).accept({ installedExt ->
                if (installedExt != null) {
                    saviorExtension = installedExt
                    setupSaviorMessageDelegate(installedExt)
                    if (!desiredEnabled) {
                        controller.disable(installedExt, WebExtensionController.EnableSource.USER)
                    }
                }
            }, { installErr ->
                Log.e("GeckoEngine", "Failed to installBuiltIn Savior", installErr)
            })
        })
    }

    fun setSaviorEnabled(enabled: Boolean, onComplete: ((Boolean) -> Unit)? = null) {
        isSaviorEnabledFlag = enabled
        val currentRuntime = runtime ?: run {
            onComplete?.invoke(false)
            return
        }
        val controller = currentRuntime.webExtensionController

        controller.list().accept({ extensions ->
            val ext = extensions?.find { it.id == SAVIOR_EXTENSION_ID } ?: saviorExtension
            if (ext != null) {
                val result = if (enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER)
                } else {
                    controller.disable(ext, WebExtensionController.EnableSource.USER)
                }
                result.accept({ updatedExt ->
                    if (updatedExt != null) {
                        saviorExtension = updatedExt
                        setupSaviorMessageDelegate(updatedExt)
                    }
                    onComplete?.invoke(true)
                }, { err ->
                    Log.e("GeckoEngine", "Failed to toggle Savior state", err)
                    onComplete?.invoke(false)
                })
            } else {
                initSavior(controller, enabled)
                onComplete?.invoke(true)
            }
        }, { err ->
            Log.e("GeckoEngine", "Failed to list extensions for Savior", err)
            onComplete?.invoke(false)
        })
    }

    fun initBackgroundPlay(
        controller: WebExtensionController,
        desiredEnabled: Boolean
    ) {
        controller.ensureBuiltIn(BG_PLAY_ASSET_URI, BG_PLAY_EXTENSION_ID).accept({ ext ->
            if (ext != null) {
                bgPlayExtension = ext
                if (desiredEnabled && !ext.metaData.enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER).accept({ enabledExt ->
                        if (enabledExt != null) {
                            bgPlayExtension = enabledExt
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to enable Background Play", err)
                    })
                } else if (!desiredEnabled && ext.metaData.enabled) {
                    controller.disable(ext, WebExtensionController.EnableSource.USER).accept({ disabledExt ->
                        if (disabledExt != null) {
                            bgPlayExtension = disabledExt
                        }
                    }, { err ->
                        Log.e("GeckoEngine", "Failed to disable Background Play", err)
                    })
                }
            }
        }, { error ->
            Log.e("GeckoEngine", "ensureBuiltIn failed for Background Play, fallback to installBuiltIn", error)
            controller.installBuiltIn(BG_PLAY_ASSET_URI).accept({ installedExt ->
                if (installedExt != null) {
                    bgPlayExtension = installedExt
                    if (!desiredEnabled) {
                        controller.disable(installedExt, WebExtensionController.EnableSource.USER)
                    }
                }
            }, { installErr ->
                Log.e("GeckoEngine", "Failed to installBuiltIn Background Play", installErr)
            })
        })
    }

    fun setBackgroundPlayEnabled(enabled: Boolean, onComplete: ((Boolean) -> Unit)? = null) {
        val currentRuntime = runtime ?: run {
            onComplete?.invoke(false)
            return
        }
        val controller = currentRuntime.webExtensionController

        controller.list().accept({ extensions ->
            val ext = extensions?.find { it.id == BG_PLAY_EXTENSION_ID } ?: bgPlayExtension
            if (ext != null) {
                val result = if (enabled) {
                    controller.enable(ext, WebExtensionController.EnableSource.USER)
                } else {
                    controller.disable(ext, WebExtensionController.EnableSource.USER)
                }
                result.accept({ updatedExt ->
                    if (updatedExt != null) {
                        bgPlayExtension = updatedExt
                    }
                    onComplete?.invoke(true)
                }, { err ->
                    Log.e("GeckoEngine", "Failed to toggle Background Play state", err)
                    onComplete?.invoke(false)
                })
            } else {
                initBackgroundPlay(controller, enabled)
                onComplete?.invoke(true)
            }
        }, { err ->
            Log.e("GeckoEngine", "Failed to list extensions for Background Play", err)
            onComplete?.invoke(false)
        })
    }

    fun initUblockOrigin(
        controller: WebExtensionController,
        desiredEnabled: Boolean,
        onError: ((String) -> Unit)? = null
    ) {
        if (isInstallingUblock) return

        controller.list().accept({ extensions ->
            val existing = extensions?.find { it.id == UBLOCK_EXTENSION_ID }
            if (existing != null) {
                setupActionDelegate(existing)
                // Extension already installed; synchronize desired enabled state
                if (desiredEnabled && !existing.metaData.enabled) {
                    controller.enable(existing, WebExtensionController.EnableSource.USER)
                } else if (!desiredEnabled && existing.metaData.enabled) {
                    controller.disable(existing, WebExtensionController.EnableSource.USER)
                }
            } else {
                // Not yet installed; install from official URL
                isInstallingUblock = true
                controller.install(UBLOCK_DOWNLOAD_URL).accept({ installedExt ->
                    isInstallingUblock = false
                    if (installedExt != null) {
                        setupActionDelegate(installedExt)
                        if (!desiredEnabled) {
                            controller.disable(installedExt, WebExtensionController.EnableSource.USER)
                        }
                    }
                }, { error ->
                    isInstallingUblock = false
                    Log.e("GeckoEngine", "Failed to install uBlock Origin", error)
                    onError?.invoke("Không thể tải uBlock Origin (kiểm tra kết nối mạng). Sẽ thử lại sau.")
                })
            }
        }, { error ->
            Log.e("GeckoEngine", "Failed to query extension list", error)
        })
    }

    fun setUblockEnabled(enabled: Boolean, onComplete: ((Boolean) -> Unit)? = null) {
        val currentRuntime = runtime ?: return
        val controller = currentRuntime.webExtensionController

        controller.list().accept({ extensions ->
            val ublock = extensions?.find { it.id == UBLOCK_EXTENSION_ID }
            if (ublock != null) {
                val result = if (enabled) {
                    controller.enable(ublock, WebExtensionController.EnableSource.USER)
                } else {
                    controller.disable(ublock, WebExtensionController.EnableSource.USER)
                }
                result.accept({
                    onComplete?.invoke(true)
                }, { err ->
                    Log.e("GeckoEngine", "Failed to toggle uBlock Origin state", err)
                    onComplete?.invoke(false)
                })
            } else {
                if (enabled) {
                    initUblockOrigin(controller, true)
                }
                onComplete?.invoke(false)
            }
        }, { err ->
            Log.e("GeckoEngine", "Failed to list extensions", err)
            onComplete?.invoke(false)
        })
    }

    fun setCookieBehavior(blockThirdPartyCookies: Boolean) {
        val cookieBehavior = if (blockThirdPartyCookies) {
            ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY
        } else {
            ContentBlocking.CookieBehavior.ACCEPT_ALL
        }
        runtime?.settings?.contentBlocking?.setCookieBehavior(cookieBehavior)
    }
}
