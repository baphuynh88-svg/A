package com.example.gecko

/**
 * Đại diện cho các hộp thoại prompt từ trang web (alert, confirm, text prompt, select dropdown).
 */
sealed class PagePrompt {
    abstract val tabId: String
    abstract val host: String
    abstract fun dismiss()

    data class Alert(
        override val tabId: String,
        override val host: String,
        val title: String,
        val message: String,
        val onConfirm: () -> Unit,
        val onDismiss: () -> Unit
    ) : PagePrompt() {
        override fun dismiss() = onDismiss()
    }

    data class Confirm(
        override val tabId: String,
        override val host: String,
        val title: String,
        val message: String,
        val onPositive: () -> Unit,
        val onNegative: () -> Unit,
        val onDismiss: () -> Unit
    ) : PagePrompt() {
        override fun dismiss() = onDismiss()
    }

    data class Text(
        override val tabId: String,
        override val host: String,
        val title: String,
        val message: String,
        val defaultValue: String,
        val onConfirm: (String) -> Unit,
        val onDismiss: () -> Unit
    ) : PagePrompt() {
        override fun dismiss() = onDismiss()
    }

    data class ChoiceItem(
        val id: String,
        val label: String,
        val isSelected: Boolean
    )

    data class Choice(
        override val tabId: String,
        override val host: String,
        val title: String,
        val message: String,
        val isMultiple: Boolean,
        val choices: List<ChoiceItem>,
        val onConfirmSingle: (String) -> Unit,
        val onConfirmMultiple: (Array<String>) -> Unit,
        val onDismiss: () -> Unit
    ) : PagePrompt() {
        override fun dismiss() = onDismiss()
    }
}
