package com.example.gecko

import android.os.SystemClock

/**
 * Giữ tiến trình nội dung Gecko ở mức ưu tiên cao thêm một lúc khi app xuống nền,
 * và trong suốt lúc bộ chọn file hệ thống đang mở, để Android ít giết (onKill) hơn.
 */
object BackgroundKeepAlive {
    const val GRACE_MS = 30_000L

    @Volatile
    var filePickerInProgress: Boolean = false

    @Volatile
    private var graceUntilElapsedMs: Long = 0L

    fun startGrace() {
        graceUntilElapsedMs = SystemClock.elapsedRealtime() + GRACE_MS
    }

    fun clearGrace() {
        graceUntilElapsedMs = 0L
    }

    fun shouldKeepActive(): Boolean =
        filePickerInProgress || SystemClock.elapsedRealtime() < graceUntilElapsedMs
}
