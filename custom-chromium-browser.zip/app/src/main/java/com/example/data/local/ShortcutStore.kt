package com.example.data.local

import android.content.Context
import android.net.Uri
import com.example.util.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ShortcutItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String
)

/**
 * Quản lý danh sách lối tắt trang chủ Aura Browser trong SharedPreferences (tối đa 12 mục).
 */
class ShortcutStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private var lastDeletedItem: ShortcutItem? = null
    private var lastDeletedIndex: Int = -1

    private val _shortcuts = MutableStateFlow<List<ShortcutItem>>(load())
    val shortcuts: StateFlow<List<ShortcutItem>> = _shortcuts.asStateFlow()

    private fun load(): List<ShortcutItem> {
        if (!prefs.contains(KEY_SHORTCUTS)) {
            persistToPrefs(DEFAULT_SHORTCUTS)
            return DEFAULT_SHORTCUTS
        }
        return try {
            val jsonString = prefs.getString(KEY_SHORTCUTS, null) ?: return DEFAULT_SHORTCUTS
            val arr = JSONArray(jsonString)
            val list = mutableListOf<ShortcutItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val url = obj.optString("url", "").trim()
                if (url.isBlank()) continue
                val title = obj.optString("title", "").trim().ifBlank {
                    SitePolicyStore.normalizeHost(url).ifBlank { url }
                }
                val id = obj.optString("id", "").trim().ifBlank {
                    UUID.randomUUID().toString()
                }
                list.add(ShortcutItem(id = id, title = title, url = url))
            }
            list.take(MAX_SHORTCUTS)
        } catch (e: Exception) {
            AppLogger.d(TAG, "Lỗi đọc lối tắt: ${e.message}")
            DEFAULT_SHORTCUTS
        }
    }

    private fun persistToPrefs(list: List<ShortcutItem>) {
        try {
            val arr = JSONArray()
            list.take(MAX_SHORTCUTS).forEach { item ->
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("url", item.url)
                }
                arr.put(obj)
            }
            prefs.edit().putString(KEY_SHORTCUTS, arr.toString()).apply()
        } catch (e: Exception) {
            AppLogger.d(TAG, "Lỗi lưu lối tắt: ${e.message}")
        }
    }

    private fun updateAndPersist(list: List<ShortcutItem>) {
        val capped = list.take(MAX_SHORTCUTS)
        _shortcuts.value = capped
        persistToPrefs(capped)
    }

    fun add(title: String, url: String): ShortcutItem? {
        val current = _shortcuts.value
        if (current.size >= MAX_SHORTCUTS) return null
        val normalizedUrl = normalizeAndValidateUrl(url) ?: return null
        val finalTitle = title.trim().ifBlank {
            SitePolicyStore.normalizeHost(normalizedUrl).ifBlank { normalizedUrl }
        }
        val newItem = ShortcutItem(
            id = UUID.randomUUID().toString(),
            title = finalTitle,
            url = normalizedUrl
        )
        updateAndPersist(current + newItem)
        return newItem
    }

    fun edit(id: String, title: String, url: String): Boolean {
        val current = _shortcuts.value
        val index = current.indexOfFirst { it.id == id }
        if (index == -1) return false
        val normalizedUrl = normalizeAndValidateUrl(url) ?: return false
        val finalTitle = title.trim().ifBlank {
            SitePolicyStore.normalizeHost(normalizedUrl).ifBlank { normalizedUrl }
        }
        val updated = current.toMutableList().apply {
            this[index] = this[index].copy(title = finalTitle, url = normalizedUrl)
        }
        updateAndPersist(updated)
        return true
    }

    fun update(id: String, title: String, url: String): Boolean = edit(id, title, url)

    fun remove(id: String): ShortcutItem? {
        val current = _shortcuts.value
        val index = current.indexOfFirst { it.id == id }
        if (index == -1) return null
        val removed = current[index]
        lastDeletedItem = removed
        lastDeletedIndex = index
        val updated = current.toMutableList().apply {
            removeAt(index)
        }
        updateAndPersist(updated)
        return removed
    }

    fun delete(id: String): ShortcutItem? = remove(id)

    fun restore(item: ShortcutItem? = lastDeletedItem, index: Int = lastDeletedIndex): Boolean {
        val targetItem = item ?: return false
        val current = _shortcuts.value
        if (current.size >= MAX_SHORTCUTS) return false
        if (current.any { it.id == targetItem.id }) return false
        val insertIndex = if (index in 0..current.size) index else current.size
        val updated = current.toMutableList().apply {
            add(insertIndex, targetItem)
        }
        if (targetItem.id == lastDeletedItem?.id) {
            lastDeletedItem = null
            lastDeletedIndex = -1
        }
        updateAndPersist(updated)
        return true
    }

    fun restore(index: Int, item: ShortcutItem): Boolean = restore(item, index)

    companion object {
        private const val TAG = "ShortcutStore"
        private const val PREFS_NAME = "aura_shortcuts"
        private const val KEY_SHORTCUTS = "shortcuts"
        const val MAX_SHORTCUTS = 12

        val DEFAULT_SHORTCUTS = listOf(
            ShortcutItem(id = "default_google", title = "Google", url = "https://www.google.com"),
            ShortcutItem(id = "default_spotify", title = "Spotify", url = "https://open.spotify.com"),
            ShortcutItem(id = "default_youtube", title = "YouTube", url = "https://www.youtube.com"),
            ShortcutItem(id = "default_wikipedia", title = "Wikipedia", url = "https://www.wikipedia.org"),
            ShortcutItem(id = "default_github", title = "GitHub", url = "https://github.com"),
            ShortcutItem(id = "default_reddit", title = "Reddit", url = "https://www.reddit.com"),
            ShortcutItem(id = "default_duckduckgo", title = "DuckDuckGo", url = "https://duckduckgo.com"),
            ShortcutItem(id = "default_mdn", title = "MDN Web", url = "https://developer.mozilla.org")
        )

        fun normalizeAndValidateUrl(rawUrl: String): String? {
            val trimmed = rawUrl.trim()
            if (trimmed.isBlank()) return null
            if (trimmed.any { it.isWhitespace() }) return null

            val withScheme = when {
                trimmed.startsWith("http://", ignoreCase = true) ->
                    "http://" + trimmed.substring(7)
                trimmed.startsWith("https://", ignoreCase = true) ->
                    "https://" + trimmed.substring(8)
                trimmed.contains("://") ->
                    return null
                else ->
                    "https://$trimmed"
            }

            val uri = try {
                Uri.parse(withScheme)
            } catch (_: Exception) {
                return null
            }

            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") return null

            val host = uri.host?.trim()?.lowercase()?.trimEnd('.') ?: return null
            if (host.isBlank()) return null

            val domainRegex = Regex("""^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$""")
            val ipv4Regex = Regex("""^(\d{1,3}\.){3}\d{1,3}$""")
            val isValidHost = host == "localhost" ||
                domainRegex.matches(host) ||
                (ipv4Regex.matches(host) && host.split('.').all { (it.toIntOrNull() ?: 999) in 0..255 })

            return if (isValidHost) withScheme else null
        }
    }
}
