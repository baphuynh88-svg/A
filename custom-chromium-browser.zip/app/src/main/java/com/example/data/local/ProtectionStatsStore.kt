package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class TabProtectionStats(
    val adsBlocked: Int = 0,
    val trackersBlocked: Int = 0,
    val popupsBlocked: Int = 0,
    val overlaysRemoved: Int = 0
) {
    val totalBlocked: Int get() = adsBlocked + trackersBlocked + popupsBlocked + overlaysRemoved
}

class ProtectionStatsStore(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("protection_stats_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Default + Job())

    companion object {
        private const val KEY_TOTAL_ADS = "total_ads_blocked"
        private const val KEY_TOTAL_TRACKERS = "total_trackers_blocked"
        private const val KEY_TOTAL_POPUPS = "total_popups_blocked"
        private const val KEY_OVERLAYS_REMOVED = "overlays_removed"
    }

    private val _totalAds = MutableStateFlow(prefs.getLong(KEY_TOTAL_ADS, 0L))
    val totalAds: StateFlow<Long> = _totalAds.asStateFlow()

    private val _totalTrackers = MutableStateFlow(prefs.getLong(KEY_TOTAL_TRACKERS, 0L))
    val totalTrackers: StateFlow<Long> = _totalTrackers.asStateFlow()

    private val _totalPopups = MutableStateFlow(prefs.getLong(KEY_TOTAL_POPUPS, 0L))
    val totalPopups: StateFlow<Long> = _totalPopups.asStateFlow()

    private val _overlaysRemoved = MutableStateFlow(prefs.getLong(KEY_OVERLAYS_REMOVED, 0L))
    val overlaysRemoved: StateFlow<Long> = _overlaysRemoved.asStateFlow()

    // Per-tab statistics (in-memory, reset on onPageStart)
    private val _tabStatsMap = MutableStateFlow<Map<String, TabProtectionStats>>(emptyMap())
    val tabStatsMap: StateFlow<Map<String, TabProtectionStats>> = _tabStatsMap.asStateFlow()

    // Last seen badge for delta calculation per tab
    private val lastSeenBadgeMap = ConcurrentHashMap<String, Int>()

    @Volatile
    private var isDirty = false

    init {
        // Start batched 3-second disk persistence loop
        scope.launch {
            while (true) {
                delay(3000)
                if (isDirty) {
                    flush()
                }
            }
        }
    }

    fun onPageStart(tabId: String) {
        lastSeenBadgeMap[tabId] = 0
        _tabStatsMap.update { current ->
            current + (tabId to TabProtectionStats(0, 0, 0))
        }
    }

    fun onTabClosed(tabId: String) {
        lastSeenBadgeMap.remove(tabId)
        _tabStatsMap.update { current ->
            current - tabId
        }
    }

    fun recordAdsBadge(tabId: String, badgeText: String?) {
        val currentCount = badgeText?.filter { it.isDigit() }?.toIntOrNull() ?: 0
        val lastCount = lastSeenBadgeMap[tabId] ?: 0

        if (currentCount > lastCount) {
            val delta = currentCount - lastCount
            lastSeenBadgeMap[tabId] = currentCount

            _totalAds.update { it + delta }
            isDirty = true

            _tabStatsMap.update { map ->
                val existing = map[tabId] ?: TabProtectionStats()
                map + (tabId to existing.copy(adsBlocked = currentCount))
            }
        } else if (currentCount < lastCount && currentCount > 0) {
            // Updated count from extension
            lastSeenBadgeMap[tabId] = currentCount
            _tabStatsMap.update { map ->
                val existing = map[tabId] ?: TabProtectionStats()
                map + (tabId to existing.copy(adsBlocked = currentCount))
            }
        }
    }

    fun recordTrackerBlocked(tabId: String) {
        _totalTrackers.update { it + 1 }
        isDirty = true

        _tabStatsMap.update { map ->
            val existing = map[tabId] ?: TabProtectionStats()
            map + (tabId to existing.copy(trackersBlocked = existing.trackersBlocked + 1))
        }
    }

    fun recordLogCrossReferenced(tabId: String, loggedCount: Int) {
        if (loggedCount <= 0) return
        _tabStatsMap.update { map ->
            val existing = map[tabId] ?: TabProtectionStats()
            if (loggedCount > existing.trackersBlocked) {
                val delta = loggedCount - existing.trackersBlocked
                _totalTrackers.update { it + delta }
                isDirty = true
                map + (tabId to existing.copy(trackersBlocked = loggedCount))
            } else {
                map
            }
        }
    }

    fun recordPopupBlocked(tabId: String) {
        _totalPopups.update { it + 1 }
        isDirty = true

        _tabStatsMap.update { map ->
            val existing = map[tabId] ?: TabProtectionStats()
            map + (tabId to existing.copy(popupsBlocked = existing.popupsBlocked + 1))
        }
        // Popup hiếm khi xuất hiện nên lưu ngay lập tức để không mất số đếm
        flush()
    }

    fun recordOverlayRemoved(tabId: String? = null) {
        _overlaysRemoved.update { it + 1 }
        isDirty = true

        if (tabId != null) {
            _tabStatsMap.update { map ->
                val existing = map[tabId] ?: TabProtectionStats()
                map + (tabId to existing.copy(overlaysRemoved = existing.overlaysRemoved + 1))
            }
        }
        flush()
    }

    fun resetTotals() {
        _totalAds.value = 0L
        _totalTrackers.value = 0L
        _totalPopups.value = 0L
        _overlaysRemoved.value = 0L
        isDirty = false

        try {
            prefs.edit()
                .putLong(KEY_TOTAL_ADS, 0L)
                .putLong(KEY_TOTAL_TRACKERS, 0L)
                .putLong(KEY_TOTAL_POPUPS, 0L)
                .putLong(KEY_OVERLAYS_REMOVED, 0L)
                .apply()
        } catch (_: Exception) {}
    }

    fun flush() {
        isDirty = false
        try {
            prefs.edit()
                .putLong(KEY_TOTAL_ADS, _totalAds.value)
                .putLong(KEY_TOTAL_TRACKERS, _totalTrackers.value)
                .putLong(KEY_TOTAL_POPUPS, _totalPopups.value)
                .putLong(KEY_OVERLAYS_REMOVED, _overlaysRemoved.value)
                .apply()
        } catch (_: Exception) {}
    }
}
