package com.example.data.local

import android.content.Context
import com.example.util.AppLogger
import org.json.JSONArray
import org.json.JSONObject

/**
 * Thông tin thu gọn của một tab để lưu trữ bền vững.
 */
data class SavedTabInfo(
    val id: String,
    val title: String,
    val url: String,
    val isStartPage: Boolean,
    val isDesktopMode: Boolean
)

/**
 * Dữ liệu toàn bộ phiên tab gồm danh sách các tab và tab đang được chọn.
 */
data class SavedSessionData(
    val tabs: List<SavedTabInfo>,
    val activeTabId: String?
)

/**
 * Quản lý lưu trữ phiên tab và cấu hình máy tìm kiếm vào SharedPreferences dưới dạng JSON.
 * Hỗ trợ lưu tối đa 50 tab, khôi phục lười (lazy restore), bảo vệ chống ghi đè khi tab rỗng.
 */
class TabSessionStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aura_tab_session", Context.MODE_PRIVATE)

    fun save(tabs: List<SavedTabInfo>, activeTabId: String?) {
        // Không lưu khi danh sách tab đang trống tạm thời (tránh ghi đè khi chuyển tab hoặc reset)
        if (tabs.isEmpty()) return
        try {
            val root = JSONObject()
            val arr = JSONArray()
            tabs.takeLast(MAX_TABS).forEach { tab ->
                val obj = JSONObject().apply {
                    put("id", tab.id)
                    put("title", tab.title)
                    put("url", tab.url)
                    put("isStartPage", tab.isStartPage)
                    put("isDesktopMode", tab.isDesktopMode)
                }
                arr.put(obj)
            }
            root.put("tabs", arr)
            root.put("activeTabId", activeTabId ?: "")
            prefs.edit().putString(KEY_SESSION_DATA, root.toString()).apply()
        } catch (e: Exception) {
            AppLogger.d("TabSessionStore", "Lỗi lưu phiên tab: ${e.message}")
        }
    }

    fun load(): SavedSessionData? {
        return try {
            val jsonString = prefs.getString(KEY_SESSION_DATA, null) ?: return null
            val root = JSONObject(jsonString)
            val arr = root.optJSONArray("tabs") ?: return null
            val list = mutableListOf<SavedTabInfo>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SavedTabInfo(
                        id = obj.getString("id"),
                        title = obj.optString("title", "New Tab"),
                        url = obj.optString("url", ""),
                        isStartPage = obj.optBoolean("isStartPage", false),
                        isDesktopMode = obj.optBoolean("isDesktopMode", false)
                    )
                )
            }
            if (list.isEmpty()) null
            else SavedSessionData(list, root.optString("activeTabId").ifBlank { null })
        } catch (e: Exception) {
            AppLogger.d("TabSessionStore", "Lỗi khôi phục phiên tab: ${e.message}")
            null
        }
    }

    fun saveSearchEngine(engineName: String) {
        try {
            prefs.edit().putString(KEY_SEARCH_ENGINE, engineName).apply()
        } catch (e: Exception) {
            AppLogger.d("TabSessionStore", "Lỗi lưu máy tìm kiếm: ${e.message}")
        }
    }

    fun loadSearchEngine(): String? {
        return try {
            prefs.getString(KEY_SEARCH_ENGINE, null)
        } catch (e: Exception) {
            AppLogger.d("TabSessionStore", "Lỗi đọc máy tìm kiếm: ${e.message}")
            null
        }
    }

    companion object {
        private const val KEY_SESSION_DATA = "tab_session_data"
        private const val KEY_SEARCH_ENGINE = "saved_search_engine"
        private const val MAX_TABS = 50
    }
}
