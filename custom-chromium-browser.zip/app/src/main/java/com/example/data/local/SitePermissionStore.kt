package com.example.data.local

import android.content.Context
import com.example.util.AppLogger

/**
 * Lưu trữ quyết định cấp quyền của người dùng theo từng trang web (host + loại quyền).
 * Lưu trong SharedPreferences "aura_site_permissions".
 */
class SitePermissionStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aura_site_permissions", Context.MODE_PRIVATE)

    fun getPermission(host: String, type: String): String? {
        return try {
            prefs.getString(makeKey(host, type), null)
        } catch (e: Exception) {
            AppLogger.d("SitePermissionStore", "Lỗi đọc quyền: ${e.message}")
            null
        }
    }

    fun setPermission(host: String, type: String, decision: String) {
        try {
            prefs.edit().putString(makeKey(host, type), decision).apply()
        } catch (e: Exception) {
            AppLogger.d("SitePermissionStore", "Lỗi lưu quyền: ${e.message}")
        }
    }

    fun clearPermission(host: String, type: String) {
        try {
            prefs.edit().remove(makeKey(host, type)).apply()
        } catch (e: Exception) {
            AppLogger.d("SitePermissionStore", "Lỗi xoá quyền: ${e.message}")
        }
    }

    fun clearAll() {
        try {
            prefs.edit().clear().apply()
        } catch (e: Exception) {
            AppLogger.d("SitePermissionStore", "Lỗi xoá toàn bộ quyền: ${e.message}")
        }
    }

    private fun makeKey(host: String, type: String): String {
        return "${host.lowercase().trim()}:$type"
    }

    companion object {
        const val ALLOW = "ALLOW"
        const val DENY = "DENY"

        const val TYPE_GEOLOCATION = "GEOLOCATION"
        const val TYPE_MEDIA = "MEDIA"
    }
}
