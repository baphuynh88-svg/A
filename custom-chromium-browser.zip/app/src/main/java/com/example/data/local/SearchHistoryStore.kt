package com.example.data.local

import android.content.Context
import com.example.util.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

/**
 * Quản lý lưu trữ lịch sử tìm kiếm người dùng vào SharedPreferences dưới dạng JSON array.
 * Giới hạn tối đa 20 mục, không trùng lặp hoa/thường, tự đưa từ khoá mới nhất lên đầu.
 */
class SearchHistoryStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aura_search_history", Context.MODE_PRIVATE)

    private val _queries = MutableStateFlow<List<String>>(load())
    val queries: StateFlow<List<String>> = _queries.asStateFlow()

    private fun load(): List<String> {
        return try {
            val jsonString = prefs.getString(KEY_QUERIES, "[]") ?: "[]"
            val arr = JSONArray(jsonString)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            AppLogger.d("SearchHistoryStore", "Lỗi đọc lịch sử tìm kiếm: ${e.message}")
            emptyList()
        }
    }

    private fun persist(list: List<String>) {
        _queries.value = list
        try {
            val arr = JSONArray(list)
            prefs.edit().putString(KEY_QUERIES, arr.toString()).apply()
        } catch (e: Exception) {
            AppLogger.d("SearchHistoryStore", "Lỗi lưu lịch sử tìm kiếm: ${e.message}")
        }
    }

    fun add(query: String) {
        val q = query.trim()
        if (q.isBlank()) return
        try {
            // Lọc bỏ từ khoá trùng (không phân biệt hoa thường) rồi đưa lên đầu, tối đa 20 mục
            val existing = _queries.value.filterNot { it.equals(q, ignoreCase = true) }
            val updated = (listOf(q) + existing).take(MAX_QUERIES)
            persist(updated)
        } catch (e: Exception) {
            AppLogger.d("SearchHistoryStore", "Lỗi thêm lịch sử tìm kiếm: ${e.message}")
        }
    }

    fun remove(query: String) {
        try {
            val updated = _queries.value.filterNot { it == query }
            persist(updated)
        } catch (e: Exception) {
            AppLogger.d("SearchHistoryStore", "Lỗi xoá mục lịch sử tìm kiếm: ${e.message}")
        }
    }

    fun clear() {
        try {
            persist(emptyList())
        } catch (e: Exception) {
            AppLogger.d("SearchHistoryStore", "Lỗi xoá toàn bộ lịch sử: ${e.message}")
        }
    }

    companion object {
        private const val KEY_QUERIES = "queries"
        private const val MAX_QUERIES = 20
    }
}
