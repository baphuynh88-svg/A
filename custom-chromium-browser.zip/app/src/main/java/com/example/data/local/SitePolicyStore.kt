package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SitePolicyStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "aura_site_policies",
        Context.MODE_PRIVATE
    )

    private val _blockedHosts = MutableStateFlow<Set<String>>(emptySet())
    val blockedHosts: StateFlow<Set<String>> = _blockedHosts.asStateFlow()

    private val _popupAllowedHosts = MutableStateFlow<Set<String>>(emptySet())
    val popupAllowedHosts: StateFlow<Set<String>> = _popupAllowedHosts.asStateFlow()

    private val _blockCookies = MutableStateFlow(false)
    val blockCookies: StateFlow<Boolean> = _blockCookies.asStateFlow()

    private val _ublockEnabled = MutableStateFlow(true)
    val ublockEnabled: StateFlow<Boolean> = _ublockEnabled.asStateFlow()

    private val _cleanOverlayEnabled = MutableStateFlow(true)
    val cleanOverlayEnabled: StateFlow<Boolean> = _cleanOverlayEnabled.asStateFlow()

    private val _backgroundPlayEnabled = MutableStateFlow(true)
    val backgroundPlayEnabled: StateFlow<Boolean> = _backgroundPlayEnabled.asStateFlow()

    private val _saviorEnabled = MutableStateFlow(true)
    val saviorEnabled: StateFlow<Boolean> = _saviorEnabled.asStateFlow()

    private val _devtoolsEnabled = MutableStateFlow(false)
    val devtoolsEnabled: StateFlow<Boolean> = _devtoolsEnabled.asStateFlow()

    init {
        _blockedHosts.value = prefs.getStringSet(KEY_BLOCKED_HOSTS, emptySet()) ?: emptySet()
        _popupAllowedHosts.value = prefs.getStringSet(KEY_POPUP_ALLOWED_HOSTS, emptySet()) ?: emptySet()
        _blockCookies.value = prefs.getBoolean(KEY_BLOCK_COOKIES, false)
        _ublockEnabled.value = prefs.getBoolean(KEY_UBLOCK_ENABLED, true)
        _cleanOverlayEnabled.value = prefs.getBoolean(KEY_CLEAN_OVERLAY_ENABLED, true)
        _backgroundPlayEnabled.value = prefs.getBoolean(KEY_BACKGROUND_PLAY_ENABLED, true)
        _saviorEnabled.value = prefs.getBoolean(KEY_SAVIOR_ENABLED, true)
        _devtoolsEnabled.value = prefs.getBoolean(KEY_DEVTOOLS_ENABLED, false)
    }

    // Cache danh sách host đã chuẩn hoá (tính lại chỉ khi tập gốc đổi), để mỗi lần kiểm tra chỉ tra Set.
    private class NormalizedSet(val source: Set<String>, val normalized: Set<String>)

    @Volatile private var blockedCache = NormalizedSet(emptySet(), emptySet())
    @Volatile private var popupAllowedCache = NormalizedSet(emptySet(), emptySet())

    private fun normalizedOf(current: Set<String>, cache: NormalizedSet): NormalizedSet {
        if (cache.source === current) return cache
        return NormalizedSet(
            current,
            current.mapNotNullTo(HashSet()) { normalizeHost(it).takeIf { h -> h.isNotBlank() } }
        )
    }

    // Khớp chính host hoặc bất kỳ tên miền cha nào (a.b.com -> a.b.com, b.com, com).
    private fun matchesHostOrParent(target: String, set: Set<String>): Boolean {
        var h = target
        while (true) {
            if (h in set) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    fun isHostBlocked(hostOrUrl: String): Boolean {
        val current = _blockedHosts.value
        if (current.isEmpty()) return false
        val target = normalizeHost(hostOrUrl)
        if (target.isBlank()) return false
        val cache = normalizedOf(current, blockedCache).also { blockedCache = it }
        return matchesHostOrParent(target, cache.normalized)
    }

    fun isPopupAllowed(hostOrUrl: String): Boolean {
        val current = _popupAllowedHosts.value
        if (current.isEmpty()) return false
        val target = normalizeHost(hostOrUrl)
        if (target.isBlank()) return false
        val cache = normalizedOf(current, popupAllowedCache).also { popupAllowedCache = it }
        return matchesHostOrParent(target, cache.normalized)
    }

    fun addBlockedHost(hostOrUrl: String) {
        val host = normalizeHost(hostOrUrl)
        if (host.isNotBlank()) {
            val updated = _blockedHosts.value + host
            _blockedHosts.value = updated
            prefs.edit().putStringSet(KEY_BLOCKED_HOSTS, updated).apply()
        }
    }

    fun removeBlockedHost(hostOrUrl: String) {
        val host = normalizeHost(hostOrUrl)
        val updated = _blockedHosts.value.filter { normalizeHost(it) != host }.toSet()
        _blockedHosts.value = updated
        prefs.edit().putStringSet(KEY_BLOCKED_HOSTS, updated).apply()
    }

    fun addPopupAllowedHost(hostOrUrl: String) {
        val host = normalizeHost(hostOrUrl)
        if (host.isNotBlank()) {
            val updated = _popupAllowedHosts.value + host
            _popupAllowedHosts.value = updated
            prefs.edit().putStringSet(KEY_POPUP_ALLOWED_HOSTS, updated).apply()
        }
    }

    fun removePopupAllowedHost(hostOrUrl: String) {
        val host = normalizeHost(hostOrUrl)
        val updated = _popupAllowedHosts.value.filter { normalizeHost(it) != host }.toSet()
        _popupAllowedHosts.value = updated
        prefs.edit().putStringSet(KEY_POPUP_ALLOWED_HOSTS, updated).apply()
    }

    fun setBlockCookies(block: Boolean) {
        _blockCookies.value = block
        prefs.edit().putBoolean(KEY_BLOCK_COOKIES, block).apply()
    }

    fun setUblockEnabled(enabled: Boolean) {
        _ublockEnabled.value = enabled
        prefs.edit().putBoolean(KEY_UBLOCK_ENABLED, enabled).apply()
    }

    fun setCleanOverlayEnabled(enabled: Boolean) {
        _cleanOverlayEnabled.value = enabled
        prefs.edit().putBoolean(KEY_CLEAN_OVERLAY_ENABLED, enabled).apply()
    }

    fun setBackgroundPlayEnabled(enabled: Boolean) {
        _backgroundPlayEnabled.value = enabled
        prefs.edit().putBoolean(KEY_BACKGROUND_PLAY_ENABLED, enabled).apply()
    }

    fun setSaviorEnabled(enabled: Boolean) {
        _saviorEnabled.value = enabled
        prefs.edit().putBoolean(KEY_SAVIOR_ENABLED, enabled).apply()
    }

    fun setDevtoolsEnabled(enabled: Boolean) {
        _devtoolsEnabled.value = enabled
        prefs.edit().putBoolean(KEY_DEVTOOLS_ENABLED, enabled).apply()
    }

    companion object {
        private const val KEY_BLOCKED_HOSTS = "blocked_hosts"
        private const val KEY_POPUP_ALLOWED_HOSTS = "popup_allowed_hosts"
        private const val KEY_BLOCK_COOKIES = "block_cookies"
        private const val KEY_UBLOCK_ENABLED = "ublock_enabled"
        private const val KEY_CLEAN_OVERLAY_ENABLED = "clean_overlay_enabled"
        private const val KEY_BACKGROUND_PLAY_ENABLED = "background_play_enabled"
        private const val KEY_SAVIOR_ENABLED = "savior_enabled"
        private const val KEY_DEVTOOLS_ENABLED = "devtools_enabled"

        fun normalizeHost(raw: String): String {
            val input = raw.trim().lowercase()
            if (input.isBlank()) return ""
            if (
                input.startsWith("about:") ||
                input.startsWith("data:") ||
                input.startsWith("javascript:") ||
                input.startsWith("blob:")
            ) {
                return ""
            }
            return try {
                val uriString = if ("://" in input) input else "http://$input"
                val host = Uri.parse(uriString)?.host ?: return ""
                host.trimEnd('.').removePrefix("www.")
            } catch (_: Exception) {
                ""
            }
        }
    }
}
