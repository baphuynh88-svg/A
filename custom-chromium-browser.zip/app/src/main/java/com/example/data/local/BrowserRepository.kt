package com.example.data.local

import kotlinx.coroutines.flow.Flow

class BrowserRepository(private val dao: BrowserDao) {
    val allBookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()
    val allHistory: Flow<List<HistoryEntity>> = dao.getAllHistory()

    fun isBookmarked(url: String): Flow<Boolean> = dao.isBookmarked(url)

    suspend fun addBookmark(title: String, url: String) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isNotBlank() && trimmedUrl != "about:blank" && !trimmedUrl.startsWith("chrome:")) {
            dao.insertBookmark(
                BookmarkEntity(
                    title = title.ifBlank { trimmedUrl },
                    url = trimmedUrl
                )
            )
        }
    }

    suspend fun removeBookmarkByUrl(url: String) {
        dao.deleteBookmarkByUrl(url.trim())
    }

    suspend fun removeBookmarkById(id: Long) {
        dao.deleteBookmarkById(id)
    }

    suspend fun addHistory(title: String, url: String) {
        val trimmedUrl = url.trim()
        val isHttp = trimmedUrl.startsWith("http://", ignoreCase = true) ||
                trimmedUrl.startsWith("https://", ignoreCase = true)
        if (trimmedUrl.isNotBlank() && isHttp) {
            dao.insertHistory(
                HistoryEntity(
                    title = title.ifBlank { trimmedUrl },
                    url = trimmedUrl,
                    visitedAt = System.currentTimeMillis()
                )
            )
            // Prune history to keep at most 1000 items
            dao.pruneOldHistory()
        }
    }

    suspend fun deleteHistoryById(id: Long) {
        dao.deleteHistoryById(id)
    }

    suspend fun clearHistory() {
        dao.clearAllHistory()
    }
}
