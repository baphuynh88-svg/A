package com.example.data.local

import kotlinx.coroutines.flow.Flow

class BrowserRepository(private val dao: BrowserDao) {
    val allBookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()
    val allHistory: Flow<List<HistoryEntity>> = dao.getAllHistory()

    fun isBookmarked(url: String): Flow<Boolean> = dao.isBookmarked(url)

    suspend fun addBookmark(title: String, url: String) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isNotBlank() && trimmedUrl != "about:blank" && !trimmedUrl.startsWith("chrome:")) {
            dao.insertBookmark(
                BookmarkEntity(
                    title = title.ifBlank { trimmedUrl },
                    url = trimmedUrl
                )
            )
        }
    }

    suspend fun removeBookmarkByUrl(url: String) {
        dao.deleteBookmarkByUrl(url.trim())
    }

    suspend fun removeBookmarkById(id: Long) {
        dao.deleteBookmarkById(id)
    }

    // Tránh ghi trùng: cùng URL liên tiếp trong vài giây (tải lại, SPA bắn nhiều sự kiện) thì bỏ qua.
    @Volatile private var lastHistoryUrl: String? = null
    @Volatile private var lastHistoryAt = 0L
    @Volatile private var insertsSincePrune = 0

    suspend fun addHistory(title: String, url: String) {
        val trimmedUrl = url.trim()
        val isHttp = trimmedUrl.startsWith("http://", ignoreCase = true) ||
                trimmedUrl.startsWith("https://", ignoreCase = true)
        if (trimmedUrl.isNotBlank() && isHttp) {
            val now = System.currentTimeMillis()
            if (trimmedUrl == lastHistoryUrl && now - lastHistoryAt < HISTORY_DEDUP_WINDOW_MS) {
                return
            }
            lastHistoryUrl = trimmedUrl
            lastHistoryAt = now
            dao.insertHistory(
                HistoryEntity(
                    title = title.ifBlank { trimmedUrl },
                    url = trimmedUrl,
                    visitedAt = now
                )
            )
            // Chỉ dọn bớt lịch sử (giữ tối đa 1000 mục) sau mỗi 25 lần ghi, không phải mỗi trang.
            insertsSincePrune++
            if (insertsSincePrune >= HISTORY_PRUNE_EVERY) {
                insertsSincePrune = 0
                dao.pruneOldHistory()
            }
        }
    }

    suspend fun deleteHistoryById(id: Long) {
        dao.deleteHistoryById(id)
    }

    suspend fun clearHistory() {
        dao.clearAllHistory()
    }

    private companion object {
        const val HISTORY_DEDUP_WINDOW_MS = 5_000L
        const val HISTORY_PRUNE_EVERY = 25
    }
}
