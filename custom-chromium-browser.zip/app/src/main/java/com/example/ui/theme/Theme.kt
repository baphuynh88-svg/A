package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ChromeBlueDark,
    secondary = ChromeAccentDark,
    tertiary = Color(0xFFFF8A65),
    background = Color(0xFF121212),
    surface = ChromeSurfaceDark,
    surfaceVariant = ChromeVariantDark,
    onPrimary = Color(0xFF002D6C),
    onSurface = Color(0xFFE3E3E3),
    onSurfaceVariant = Color(0xFFC4C7C5)
)

private val LightColorScheme = lightColorScheme(
    primary = ChromeBlue,
    secondary = ChromeAccent,
    tertiary = Color(0xFFE65100),
    background = Color(0xFFF8F9FA),
    surface = ChromeSurface,
    surfaceVariant = ChromeVariant,
    onPrimary = Color.White,
    onSurface = Color(0xFF1F1F1F),
    onSurfaceVariant = Color(0xFF444746)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
