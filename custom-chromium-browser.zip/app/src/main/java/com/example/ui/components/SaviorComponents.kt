package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.SitePolicyStore
import com.example.gecko.AudioExtractionFallback
import com.example.gecko.MediaItem
import com.example.gecko.MediaKind
import com.example.gecko.SaviorDownloadStatus
import com.example.gecko.SaviorItemDownloadState
import com.example.gecko.YtOption
import com.example.ui.YtDialogState
import java.util.Locale
import kotlin.math.roundToInt

private val KNOWN_MEDIA_EXT_REGEX =
    Regex("""\.(mp4|webm|m4v|mov|mp3|m4a|aac|ogg|opus|wav|flac|m3u8|mpd)$""", RegexOption.IGNORE_CASE)

internal fun extractFileExtension(url: String, kind: MediaKind): String {
    val cleanPath = try {
        Uri.parse(url).path ?: url.substringBefore('?').substringBefore('#')
    } catch (_: Exception) {
        url.substringBefore('?').substringBefore('#')
    }
    val match = KNOWN_MEDIA_EXT_REGEX.find(cleanPath)
    if (match != null) {
        return match.groupValues[1].lowercase(Locale.ROOT)
    }
    return when (kind) {
        MediaKind.AUDIO -> "mp3"
        MediaKind.HLS -> "m3u8"
        MediaKind.DASH -> "mpd"
        MediaKind.VIDEO -> "mp4"
    }
}

internal fun formatMediaDisplayTitle(item: MediaItem): String {
    val ext = extractFileExtension(item.url, item.kind)
    val baseTitle = item.pageTitle.trim().ifBlank {
        val lastSeg = try {
            Uri.parse(item.url).lastPathSegment?.substringBeforeLast('.')
        } catch (_: Exception) {
            null
        }
        lastSeg?.takeIf { it.isNotBlank() } ?: "Media"
    }
    return if (baseTitle.lowercase(Locale.ROOT).endsWith(".$ext")) {
        baseTitle
    } else {
        "$baseTitle.$ext"
    }
}

internal fun formatMediaSizeMb(sizeBytes: Long?): String? {
    if (sizeBytes == null || sizeBytes <= 0L) return null
    val mb = sizeBytes.toDouble() / (1024.0 * 1024.0)
    return if (mb >= 10.0) {
        String.format(Locale.US, "%.1f MB", mb)
    } else {
        String.format(Locale.US, "%.2f MB", mb)
    }
}

internal fun formatYtOptionSizeMb(sizeBytes: Long?): String {
    if (sizeBytes == null || sizeBytes <= 0L) return "—"
    val mb = sizeBytes.toDouble() / (1024.0 * 1024.0)
    return when {
        mb >= 100.0 -> "${mb.roundToInt()} MB"
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.2f MB", mb)
    }
}

internal fun formatMediaDuration(durationSec: Double): String? {
    if (!durationSec.isFinite() || durationSec <= 0.0) return null
    val totalSeconds = durationSec.roundToInt()
    if (totalSeconds <= 0) return null
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}

/**
 * Nút nổi nhỏ ở góc dưới bên phải vùng web, có thể kéo thả dọc theo cạnh phải.
 */
@Composable
fun SaviorFloatingButtonOverlay(
    downloadableCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    alwaysVisible: Boolean = false
) {
    if (downloadableCount <= 0 && !alwaysVisible) return

    var containerHeightPx by remember { mutableIntStateOf(0) }
    var buttonHeightPx by remember { mutableIntStateOf(0) }
    var verticalOffsetPx by rememberSaveable { mutableFloatStateOf(0f) }

    val minOffsetPx = remember(containerHeightPx, buttonHeightPx) {
        if (containerHeightPx > buttonHeightPx && buttonHeightPx > 0) {
            -(containerHeightPx - buttonHeightPx - 48).coerceAtLeast(0).toFloat()
        } else {
            -600f
        }
    }

    val clampedOffsetPx = verticalOffsetPx.coerceIn(minOffsetPx, 0f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { containerHeightPx = it.height }
            .navigationBarsPadding()
            .padding(end = 12.dp, bottom = 20.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        Surface(
            onClick = onClick,
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
            tonalElevation = 6.dp,
            shadowElevation = 6.dp,
            modifier = Modifier
                .offset { IntOffset(0, clampedOffsetPx.roundToInt()) }
                .onSizeChanged { buttonHeightPx = it.height }
                .minimumInteractiveComponentSize()
                .pointerInput(minOffsetPx) {
                    detectVerticalDragGestures { change, dragAmount ->
                        change.consume()
                        verticalOffsetPx = (verticalOffsetPx + dragAmount).coerceIn(minOffsetPx, 0f)
                    }
                }
                .testTag("savior_floating_button")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Savior tải media",
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Savior",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                if (downloadableCount > 0) {
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = downloadableCount.toString(),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaviorBottomSheet(
    items: List<MediaItem>,
    downloadStates: Map<String, SaviorItemDownloadState> = emptyMap(),
    onDownloadVideo: (MediaItem) -> Unit,
    onDownloadAudio: (MediaItem) -> Unit,
    onCancelDownload: (String) -> Unit = {},
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var qualitySelectionItem by remember { mutableStateOf<MediaItem?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = Modifier.testTag("savior_bottom_sheet")
    ) {
        val selectedStreamItem = qualitySelectionItem
        if (selectedStreamItem != null) {
            SaviorQualitySelectionStep(
                item = selectedStreamItem,
                onBack = { qualitySelectionItem = null }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Savior",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    val downloadableCount = items.count { !it.isProtected }
                    Text(
                        text = "$downloadableCount mục tải được",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                if (items.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 36.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Chưa phát hiện video hoặc âm thanh trên trang này",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 460.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(items = items, key = { it.id }) { item ->
                            val itemDownloadState = downloadStates[item.id]
                            SaviorMediaItemCard(
                                item = item,
                                downloadState = itemDownloadState,
                                onDownloadVideo = {
                                    if (item.kind == MediaKind.HLS || item.kind == MediaKind.DASH) {
                                        qualitySelectionItem = item
                                    } else {
                                        onDownloadVideo(item)
                                    }
                                },
                                onDownloadAudio = {
                                    if (item.kind == MediaKind.HLS || item.kind == MediaKind.DASH) {
                                        qualitySelectionItem = item
                                    } else {
                                        onDownloadAudio(item)
                                    }
                                },
                                onCancelDownload = {
                                    onCancelDownload(item.id)
                                },
                                onOpenQualitySelection = {
                                    qualitySelectionItem = item
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SaviorAudioFallbackDialog(
    fallback: AudioExtractionFallback,
    onConfirmSaveVideo: () -> Unit,
    onDismissDiscard: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismissDiscard,
        title = {
            Text(
                text = "Không tách được âm thanh",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "Video \"${fallback.baseTitle}.${fallback.videoExtension}\" không có luồng âm thanh tương thích để tách sang .m4a. Bạn có muốn lưu cả video không?"
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirmSaveVideo,
                modifier = Modifier.testTag("savior_fallback_save_video_button")
            ) {
                Text("Lưu cả video")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismissDiscard,
                modifier = Modifier.testTag("savior_fallback_cancel_button")
            ) {
                Text("Huỷ")
            }
        }
    )
}

@Composable
private fun SaviorQualitySelectionStep(
    item: MediaItem,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("savior_quality_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại"
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Chọn chất lượng (${item.kind.name})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = formatMediaDisplayTitle(item),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
            Text(
                text = "Sắp có",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Tính năng chọn chất lượng luồng ${item.kind.name} sẽ sớm được cập nhật.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        FilledTonalButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.End)
                .padding(bottom = 8.dp)
        ) {
            Text("Quay lại")
        }
    }
}

@Composable
private fun SaviorMediaItemCard(
    item: MediaItem,
    downloadState: SaviorItemDownloadState?,
    onDownloadVideo: () -> Unit,
    onDownloadAudio: () -> Unit,
    onCancelDownload: () -> Unit,
    onOpenQualitySelection: () -> Unit
) {
    val isStreamManifest = item.kind == MediaKind.HLS || item.kind == MediaKind.DASH
    val displayTitle = remember(item.pageTitle, item.url, item.kind) {
        formatMediaDisplayTitle(item)
    }
    val host = remember(item.pageUrl, item.url) {
        SitePolicyStore.normalizeHost(item.pageUrl).ifBlank {
            SitePolicyStore.normalizeHost(item.url)
        }
    }
    val sizeText = remember(item.sizeBytes) {
        formatMediaSizeMb(item.sizeBytes)
    }
    val durationText = remember(item.durationSec) {
        formatMediaDuration(item.durationSec)
    }

    val metadataParts = buildList {
        if (host.isNotBlank()) add(host)
        if (sizeText != null) add(sizeText)
        if (durationText != null) add(durationText)
        if (isStreamManifest) add(item.kind.name)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (item.isProtected) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (!item.isProtected && isStreamManifest) {
                    Modifier.clickable { onOpenQualitySelection() }
                } else {
                    Modifier
                }
            )
            .alpha(if (item.isProtected) 0.6f else 1f)
            .testTag("savior_media_item_${item.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            color = if (item.isProtected) {
                                MaterialTheme.colorScheme.outlineVariant
                            } else {
                                MaterialTheme.colorScheme.primaryContainer
                            },
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (item.kind == MediaKind.AUDIO) {
                            Icons.Default.MusicNote
                        } else {
                            Icons.Default.Videocam
                        },
                        contentDescription = if (item.kind == MediaKind.AUDIO) "Âm thanh" else "Video",
                        tint = if (item.isProtected) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = displayTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (metadataParts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = metadataParts.joinToString(" • "),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (item.isProtected) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Nội dung được bảo vệ, không thể tải",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (downloadState != null) {
                // Hiển thị thanh tiến trình và nút Huỷ khi mục đang tải, ghép hoặc xếp hàng
                val fraction = downloadState.progressFraction
                val statusLabel = when (downloadState.status) {
                    SaviorDownloadStatus.QUEUED -> "Đang chờ trong hàng đợi..."
                    SaviorDownloadStatus.EXTRACTING_AUDIO -> "Đang tách âm thanh (.m4a)..."
                    SaviorDownloadStatus.MUXING -> {
                        val pct = ((fraction ?: 0.9f) * 100).roundToInt().coerceIn(90, 100)
                        "Đang ghép video và âm thanh ($pct%)..."
                    }
                    SaviorDownloadStatus.DOWNLOADING -> {
                        val dlMb = String.format(Locale.US, "%.2f MB", downloadState.downloadedBytes / (1024.0 * 1024.0))
                        val totalPart = downloadState.totalBytes?.takeIf { it > 0L }?.let { total ->
                            val pct = ((fraction ?: 0f) * 100).roundToInt()
                            String.format(Locale.US, " / %.2f MB (%d%%)", total / (1024.0 * 1024.0), pct)
                        } ?: ""
                        "Đang tải: $dlMb$totalPart"
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = onCancelDownload,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("savior_btn_cancel_${item.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Huỷ")
                        }
                    }

                    if (fraction != null &&
                        (downloadState.status == SaviorDownloadStatus.DOWNLOADING ||
                            downloadState.status == SaviorDownloadStatus.MUXING)
                    ) {
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .testTag("savior_progress_${item.id}")
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .testTag("savior_progress_${item.id}")
                        )
                    }
                }
            } else if (item.kind == MediaKind.AUDIO) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDownloadAudio,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("savior_btn_download_audio_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tải âm thanh")
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                ) {
                    OutlinedButton(
                        onClick = onDownloadAudio,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("savior_btn_audio_only_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chỉ âm thanh")
                    }
                    Button(
                        onClick = onDownloadVideo,
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("savior_btn_download_video_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tải video")
                    }
                }
            }
        }
    }
}

private val YtDialogDarkBg = Color(0xFF1E1E24)
private val YtDialogSurfaceVariant = Color(0xFF2B2B33)
private val YtDialogGreenAccent = Color(0xFF4CAF50)
private val YtDialogPrimaryText = Color(0xFFF3F3F7)
private val YtDialogSecondaryText = Color(0xFFB4B4C2)

/**
 * Hộp thoại chọn chất lượng tải video/âm thanh YouTube cho Savior.
 */
@Composable
fun SaviorYouTubeDialog(
    state: YtDialogState,
    downloadStates: Map<String, SaviorItemDownloadState> = emptyMap(),
    onSelectOption: (String) -> Unit,
    onConfirmDownload: () -> Unit,
    onRetry: () -> Unit,
    onCancelDownload: (String) -> Unit = {},
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = YtDialogDarkBg,
            contentColor = YtDialogPrimaryText,
            tonalElevation = 8.dp,
            shadowElevation = 12.dp,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("savior_youtube_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            ) {
                val titleText = when (state) {
                    is YtDialogState.Ready -> state.media.title.ifBlank { "Video YouTube" }
                    is YtDialogState.Loading -> "Đang lấy thông tin video..."
                    is YtDialogState.Error -> "Không thể tải video"
                }

                Text(
                    text = titleText,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = YtDialogPrimaryText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("savior_yt_dialog_title")
                )

                val activeYtDownloads = remember(downloadStates) {
                    downloadStates.values.filter { it.itemId.startsWith("yt_") }
                }

                if (activeYtDownloads.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        activeYtDownloads.forEach { dl ->
                            YtActiveDownloadProgressCard(
                                downloadState = dl,
                                onCancel = { onCancelDownload(dl.itemId) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                when (state) {
                    is YtDialogState.Loading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = YtDialogGreenAccent,
                                modifier = Modifier
                                    .size(40.dp)
                                    .testTag("savior_yt_loading_spinner")
                            )
                        }
                    }

                    is YtDialogState.Error -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = state.msg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = YtDialogSecondaryText,
                                modifier = Modifier.testTag("savior_yt_error_message")
                            )
                            OutlinedButton(
                                onClick = onRetry,
                                modifier = Modifier.testTag("savior_yt_retry_button")
                            ) {
                                Text(
                                    text = "Thử lại",
                                    color = YtDialogGreenAccent,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    is YtDialogState.Ready -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 320.dp)
                                .testTag("savior_yt_options_list"),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(
                                items = state.media.options,
                                key = { it.id }
                            ) { option ->
                                val isSelected = option.id == state.selectedId
                                YtOptionRadioRow(
                                    option = option,
                                    selected = isSelected,
                                    onClick = { onSelectOption(option.id) }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("savior_yt_cancel_button")
                    ) {
                        Text(
                            text = "Huỷ",
                            color = YtDialogGreenAccent,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    }

                    val canDownload = state is YtDialogState.Ready && state.media.options.isNotEmpty()
                    TextButton(
                        onClick = onConfirmDownload,
                        enabled = canDownload,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("savior_yt_download_button")
                    ) {
                        Text(
                            text = "Tải về",
                            color = if (canDownload) {
                                YtDialogGreenAccent
                            } else {
                                YtDialogGreenAccent.copy(alpha = 0.4f)
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun YtOptionRadioRow(
    option: YtOption,
    selected: Boolean,
    onClick: () -> Unit
) {
    val sizeText = remember(option.sizeBytes) {
        formatYtOptionSizeMb(option.sizeBytes)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (selected) YtDialogSurfaceVariant else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("savior_yt_option_${option.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = YtDialogGreenAccent,
                    unselectedColor = YtDialogSecondaryText
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = option.label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                color = YtDialogPrimaryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Text(
            text = sizeText,
            style = MaterialTheme.typography.bodySmall,
            color = YtDialogSecondaryText
        )
    }
}

@Composable
private fun YtActiveDownloadProgressCard(
    downloadState: SaviorItemDownloadState,
    onCancel: () -> Unit
) {
    val fraction = downloadState.progressFraction
    val pct = ((fraction ?: 0f) * 100).roundToInt().coerceIn(0, 100)
    val statusText = when (downloadState.status) {
        SaviorDownloadStatus.QUEUED -> "Đang chờ..."
        SaviorDownloadStatus.EXTRACTING_AUDIO -> "Đang tách âm thanh..."
        SaviorDownloadStatus.MUXING -> "Đang ghép video & âm thanh ($pct%)"
        SaviorDownloadStatus.DOWNLOADING -> {
            val dlMb = String.format(Locale.US, "%.1f MB", downloadState.downloadedBytes / (1024.0 * 1024.0))
            val totalPart = downloadState.totalBytes?.takeIf { it > 0L }?.let { total ->
                String.format(Locale.US, " / %.1f MB (%d%%)", total / (1024.0 * 1024.0), pct)
            } ?: " ($pct%)"
            "Đang tải: $dlMb$totalPart"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(YtDialogSurfaceVariant, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = downloadState.fileName,
                    style = MaterialTheme.typography.labelMedium,
                    color = YtDialogPrimaryText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelSmall,
                    color = YtDialogGreenAccent
                )
            }
            TextButton(
                onClick = onCancel,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.testTag("savior_yt_cancel_dl_${downloadState.itemId}")
            ) {
                Text("Huỷ", color = YtDialogGreenAccent, fontSize = 12.sp)
            }
        }
        if (fraction != null &&
            (downloadState.status == SaviorDownloadStatus.DOWNLOADING ||
                downloadState.status == SaviorDownloadStatus.MUXING)
        ) {
            LinearProgressIndicator(
                progress = { fraction },
                color = YtDialogGreenAccent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
            )
        } else {
            LinearProgressIndicator(
                color = YtDialogGreenAccent,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
            )
        }
    }
}
