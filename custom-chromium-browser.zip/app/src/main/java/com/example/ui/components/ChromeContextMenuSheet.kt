package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.gecko.ContextMenuState
import org.mozilla.geckoview.GeckoSession.ContentDelegate.ContextElement

/**
 * Menu ngữ cảnh khi người dùng nhấn giữ lâu trên liên kết hoặc hình ảnh.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChromeContextMenuSheet(
    state: ContextMenuState,
    onOpenInNewTab: (String) -> Unit,
    onOpenInCurrentTab: (String) -> Unit,
    onCopyLink: (String) -> Unit,
    onShareLink: (String) -> Unit,
    onBlockSite: (String) -> Unit,
    onViewImage: (String) -> Unit,
    onCopyImageLink: (String) -> Unit,
    onSaveImage: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            val hasLink = !state.linkUri.isNullOrBlank()
            val isImage = state.type == ContextElement.TYPE_IMAGE && !state.srcUri.isNullOrBlank()

            if (hasLink) {
                Text(
                    text = state.linkUri ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                ContextMenuItem(
                    icon = Icons.Default.OpenInNew,
                    label = "Mở trong tab mới",
                    onClick = {
                        onDismiss()
                        onOpenInNewTab(state.linkUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.OpenInBrowser,
                    label = "Mở trong tab này",
                    onClick = {
                        onDismiss()
                        onOpenInCurrentTab(state.linkUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.ContentCopy,
                    label = "Sao chép link",
                    onClick = {
                        onDismiss()
                        onCopyLink(state.linkUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.Share,
                    label = "Chia sẻ link",
                    onClick = {
                        onDismiss()
                        onShareLink(state.linkUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.Block,
                    label = "Chặn trang này",
                    onClick = {
                        onDismiss()
                        onBlockSite(state.linkUri!!)
                    }
                )
            }

            if (isImage) {
                if (hasLink) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                }

                Text(
                    text = "Hình ảnh",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                )

                ContextMenuItem(
                    icon = Icons.Default.Image,
                    label = "Xem ảnh",
                    onClick = {
                        onDismiss()
                        onViewImage(state.srcUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.ContentCopy,
                    label = "Sao chép link ảnh",
                    onClick = {
                        onDismiss()
                        onCopyImageLink(state.srcUri!!)
                    }
                )

                ContextMenuItem(
                    icon = Icons.Default.Download,
                    label = "Lưu ảnh",
                    onClick = {
                        onDismiss()
                        onSaveImage(state.srcUri!!)
                    }
                )
            }
        }
    }
}

@Composable
private fun ContextMenuItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
