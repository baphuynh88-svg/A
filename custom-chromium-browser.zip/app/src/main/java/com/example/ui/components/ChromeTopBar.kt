package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChromeTopBar(
    tabUrl: String,
    tabIsLoading: Boolean,
    tabIsStartPage: Boolean,
    tabIsDesktopMode: Boolean,
    tabIsSecure: Boolean,
    tabsCount: Int,
    isEditing: Boolean,
    omniboxText: String,
    isBookmarked: Boolean,
    showMenu: Boolean,
    onOmniboxTextChange: (String) -> Unit,
    onStartEditing: () -> Unit,
    onSubmitUrl: (String) -> Unit,
    onReload: () -> Unit,
    onStopLoading: () -> Unit,
    onOpenTabSwitcher: () -> Unit,
    onOpenMenu: () -> Unit,
    onDismissMenu: () -> Unit,
    onNewTab: () -> Unit,
    onToggleBookmark: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenDownloads: () -> Unit = {},
    onToggleDesktop: () -> Unit,
    onShare: () -> Unit,
    onFindInPage: () -> Unit,
    onAboutGecko: () -> Unit,
    // Site Policy & Cookie Controls
    onBlockCurrentSite: () -> Unit,
    isCurrentSitePopupAllowed: Boolean,
    onTogglePopupCurrentSite: () -> Unit,
    blockThirdPartyCookies: Boolean,
    onToggleBlockCookies: () -> Unit,
    isUblockEnabled: Boolean,
    onToggleUblock: () -> Unit,
    isCleanOverlayEnabled: Boolean = true,
    onToggleCleanOverlay: () -> Unit = {},
    isBackgroundPlayEnabled: Boolean = true,
    onToggleBackgroundPlay: () -> Unit = {},
    isSaviorEnabled: Boolean = true,
    onToggleSavior: () -> Unit = {},
    isDevtoolsEnabled: Boolean = false,
    onToggleDevtools: () -> Unit = {},
    onOpenPolicyManagement: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenProtectionStats: () -> Unit,
    onClearSearchHistory: () -> Unit,
    onClearBrowsingData: () -> Unit,
    onNewPrivateTab: () -> Unit,
    isPageTranslated: Boolean = false,
    onTranslatePage: () -> Unit = {},
    isPrivate: Boolean = false,
    protectionBadgeCount: Int = 0,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    val initialText = if (tabIsStartPage || tabUrl == "about:blank") "" else tabUrl
    var textFieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = initialText,
                selection = TextRange(initialText.length)
            )
        )
    }

    var showToolsSheet by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(isEditing, tabUrl, tabIsStartPage) {
        val syncedText = if (tabIsStartPage || tabUrl == "about:blank") "" else tabUrl
        textFieldValue = TextFieldValue(
            text = syncedText,
            selection = TextRange(syncedText.length)
        )
        if (isEditing) {
            focusRequester.requestFocus()
        }
    }

    LaunchedEffect(omniboxText) {
        if (!isEditing && textFieldValue.text != omniboxText) {
            textFieldValue = TextFieldValue(
                text = omniboxText,
                selection = TextRange(omniboxText.length)
            )
        }
    }

    // Debounce 300ms khi gõ chữ để cập nhật gợi ý tìm kiếm mà không gây lag trên từng ký tự
    LaunchedEffect(textFieldValue.text, isEditing) {
        if (isEditing) {
            delay(300)
            onOmniboxTextChange(textFieldValue.text)
        }
    }

    val topBarColor = if (isPrivate) Color(0xFF282333) else MaterialTheme.colorScheme.surface
    val omniboxColor = if (isPrivate) Color(0xFF3B334A) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
    val isValidWebPage = !tabIsStartPage && tabUrl.isNotBlank() && tabUrl != "about:blank"

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = topBarColor,
        tonalElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Chrome-Style Omnibox Pill
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(omniboxColor)
                    .clickable(enabled = !isEditing) { onStartEditing() }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Security, Private, or Search Icon
                    val isStart = tabIsStartPage
                    val isHttps = tabIsSecure
                    val isBlankOrHome = isStart && (tabUrl.isBlank() || tabUrl == "about:blank")

                    Icon(
                        imageVector = when {
                            isPrivate -> Icons.Default.VisibilityOff
                            isBlankOrHome -> Icons.Default.Search
                            isHttps -> Icons.Default.Lock
                            else -> Icons.Default.Search
                        },
                        contentDescription = when {
                            isPrivate -> "Chế độ ẩn danh"
                            isHttps && !isBlankOrHome -> "Secure connection"
                            else -> "Search"
                        },
                        tint = when {
                            isPrivate -> Color(0xFFD0BCFF)
                            isHttps && !isBlankOrHome -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.size(18.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isEditing) {
                        val submitCurrentText = {
                            val currentText = textFieldValue.text
                            onOmniboxTextChange(currentText)
                            onSubmitUrl(currentText)
                        }
                        BasicTextField(
                            value = textFieldValue,
                            onValueChange = { textFieldValue = it },
                            modifier = Modifier
                                .weight(1f)
                                .focusRequester(focusRequester)
                                .onKeyEvent { keyEvent ->
                                    if ((keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter) &&
                                        keyEvent.type == KeyEventType.KeyUp
                                    ) {
                                        submitCurrentText()
                                        true
                                    } else {
                                        false
                                    }
                                }
                                .testTag("omnibox_input_field"),
                            singleLine = true,
                            textStyle = TextStyle(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = { submitCurrentText() },
                                onSearch = { submitCurrentText() },
                                onDone = { submitCurrentText() }
                            )
                        )

                        if (textFieldValue.text.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    textFieldValue = TextFieldValue("")
                                    onOmniboxTextChange("")
                                },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("omnibox_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear address",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            IconButton(
                                onClick = { submitCurrentText() },
                                modifier = Modifier
                                    .size(28.dp)
                                    .testTag("omnibox_go_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = "Go",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    } else {
                        // Display URL or Search prompt
                        val displayText = when {
                            isStart -> "Search or type web address"
                            tabUrl.isNotBlank() && tabUrl != "about:blank" -> cleanDisplayUrl(tabUrl)
                            textFieldValue.text.isNotBlank() -> cleanDisplayUrl(textFieldValue.text)
                            else -> "Search or type web address"
                        }
                        val isPlaceholder = displayText == "Search or type web address"
                        Text(
                            text = displayText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (isPlaceholder) {
                                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                fontWeight = if (isPlaceholder) FontWeight.Normal else FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("omnibox_text_display")
                        )

                        // Reload / Stop button inside or beside omnibox
                        if (tabIsLoading) {
                            IconButton(
                                onClick = onStopLoading,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("omnibox_stop_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Stop loading",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        } else if (!isStart) {
                            IconButton(
                                onClick = onReload,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("omnibox_reload_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reload page",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Chrome-Style Tab Counter Badge Button
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(
                        width = 1.8.dp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { onOpenTabSwitcher() }
                    .testTag("tab_switcher_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tabsCount.coerceAtLeast(1).toString(),
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    textAlign = TextAlign.Center
                )
            }

            // Chrome 3-Dots Overflow Menu
            Box {
                IconButton(
                    onClick = onOpenMenu,
                    modifier = Modifier.testTag("overflow_menu_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (protectionBadgeCount > 0) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ) {
                                    Text(
                                        text = if (protectionBadgeCount > 99) "99+" else "$protectionBadgeCount",
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = onDismissMenu,
                    modifier = Modifier.testTag("chrome_dropdown_menu")
                ) {
                    DropdownMenuItem(
                        text = { Text("New tab") },
                        leadingIcon = {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                        },
                        onClick = {
                            onDismissMenu()
                            onNewTab()
                        },
                        modifier = Modifier.testTag("menu_new_tab")
                    )

                    DropdownMenuItem(
                        text = { Text("Tab ẩn danh mới") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = Color(0xFFB388FF)
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onNewPrivateTab()
                        },
                        modifier = Modifier.testTag("menu_new_private_tab")
                    )

                    DropdownMenuItem(
                        text = {
                            Text(if (isBookmarked) "Remove bookmark" else "Bookmark this page")
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        },
                        enabled = isValidWebPage,
                        onClick = {
                            onDismissMenu()
                            onToggleBookmark()
                        },
                        modifier = Modifier.testTag("menu_bookmark")
                    )

                    DropdownMenuItem(
                        text = { Text("Bookmarks") },
                        leadingIcon = {
                            Icon(Icons.Default.Bookmark, contentDescription = null)
                        },
                        onClick = {
                            onDismissMenu()
                            onOpenBookmarks()
                        },
                        modifier = Modifier.testTag("menu_bookmarks_list")
                    )

                    DropdownMenuItem(
                        text = { Text("History") },
                        leadingIcon = {
                            Icon(Icons.Default.History, contentDescription = null)
                        },
                        onClick = {
                            onDismissMenu()
                            onOpenHistory()
                        },
                        modifier = Modifier.testTag("menu_history_list")
                    )

                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.downloads_menu_title)) },
                        leadingIcon = {
                            Icon(Icons.Default.Download, contentDescription = null)
                        },
                        onClick = {
                            onDismissMenu()
                            onOpenDownloads()
                        },
                        modifier = Modifier.testTag("menu_downloads_list")
                    )

                    HorizontalDivider()

                    // Công tắc "Chặn quảng cáo (uBlock Origin)"
                    DropdownMenuItem(
                        text = { Text("Chặn quảng cáo (uBlock Origin)") },
                        leadingIcon = {
                            Icon(Icons.Default.Shield, contentDescription = null)
                        },
                        trailingIcon = {
                            Checkbox(
                                checked = isUblockEnabled,
                                onCheckedChange = null
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onToggleUblock()
                        },
                        modifier = Modifier.testTag("menu_toggle_ublock")
                    )

                    // Công tắc "Phát YouTube dưới nền"
                    DropdownMenuItem(
                        text = { Text("Phát YouTube dưới nền") },
                        leadingIcon = {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                        },
                        trailingIcon = {
                            Checkbox(
                                checked = isBackgroundPlayEnabled,
                                onCheckedChange = null
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onToggleBackgroundPlay()
                        },
                        modifier = Modifier.testTag("menu_toggle_background_play")
                    )

                    // Công tắc "Bật Savior"
                    DropdownMenuItem(
                        text = { Text("Bật Savior") },
                        leadingIcon = {
                            Icon(Icons.Default.Download, contentDescription = null)
                        },
                        trailingIcon = {
                            Checkbox(
                                checked = isSaviorEnabled,
                                onCheckedChange = null
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onToggleSavior()
                        },
                        modifier = Modifier.testTag("menu_toggle_savior")
                    )

                    // Công tắc "Công cụ nhà phát triển (F12)"
                    DropdownMenuItem(
                        text = { Text("Công cụ nhà phát triển (F12)") },
                        leadingIcon = {
                            Icon(Icons.Default.Code, contentDescription = null)
                        },
                        trailingIcon = {
                            Checkbox(
                                checked = isDevtoolsEnabled,
                                onCheckedChange = null
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onToggleDevtools()
                        },
                        modifier = Modifier.testTag("menu_toggle_devtools")
                    )

                    HorizontalDivider()

                    DropdownMenuItem(
                        text = { Text("Desktop site") },
                        leadingIcon = {
                            Icon(Icons.Default.DesktopWindows, contentDescription = null)
                        },
                        trailingIcon = {
                            Checkbox(
                                checked = tabIsDesktopMode,
                                onCheckedChange = null
                            )
                        },
                        onClick = {
                            onDismissMenu()
                            onToggleDesktop()
                        },
                        modifier = Modifier.testTag("menu_desktop_site")
                    )

                    DropdownMenuItem(
                        text = { Text("Share...") },
                        leadingIcon = {
                            Icon(Icons.Default.Share, contentDescription = null)
                        },
                        enabled = isValidWebPage,
                        onClick = {
                            onDismissMenu()
                            onShare()
                        },
                        modifier = Modifier.testTag("menu_share")
                    )

                    DropdownMenuItem(
                        text = { Text(if (isPageTranslated) "Hiện bản gốc" else "Dịch sang tiếng Việt") },
                        leadingIcon = {
                            Icon(Icons.Default.Translate, contentDescription = null)
                        },
                        enabled = isValidWebPage,
                        onClick = {
                            onDismissMenu()
                            onTranslatePage()
                        },
                        modifier = Modifier.testTag("menu_translate_page")
                    )

                    DropdownMenuItem(
                        text = { Text("Find in page") },
                        leadingIcon = {
                            Icon(Icons.Default.FindInPage, contentDescription = null)
                        },
                        enabled = isValidWebPage,
                        onClick = {
                            onDismissMenu()
                            onFindInPage()
                        },
                        modifier = Modifier.testTag("menu_find_in_page")
                    )

                    HorizontalDivider()

                    DropdownMenuItem(
                        text = { Text("Công cụ & cài đặt trang") },
                        leadingIcon = {
                            Icon(Icons.Default.Settings, contentDescription = null)
                        },
                        onClick = {
                            onDismissMenu()
                            showToolsSheet = true
                        },
                        modifier = Modifier.testTag("menu_tools_and_site_settings")
                    )
                }
            }
        }
    }

    if (showToolsSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showToolsSheet = false },
            sheetState = sheetState,
            modifier = Modifier.testTag("tools_and_site_settings_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Công cụ & cài đặt trang",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showToolsSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Đóng")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item(key = "menu_block_site") {
                        ToolsSheetItemRow(
                            text = "Chặn trang này",
                            icon = Icons.Default.Block,
                            iconTint = MaterialTheme.colorScheme.error,
                            enabled = isValidWebPage,
                            testTag = "menu_block_site",
                            onClick = {
                                showToolsSheet = false
                                onBlockCurrentSite()
                            }
                        )
                    }

                    item(key = "menu_allow_popup") {
                        ToolsSheetItemRow(
                            text = "Cho phép popup ở trang này",
                            icon = Icons.Default.OpenInNew,
                            checked = isCurrentSitePopupAllowed,
                            enabled = isValidWebPage,
                            testTag = "menu_allow_popup",
                            onClick = {
                                showToolsSheet = false
                                onTogglePopupCurrentSite()
                            }
                        )
                    }

                    item(key = "menu_block_cookies") {
                        ToolsSheetItemRow(
                            text = "Chặn cookie bên thứ ba",
                            icon = Icons.Default.Cookie,
                            checked = blockThirdPartyCookies,
                            testTag = "menu_block_cookies",
                            onClick = {
                                showToolsSheet = false
                                onToggleBlockCookies()
                            }
                        )
                    }

                    item(key = "menu_toggle_clean_overlay") {
                        ToolsSheetItemRow(
                            text = "Dọn lớp phủ quảng cáo",
                            icon = Icons.Default.Shield,
                            checked = isCleanOverlayEnabled,
                            testTag = "menu_toggle_clean_overlay",
                            onClick = {
                                showToolsSheet = false
                                onToggleCleanOverlay()
                            }
                        )
                    }

                    item(key = "menu_manage_policies") {
                        ToolsSheetItemRow(
                            text = "Quản lý trang bị chặn",
                            icon = Icons.Default.Security,
                            testTag = "menu_manage_policies",
                            onClick = {
                                showToolsSheet = false
                                onOpenPolicyManagement()
                            }
                        )
                    }

                    item(key = "divider_tools") {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )
                    }

                    item(key = "menu_protection_stats") {
                        ToolsSheetItemRow(
                            text = "Thống kê bảo vệ",
                            icon = Icons.Default.Security,
                            testTag = "menu_protection_stats",
                            onClick = {
                                showToolsSheet = false
                                onOpenProtectionStats()
                            }
                        )
                    }

                    item(key = "menu_clear_search_history") {
                        ToolsSheetItemRow(
                            text = "Xoá lịch sử tìm kiếm",
                            icon = Icons.Default.DeleteSweep,
                            testTag = "menu_clear_search_history",
                            onClick = {
                                showToolsSheet = false
                                onClearSearchHistory()
                            }
                        )
                    }

                    item(key = "menu_clear_browsing_data") {
                        ToolsSheetItemRow(
                            text = "Xoá dữ liệu duyệt web",
                            icon = Icons.Default.Delete,
                            iconTint = MaterialTheme.colorScheme.error,
                            testTag = "menu_clear_browsing_data",
                            onClick = {
                                showToolsSheet = false
                                onClearBrowsingData()
                            }
                        )
                    }

                    item(key = "menu_diagnostics") {
                        ToolsSheetItemRow(
                            text = "Chẩn đoán",
                            icon = Icons.Default.Info,
                            testTag = "menu_diagnostics",
                            onClick = {
                                showToolsSheet = false
                                onOpenDiagnostics()
                            }
                        )
                    }

                    item(key = "menu_about_gecko") {
                        ToolsSheetItemRow(
                            text = "About GeckoView Engine",
                            icon = Icons.Default.Info,
                            testTag = "menu_about_gecko",
                            onClick = {
                                showToolsSheet = false
                                onAboutGecko()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolsSheetItemRow(
    text: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit,
    iconTint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    checked: Boolean? = null,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .alpha(if (enabled) 1f else 0.45f)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (checked != null) {
            Checkbox(
                checked = checked,
                onCheckedChange = null,
                enabled = enabled
            )
        }
    }
}

private fun cleanDisplayUrl(fullUrl: String): String {
    return fullUrl
        .removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")
        .trimEnd('/')
}
