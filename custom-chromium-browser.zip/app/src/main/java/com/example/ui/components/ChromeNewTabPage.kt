package com.example.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.BookmarkEntity
import com.example.data.local.ShortcutItem
import com.example.data.local.ShortcutStore
import com.example.data.local.SitePolicyStore
import kotlinx.coroutines.flow.Flow
import kotlin.math.abs

data class QuickShortcut(
    val title: String,
    val url: String,
    val icon: ImageVector,
    val iconBgColor: Color
)

private val FALLBACK_SHORTCUT_COLORS = listOf(
    Color(0xFF4285F4),
    Color(0xFF1DB954),
    Color(0xFFFF4500),
    Color(0xFF8E24AA),
    Color(0xFF00897B),
    Color(0xFFF4511E),
    Color(0xFF3949AB),
    Color(0xFF039BE5)
)

private fun resolveShortcutVisual(item: ShortcutItem): Pair<ImageVector, Color> {
    val host = SitePolicyStore.normalizeHost(item.url)
    return when {
        host == "google.com" || host.endsWith(".google.com") ->
            Icons.Default.Search to Color(0xFF4285F4)
        host == "spotify.com" || host.endsWith(".spotify.com") ->
            Icons.Default.SmartDisplay to Color(0xFF1DB954)
        host == "youtube.com" || host.endsWith(".youtube.com") || host == "youtu.be" ->
            Icons.Default.SmartDisplay to Color(0xFFFF0000)
        host == "wikipedia.org" || host.endsWith(".wikipedia.org") ->
            Icons.Default.Language to Color(0xFF555555)
        host == "github.com" || host.endsWith(".github.com") ->
            Icons.Default.Terminal to Color(0xFF24292E)
        host == "reddit.com" || host.endsWith(".reddit.com") ->
            Icons.Default.Public to Color(0xFFFF4500)
        host == "duckduckgo.com" || host.endsWith(".duckduckgo.com") ->
            Icons.Default.Search to Color(0xFFDE5833)
        host == "mozilla.org" || host.endsWith(".mozilla.org") ->
            Icons.Default.Code to Color(0xFF005A9C)
        else -> {
            val colorIndex = abs(host.ifBlank { item.title }.hashCode()) % FALLBACK_SHORTCUT_COLORS.size
            Icons.Default.Public to FALLBACK_SHORTCUT_COLORS[colorIndex]
        }
    }
}

/**
 * Icon lối tắt: tải favicon thật của trang; khi chưa tải được (hoặc lỗi mạng)
 * thì hiện icon mặc định như trước.
 */
@Composable
private fun ShortcutIcon(
    shortcut: ShortcutItem,
    fallbackIcon: ImageVector,
    fallbackColor: Color
) {
    val context = LocalContext.current
    val host = remember(shortcut.url) { SitePolicyStore.normalizeHost(shortcut.url) }
    var faviconLoaded by remember(shortcut.url) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(
                if (faviconLoaded) Color.White else MaterialTheme.colorScheme.surfaceVariant
            ),
        contentAlignment = Alignment.Center
    ) {
        if (!faviconLoaded) {
            Icon(
                imageVector = fallbackIcon,
                contentDescription = shortcut.title,
                tint = fallbackColor,
                modifier = Modifier.size(24.dp)
            )
        }
        if (host.isNotBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data("https://www.google.com/s2/favicons?domain=$host&sz=128")
                    .crossfade(true)
                    .build(),
                contentDescription = shortcut.title,
                modifier = Modifier.size(32.dp),
                onSuccess = { faviconLoaded = true },
                onError = { faviconLoaded = false }
            )
        }
    }
}

private sealed interface ShortcutGridCell {
    data class Item(val shortcut: ShortcutItem) : ShortcutGridCell
    data object AddButton : ShortcutGridCell
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChromeNewTabPage(
    bookmarksFlow: Flow<List<BookmarkEntity>>,
    onSelectUrl: (String) -> Unit,
    onSearch: (String) -> Unit,
    isPrivate: Boolean = false,
    blockedHosts: Set<String> = emptySet(),
    shortcuts: List<ShortcutItem> = ShortcutStore.DEFAULT_SHORTCUTS,
    onAddShortcut: (title: String, url: String) -> Unit = { _, _ -> },
    onEditShortcut: (id: String, title: String, url: String) -> Unit = { _, _, _ -> },
    onDeleteShortcut: (id: String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val bookmarks by bookmarksFlow.collectAsStateWithLifecycle(emptyList())
    var searchQuery by remember { mutableStateOf("") }

    var contextMenuShortcutId by remember { mutableStateOf<String?>(null) }
    var showShortcutDialog by remember { mutableStateOf(false) }
    var editingShortcut by remember { mutableStateOf<ShortcutItem?>(null) }
    var dialogNameInput by remember { mutableStateOf("") }
    var dialogUrlInput by remember { mutableStateOf("") }
    var dialogUrlError by remember { mutableStateOf<String?>(null) }

    val handleSearch = {
        val trimmed = searchQuery.trim()
        if (trimmed.isNotBlank()) {
            onSearch(trimmed)
        }
    }

    val handleSaveShortcut = {
        val validUrl = ShortcutStore.normalizeAndValidateUrl(dialogUrlInput)
        if (validUrl == null) {
            dialogUrlError = "URL không hợp lệ"
        } else {
            val finalTitle = dialogNameInput.trim().ifBlank {
                SitePolicyStore.normalizeHost(validUrl).ifBlank { validUrl }
            }
            val targetEditing = editingShortcut
            if (targetEditing == null) {
                onAddShortcut(finalTitle, validUrl)
            } else {
                onEditShortcut(targetEditing.id, finalTitle, validUrl)
            }
            showShortcutDialog = false
            editingShortcut = null
        }
    }

    if (showShortcutDialog) {
        AlertDialog(
            onDismissRequest = {
                showShortcutDialog = false
                editingShortcut = null
            },
            title = {
                Text(
                    text = if (editingShortcut == null) "Thêm lối tắt" else "Sửa lối tắt",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = dialogNameInput,
                        onValueChange = { dialogNameInput = it },
                        label = { Text("Tên") },
                        placeholder = { Text("Để trống để lấy theo tên miền") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shortcut_name_input")
                    )

                    OutlinedTextField(
                        value = dialogUrlInput,
                        onValueChange = {
                            dialogUrlInput = it
                            if (dialogUrlError != null) {
                                dialogUrlError = null
                            }
                        },
                        label = { Text("URL") },
                        placeholder = { Text("https://example.com") },
                        singleLine = true,
                        isError = dialogUrlError != null,
                        supportingText = {
                            val err = dialogUrlError
                            if (err != null) {
                                Text(
                                    text = err,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.testTag("shortcut_url_error")
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { handleSaveShortcut() }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shortcut_url_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { handleSaveShortcut() },
                    modifier = Modifier.testTag("shortcut_save_button")
                ) {
                    Text("Lưu")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showShortcutDialog = false
                        editingShortcut = null
                    },
                    modifier = Modifier.testTag("shortcut_cancel_button")
                ) {
                    Text("Huỷ")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Chrome-like Brand / Logo Section
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.tertiary
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Language,
                contentDescription = "Biểu tượng Aura Browser",
                tint = Color.White,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Aura Browser",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp)
        ) {
            Text(
                text = "Nhân trình duyệt Mozilla GeckoView",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }

        if (isPrivate) {
            Spacer(modifier = Modifier.height(18.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF382F4D),
                contentColor = Color(0xFFEADBFF),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.VisibilityOff,
                        contentDescription = null,
                        tint = Color(0xFFD0BCFF),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Bạn đang ở chế độ ẩn danh, lịch sử sẽ không được lưu",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Functional Google Search Box
        val hasText = searchQuery.isNotBlank()

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("new_tab_search_box"),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 16.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Tìm kiếm bằng Google",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Tìm kiếm bằng Google hoặc nhập URL",
                            style = TextStyle(
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                fontSize = 16.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .onKeyEvent { keyEvent ->
                                if ((keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter) &&
                                    keyEvent.type == KeyEventType.KeyUp
                                ) {
                                    handleSearch()
                                    true
                                } else {
                                    false
                                }
                            }
                            .testTag("new_tab_search_input"),
                        singleLine = true,
                        textStyle = TextStyle(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Search
                        ),
                        keyboardActions = KeyboardActions(
                            onSearch = { handleSearch() },
                            onGo = { handleSearch() },
                            onDone = { handleSearch() }
                        )
                    )
                }

                if (hasText) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable { searchQuery = "" }
                            .testTag("new_tab_clear_search"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Xóa nội dung",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))
                }

                val buttonBg = if (hasText) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(buttonBg)
                        .clickable(enabled = hasText) { handleSearch() }
                        .testTag("new_tab_submit_search"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Tìm kiếm",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Lọc lối tắt theo danh sách trang bị chặn
        val visibleShortcuts = remember(shortcuts, blockedHosts) {
            shortcuts.filterNot { shortcut ->
                val targetHost = SitePolicyStore.normalizeHost(shortcut.url)
                targetHost.isNotBlank() && blockedHosts.any { blocked ->
                    val normalizedBlocked = SitePolicyStore.normalizeHost(blocked)
                    normalizedBlocked.isNotBlank() && (
                        targetHost == normalizedBlocked ||
                        targetHost.endsWith(".$normalizedBlocked")
                    )
                }
            }
        }

        val canAddShortcut = shortcuts.size < ShortcutStore.MAX_SHORTCUTS
        val gridCells = remember(visibleShortcuts, canAddShortcut) {
            buildList {
                visibleShortcuts.forEach { add(ShortcutGridCell.Item(it)) }
                if (canAddShortcut) {
                    add(ShortcutGridCell.AddButton)
                }
            }
        }

        if (gridCells.isNotEmpty()) {
            Spacer(modifier = Modifier.height(28.dp))

            // Tiêu đề phần Lối tắt
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Lối tắt",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Lưới lối tắt kiểu Chrome (4 cột mỗi hàng)
            val chunkedCells = gridCells.chunked(4)
            chunkedCells.forEach { rowCells ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    rowCells.forEach { cell ->
                        when (cell) {
                            is ShortcutGridCell.Item -> {
                                val shortcut = cell.shortcut
                                val (icon, iconColor) = resolveShortcutVisual(shortcut)
                                Box {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .width(72.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .combinedClickable(
                                                onClick = { onSelectUrl(shortcut.url) },
                                                onLongClick = { contextMenuShortcutId = shortcut.id }
                                            )
                                            .padding(vertical = 4.dp)
                                            .testTag("shortcut_${shortcut.title.lowercase()}")
                                    ) {
                                        ShortcutIcon(
                                            shortcut = shortcut,
                                            fallbackIcon = icon,
                                            fallbackColor = iconColor
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = shortcut.title,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Normal,
                                                color = MaterialTheme.colorScheme.onSurface
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    DropdownMenu(
                                        expanded = contextMenuShortcutId == shortcut.id,
                                        onDismissRequest = { contextMenuShortcutId = null }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Sửa") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Edit,
                                                    contentDescription = null
                                                )
                                            },
                                            onClick = {
                                                contextMenuShortcutId = null
                                                editingShortcut = shortcut
                                                dialogNameInput = shortcut.title
                                                dialogUrlInput = shortcut.url
                                                dialogUrlError = null
                                                showShortcutDialog = true
                                            },
                                            modifier = Modifier.testTag("shortcut_menu_edit")
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Xoá") },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = null
                                                )
                                            },
                                            onClick = {
                                                contextMenuShortcutId = null
                                                onDeleteShortcut(shortcut.id)
                                            },
                                            modifier = Modifier.testTag("shortcut_menu_delete")
                                        )
                                    }
                                }
                            }

                            ShortcutGridCell.AddButton -> {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .width(72.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            editingShortcut = null
                                            dialogNameInput = ""
                                            dialogUrlInput = ""
                                            dialogUrlError = null
                                            showShortcutDialog = true
                                        }
                                        .padding(vertical = 4.dp)
                                        .testTag("shortcut_add")
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.surfaceVariant),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Thêm lối tắt",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Thêm lối tắt",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurface
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    if (rowCells.size < 4) {
                        repeat(4 - rowCells.size) {
                            Spacer(modifier = Modifier.width(72.dp))
                        }
                    }
                }
            }
        }

        // Phần Dấu trang đã lưu
        if (bookmarks.isNotEmpty()) {
            Spacer(modifier = Modifier.height(28.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Bookmark,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Dấu trang đã lưu",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            bookmarks.take(4).forEach { bookmark ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onSelectUrl(bookmark.url) }
                        .testTag("home_bookmark_${bookmark.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = bookmark.title,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = bookmark.url,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(36.dp))
    }
}
