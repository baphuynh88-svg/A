package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Hộp thoại cho phép người dùng lựa chọn và xoá các loại dữ liệu duyệt web.
 * Mặc định tick sẵn: Lịch sử + Cache. Không đụng tới bookmark và danh sách web bị chặn.
 */
@Composable
fun ClearBrowsingDataDialog(
    onDismiss: () -> Unit,
    onConfirmClear: (
        clearHistory: Boolean,
        clearCookies: Boolean,
        clearCache: Boolean,
        clearProtectionStats: Boolean,
        clearSitePermissions: Boolean
    ) -> Unit
) {
    var clearHistory by remember { mutableStateOf(true) }
    var clearCache by remember { mutableStateOf(true) }
    var clearCookies by remember { mutableStateOf(false) }
    var clearProtectionStats by remember { mutableStateOf(false) }
    var clearSitePermissions by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error
            )
        },
        title = {
            Text(
                text = "Xoá dữ liệu duyệt web",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Chọn các mục bạn muốn xoá:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                ClearOptionRow(
                    label = "Lịch sử duyệt web & tìm kiếm",
                    description = "Xoá lịch sử các trang đã xem và từ khoá tìm kiếm",
                    checked = clearHistory,
                    onCheckedChange = { clearHistory = it }
                )

                ClearOptionRow(
                    label = "Ảnh và tệp lưu trong bộ nhớ đệm (Cache)",
                    description = "Giải phóng dung lượng bộ nhớ tạm",
                    checked = clearCache,
                    onCheckedChange = { clearCache = it }
                )

                ClearOptionRow(
                    label = "Cookie và dữ liệu trang web",
                    description = "Đăng xuất khỏi hầu hết các trang web",
                    checked = clearCookies,
                    onCheckedChange = { clearCookies = it }
                )

                ClearOptionRow(
                    label = "Số liệu chặn đã thống kê",
                    description = "Đặt lại bộ đếm quảng cáo, theo dõi và popup",
                    checked = clearProtectionStats,
                    onCheckedChange = { clearProtectionStats = it }
                )

                ClearOptionRow(
                    label = "Quyền đã nhớ cho từng trang",
                    description = "Đặt lại quyền vị trí, camera và micro",
                    checked = clearSitePermissions,
                    onCheckedChange = { clearSitePermissions = it }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmClear(
                        clearHistory,
                        clearCookies,
                        clearCache,
                        clearProtectionStats,
                        clearSitePermissions
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                enabled = clearHistory || clearCookies || clearCache || clearProtectionStats || clearSitePermissions
            ) {
                Text("Xoá dữ liệu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Huỷ")
            }
        }
    )
}

@Composable
private fun ClearOptionRow(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
