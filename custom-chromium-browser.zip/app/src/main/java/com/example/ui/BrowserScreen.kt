package com.example.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SitePolicyStore
import com.example.data.local.TabProtectionStats
import com.example.gecko.YouTubeExtractorRepo
import com.example.ui.components.AboutGeckoDialog
import com.example.ui.components.AuraIntro
import com.example.ui.components.ChromeBookmarksSheet
import com.example.ui.components.ChromeContextMenuSheet
import com.example.ui.components.ChromeDownloadsScreen
import com.example.ui.components.ChromeFindInPageBar
import com.example.ui.components.ChromeHistorySheet
import com.example.ui.components.ChromeLoadingBar
import com.example.ui.components.ChromeNewTabPage
import com.example.ui.components.ChromePagePromptDialog
import com.example.ui.components.ChromePermissionDialog
import com.example.ui.components.ChromePolicyManagementDialog
import com.example.ui.components.ChromeTabSwitcher
import com.example.ui.components.ChromeTopBar
import com.example.ui.components.ClearBrowsingDataDialog
import com.example.ui.components.DiagnosticsDialog
import com.example.ui.components.GeckoViewContainer
import com.example.ui.components.ProtectionStatsDialog
import com.example.ui.components.SaviorAudioFallbackDialog
import com.example.ui.components.SaviorBottomSheet
import com.example.ui.components.SaviorFloatingButtonOverlay
import com.example.ui.components.SaviorYouTubeDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val isExternalViewIntent = (context as? android.app.Activity)?.intent?.action == Intent.ACTION_VIEW
    var showIntro by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) {
            listOf<ImageVector>(
                Icons.Rounded.Add,
                Icons.Default.VisibilityOff,
                Icons.Default.Star,
                Icons.Default.StarBorder,
                Icons.Default.Bookmark,
                Icons.Default.History,
                Icons.Default.Download,
                Icons.Default.Shield,
                Icons.Default.PlayArrow,
                Icons.Default.DesktopWindows,
                Icons.Default.Share,
                Icons.Default.FindInPage,
                Icons.Default.Settings,
                Icons.Default.Block,
                Icons.Default.OpenInNew,
                Icons.Default.Cookie,
                Icons.Default.Lock,
                Icons.Default.Security,
                Icons.Default.DeleteSweep,
                Icons.Default.Delete,
                Icons.Default.Info,
                Icons.Default.MoreVert,
                Icons.Default.Search,
                Icons.Default.Refresh,
                Icons.Default.Close,
                Icons.Default.Clear,
                Icons.AutoMirrored.Filled.ArrowForward
            ).size
        }
    }

    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
    val mediaState by viewModel.mediaState.collectAsStateWithLifecycle()

    val activeTab by remember {
        derivedStateOf {
            tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
        }
    }

    val isStartPageDisplay by remember {
        derivedStateOf {
            val tab = activeTab
            tab == null || tab.isStartPage ||
                ((tab.url.isBlank() || tab.url == "about:blank") && !tab.isLoading)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP || event == Lifecycle.Event.ON_PAUSE) {
                viewModel.onAppBackgrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    BrowserSnackbarEffect(viewModel = viewModel, snackbarHostState = snackbarHostState)
    BrowserBackHandler(viewModel = viewModel, context = context)

    Box(modifier = modifier.fillMaxSize()) {
        // Scaffold is always composed so GeckoView is not destroyed when opening tab switcher or dialogs
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = {
                if (!isFullscreen) {
                    SnackbarHost(snackbarHostState)
                }
            },
            modifier = Modifier.fillMaxSize(),
            topBar = {
                if (!isFullscreen) {
                    Column {
                        BrowserTopBarSection(viewModel = viewModel)
                        BrowserLoadingBarSection(viewModel = viewModel)
                        BrowserFindInPageSection(viewModel = viewModel)
                    }
                }
            }
        ) { paddingValues ->
            val effectivePadding = if (isFullscreen) PaddingValues(0.dp) else paddingValues
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(effectivePadding)
            ) {
                val currentTabId = activeTab?.id
                val currentSession = activeTab?.session
                val keepSessionActive = mediaState?.let { it.tabId == currentTabId && it.isPlaying } == true
                if (currentTabId != null && currentSession != null) {
                    GeckoViewContainer(
                        tabId = currentTabId,
                        session = currentSession,
                        keepSessionActiveInBackground = keepSessionActive,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Draw ChromeNewTabPage on top with opaque background when isStartPageDisplay is true
                if (isStartPageDisplay) {
                    BrowserNewTabPageOverlay(
                        viewModel = viewModel,
                        isPrivate = activeTab?.isPrivate == true
                    )
                }

                // Nút nổi Savior ở góc dưới bên phải vùng web (ẩn khi fullscreen hoặc ở trang tab mới)
                if (!isFullscreen && !isStartPageDisplay) {
                    BrowserSaviorFloatingOverlay(viewModel = viewModel)
                }

                // Tab switcher rendered as an overlay on top (in Box) without tearing down GeckoView
                BrowserTabSwitcherOverlay(viewModel = viewModel)

                // Gợi ý từ lịch sử tìm kiếm khi đang sửa omnibox
                BrowserOmniboxSuggestionsOverlay(viewModel = viewModel)
            }
        }

        BrowserDialogsSection(viewModel = viewModel)

        if (showIntro && !isExternalViewIntent) {
            AuraIntro(
                onFinished = { showIntro = false }
            )
        }
    }
}

@Composable
private fun BrowserSnackbarEffect(
    viewModel: BrowserViewModel,
    snackbarHostState: SnackbarHostState
) {
    val snackbarEvent by viewModel.snackbarEvent.collectAsStateWithLifecycle()

    LaunchedEffect(snackbarEvent) {
        snackbarEvent?.let { event ->
            val result = snackbarHostState.showSnackbar(
                message = event.message,
                actionLabel = event.actionLabel,
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) {
                event.onAction?.invoke()
            }
            viewModel.clearSnackbarEvent()
        }
    }
}

@Composable
private fun BrowserBackHandler(
    viewModel: BrowserViewModel,
    context: android.content.Context
) {
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
    val showFindInPage by viewModel.showFindInPage.collectAsStateWithLifecycle()
    val showTabSwitcher by viewModel.showTabSwitcher.collectAsStateWithLifecycle()
    val isEditingOmnibox by viewModel.isEditingOmnibox.collectAsStateWithLifecycle()

    val activeTab by remember {
        derivedStateOf {
            tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
        }
    }

    BackHandler(enabled = true) {
        when {
            isFullscreen -> viewModel.exitFullscreen()
            showFindInPage -> viewModel.setShowFindInPage(false)
            showTabSwitcher -> viewModel.setShowTabSwitcher(false)
            isEditingOmnibox -> viewModel.setIsEditingOmnibox(false)
            activeTab?.canGoBack == true -> viewModel.goBackActiveTab()
            tabs.size > 1 -> viewModel.closeTab(activeTabId)
            else -> {
                (context as? android.app.Activity)?.finish()
            }
        }
    }
}

@Composable
private fun BrowserTopBarSection(viewModel: BrowserViewModel) {
    val context = LocalContext.current
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val isEditingOmnibox by viewModel.isEditingOmnibox.collectAsStateWithLifecycle()
    val omniboxInput by viewModel.omniboxInput.collectAsStateWithLifecycle()
    val isBookmarked by viewModel.isCurrentPageBookmarked.collectAsStateWithLifecycle()
    val showOverflowMenu by viewModel.showOverflowMenu.collectAsStateWithLifecycle()
    val popupAllowedHosts by viewModel.popupAllowedHosts.collectAsStateWithLifecycle()
    val blockCookies by viewModel.blockCookies.collectAsStateWithLifecycle()
    val ublockEnabled by viewModel.ublockEnabled.collectAsStateWithLifecycle()
    val cleanOverlayEnabled by viewModel.cleanOverlayEnabled.collectAsStateWithLifecycle()
    val backgroundPlayEnabled by viewModel.backgroundPlayEnabled.collectAsStateWithLifecycle()
    val saviorEnabled by viewModel.saviorEnabled.collectAsStateWithLifecycle()
    val devtoolsEnabled by viewModel.devtoolsEnabled.collectAsStateWithLifecycle()
    val drmEnabled by viewModel.drmEnabled.collectAsStateWithLifecycle()
    val tabStatsMap by viewModel.tabStatsMap.collectAsStateWithLifecycle()

    val activeTab by remember {
        derivedStateOf {
            tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
        }
    }

    val isStartPageDisplay by remember {
        derivedStateOf {
            val tab = activeTab
            tab == null || tab.isStartPage ||
                ((tab.url.isBlank() || tab.url == "about:blank") && !tab.isLoading)
        }
    }

    val isCurrentSitePopupAllowed by remember {
        derivedStateOf {
            val host = SitePolicyStore.normalizeHost(activeTab?.url ?: "")
            @Suppress("UNUSED_EXPRESSION")
            popupAllowedHosts
            viewModel.sitePolicyStore.isPopupAllowed(host)
        }
    }

    val protectionBadgeCount by remember {
        derivedStateOf {
            val stats = tabStatsMap[activeTab?.id] ?: TabProtectionStats()
            stats.adsBlocked + stats.trackersBlocked + stats.overlaysRemoved
        }
    }

    ChromeTopBar(
        tabUrl = activeTab?.url ?: "",
        tabIsLoading = activeTab?.isLoading == true,
        tabIsStartPage = isStartPageDisplay,
        tabIsDesktopMode = activeTab?.isDesktopMode == true,
        tabIsSecure = activeTab?.isSecure == true,
        tabsCount = tabs.size,
        isEditing = isEditingOmnibox,
        omniboxText = omniboxInput,
        isBookmarked = isBookmarked,
        showMenu = showOverflowMenu,
        onOmniboxTextChange = { viewModel.setOmniboxInput(it) },
        onStartEditing = { viewModel.setIsEditingOmnibox(true) },
        onSubmitUrl = { viewModel.submitOmnibox(it) },
        onReload = { viewModel.reloadActiveTab() },
        onStopLoading = { viewModel.stopActiveTab() },
        onOpenTabSwitcher = { viewModel.setShowTabSwitcher(true) },
        onOpenMenu = { viewModel.setShowOverflowMenu(true) },
        onDismissMenu = { viewModel.setShowOverflowMenu(false) },
        onNewTab = { viewModel.createNewTab() },
        onToggleBookmark = { viewModel.toggleBookmark() },
        onOpenBookmarks = { viewModel.setShowBookmarksDialog(true) },
        onOpenHistory = { viewModel.setShowHistoryDialog(true) },
        onOpenDownloads = { viewModel.setShowDownloadsScreen(true) },
        onToggleDesktop = { viewModel.toggleDesktopMode() },
        onShare = {
            val url = activeTab?.url
            if (!url.isNullOrBlank()) {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, url)
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Share URL"))
            }
        },
        onFindInPage = { viewModel.setShowFindInPage(true) },
        onAboutGecko = { viewModel.setShowAboutDialog(true) },
        onBlockCurrentSite = { viewModel.blockCurrentSite() },
        isCurrentSitePopupAllowed = isCurrentSitePopupAllowed,
        onTogglePopupCurrentSite = { viewModel.togglePopupForCurrentSite() },
        blockThirdPartyCookies = blockCookies,
        onToggleBlockCookies = { viewModel.toggleBlockCookies() },
        isUblockEnabled = ublockEnabled,
        onToggleUblock = { viewModel.toggleUblock() },
        isCleanOverlayEnabled = cleanOverlayEnabled,
        onToggleCleanOverlay = { viewModel.toggleCleanOverlay() },
        isBackgroundPlayEnabled = backgroundPlayEnabled,
        onToggleBackgroundPlay = { viewModel.toggleBackgroundPlay() },
        isSaviorEnabled = saviorEnabled,
        onToggleSavior = { viewModel.toggleSavior() },
        isDevtoolsEnabled = devtoolsEnabled,
        onToggleDevtools = { viewModel.toggleDevtools() },
        isDrmEnabled = drmEnabled,
        onToggleDrm = { viewModel.toggleDrm() },
        onOpenPolicyManagement = { viewModel.setShowPolicyManagementDialog(true) },
        onOpenDiagnostics = { viewModel.openDiagnostics() },
        onOpenProtectionStats = { viewModel.openProtectionStatsDialog() },
        onClearSearchHistory = { viewModel.clearSearchHistory() },
        onClearBrowsingData = { viewModel.setShowClearBrowsingDataDialog(true) },
        onNewPrivateTab = { viewModel.createNewTab(isPrivate = true) },
        isPrivate = activeTab?.isPrivate == true,
        protectionBadgeCount = protectionBadgeCount
    )
}

@Composable
private fun BrowserLoadingBarSection(viewModel: BrowserViewModel) {
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()

    val loadingState by remember {
        derivedStateOf {
            val tab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
            (tab?.isLoading == true) to (tab?.progress ?: 0)
        }
    }

    ChromeLoadingBar(
        isLoading = loadingState.first,
        progress = loadingState.second
    )
}

@Composable
private fun BrowserFindInPageSection(viewModel: BrowserViewModel) {
    val showFindInPage by viewModel.showFindInPage.collectAsStateWithLifecycle()
    val findQuery by viewModel.findQuery.collectAsStateWithLifecycle()

    AnimatedVisibility(
        visible = showFindInPage,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        ChromeFindInPageBar(
            query = findQuery,
            onQueryChange = { viewModel.setFindQuery(it) },
            onClose = { viewModel.setShowFindInPage(false) }
        )
    }
}

@Composable
private fun BrowserNewTabPageOverlay(
    viewModel: BrowserViewModel,
    isPrivate: Boolean
) {
    val blockedHosts by viewModel.blockedHosts.collectAsStateWithLifecycle()
    val shortcuts by viewModel.shortcuts.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        ChromeNewTabPage(
            bookmarksFlow = viewModel.bookmarksFlow,
            onSelectUrl = { url -> viewModel.submitOmnibox(url) },
            onSearch = { query -> viewModel.submitOmnibox(query) },
            isPrivate = isPrivate,
            blockedHosts = blockedHosts,
            shortcuts = shortcuts,
            onAddShortcut = { title, url -> viewModel.addShortcut(title, url) },
            onEditShortcut = { id, title, url -> viewModel.editShortcut(id, title, url) },
            onDeleteShortcut = { id -> viewModel.deleteShortcut(id) }
        )
    }
}

@Composable
private fun BrowserTabSwitcherOverlay(viewModel: BrowserViewModel) {
    val showTabSwitcher by viewModel.showTabSwitcher.collectAsStateWithLifecycle()
    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()

    AnimatedVisibility(
        visible = showTabSwitcher,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        ChromeTabSwitcher(
            tabs = tabs,
            activeTabId = activeTabId,
            onSelectTab = { viewModel.selectTab(it) },
            onCloseTab = { viewModel.closeTab(it) },
            onNewTab = { viewModel.createNewTab() },
            onCloseAllTabs = { viewModel.closeAllTabs() },
            onCloseAllPrivateTabs = { viewModel.closeAllPrivateTabs() },
            onDismiss = { viewModel.setShowTabSwitcher(false) }
        )
    }
}

@Composable
private fun BoxScope.BrowserOmniboxSuggestionsOverlay(viewModel: BrowserViewModel) {
    val isEditingOmnibox by viewModel.isEditingOmnibox.collectAsStateWithLifecycle()
    if (!isEditingOmnibox) return

    val omniboxInput by viewModel.omniboxInput.collectAsStateWithLifecycle()
    val searchHistory by viewModel.searchHistory.collectAsStateWithLifecycle()
    val blockedHosts by viewModel.blockedHosts.collectAsStateWithLifecycle()

    val suggestions by remember {
        derivedStateOf {
            val q = omniboxInput.trim()
            searchHistory
                .filterNot { item ->
                    val targetHost = SitePolicyStore.normalizeHost(item)
                    val lowerItem = item.lowercase()
                    blockedHosts.any { blocked ->
                        val normalizedBlocked = SitePolicyStore.normalizeHost(blocked)
                        normalizedBlocked.isNotBlank() && (
                            targetHost == normalizedBlocked ||
                            targetHost.endsWith(".$normalizedBlocked") ||
                            lowerItem.contains(normalizedBlocked)
                        )
                    }
                }
                .filter { q.isBlank() || it.contains(q, ignoreCase = true) }
                .filterNot { it.equals(q, ignoreCase = true) }
                .take(6)
        }
    }

    if (suggestions.isNotEmpty()) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            tonalElevation = 6.dp,
            shadowElevation = 8.dp,
            shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                suggestions.forEach { s ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.setIsEditingOmnibox(false)
                                viewModel.submitOmnibox(s)
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = s,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = { viewModel.removeSearchQuery(s) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Xoá",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                TextButton(
                    onClick = { viewModel.clearSearchHistory() },
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text("Xoá lịch sử tìm kiếm", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun BrowserSaviorFloatingOverlay(viewModel: BrowserViewModel) {
    val saviorEnabled by viewModel.saviorEnabled.collectAsStateWithLifecycle()
    if (!saviorEnabled) return

    val showTabSwitcher by viewModel.showTabSwitcher.collectAsStateWithLifecycle()
    if (showTabSwitcher) return

    val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
    if (isFullscreen) return

    val tabs by viewModel.tabs.collectAsStateWithLifecycle()
    val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
    val detectedMediaByTab by viewModel.detectedMediaByTab.collectAsStateWithLifecycle()

    val activeTab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
    val currentTab = activeTab
    if (currentTab == null || currentTab.isStartPage) return

    val isYouTubeVideoPage = YouTubeExtractorRepo.isYouTubeVideoUrl(currentTab.url)
    val downloadableCount = detectedMediaByTab[currentTab.id].orEmpty().count { !it.isProtected }

    if (isYouTubeVideoPage || downloadableCount > 0) {
        SaviorFloatingButtonOverlay(
            downloadableCount = downloadableCount,
            alwaysVisible = isYouTubeVideoPage,
            onClick = {
                if (isYouTubeVideoPage) {
                    viewModel.openYtDialog(currentTab.url)
                } else {
                    viewModel.setShowSaviorSheet(true)
                }
            }
        )
    }
}

@Composable
private fun BrowserDialogsSection(viewModel: BrowserViewModel) {
    BookmarksDialogHost(viewModel)
    HistoryDialogHost(viewModel)
    DownloadsDialogHost(viewModel)
    PolicyManagementDialogHost(viewModel)
    AboutDialogHost(viewModel)
    DiagnosticsDialogHost(viewModel)
    ProtectionStatsDialogHost(viewModel)
    ClearBrowsingDataDialogHost(viewModel)
    SaviorBottomSheetHost(viewModel)
    PromptsAndContextMenuHost(viewModel)
}

@Composable
private fun DownloadsDialogHost(viewModel: BrowserViewModel) {
    val showDownloadsScreen by viewModel.showDownloadsScreen.collectAsStateWithLifecycle()
    if (showDownloadsScreen) {
        val downloadedFiles by viewModel.downloadedFiles.collectAsStateWithLifecycle()
        val saviorDownloadStates by viewModel.saviorDownloadStates.collectAsStateWithLifecycle()

        ChromeDownloadsScreen(
            downloadedFiles = downloadedFiles,
            downloadStates = saviorDownloadStates,
            onRefresh = { viewModel.loadDownloadedFiles() },
            onDeleteFile = { viewModel.deleteDownloadedFile(it) },
            onCancelDownload = { viewModel.cancelSaviorDownload(it) },
            onDismiss = { viewModel.setShowDownloadsScreen(false) }
        )
    }
}

@Composable
private fun SaviorBottomSheetHost(viewModel: BrowserViewModel) {
    val showSaviorSheet by viewModel.showSaviorSheet.collectAsStateWithLifecycle()
    val saviorEnabled by viewModel.saviorEnabled.collectAsStateWithLifecycle()
    val audioFallbackPrompt by viewModel.audioFallbackPrompt.collectAsStateWithLifecycle()
    val ytDialogState by viewModel.ytDialogState.collectAsStateWithLifecycle()
    val saviorDownloadStates by viewModel.saviorDownloadStates.collectAsStateWithLifecycle()

    if (showSaviorSheet && saviorEnabled) {
        val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
        val detectedMediaByTab by viewModel.detectedMediaByTab.collectAsStateWithLifecycle()
        val currentItems = detectedMediaByTab[activeTabId].orEmpty()

        SaviorBottomSheet(
            items = currentItems,
            downloadStates = saviorDownloadStates,
            onDownloadVideo = { item ->
                viewModel.onDownloadVideo(item)
            },
            onDownloadAudio = { item ->
                viewModel.onDownloadAudio(item)
            },
            onCancelDownload = { itemId ->
                viewModel.cancelSaviorDownload(itemId)
            },
            onDismiss = { viewModel.setShowSaviorSheet(false) }
        )
    }

    val currentYtDialogState = ytDialogState
    if (currentYtDialogState != null && saviorEnabled) {
        SaviorYouTubeDialog(
            state = currentYtDialogState,
            downloadStates = saviorDownloadStates,
            onSelectOption = { optionId ->
                viewModel.selectOption(optionId)
            },
            onConfirmDownload = {
                viewModel.confirmDownload()
            },
            onRetry = {
                viewModel.retryYtDialog()
            },
            onCancelDownload = { itemId ->
                viewModel.cancelSaviorDownload(itemId)
            },
            onDismiss = {
                viewModel.dismissYtDialog()
            }
        )
    }

    audioFallbackPrompt?.let { fallback ->
        SaviorAudioFallbackDialog(
            fallback = fallback,
            onConfirmSaveVideo = { viewModel.confirmSaveVideoFromAudioFallback() },
            onDismissDiscard = { viewModel.dismissAudioFallback() }
        )
    }
}

@Composable
private fun BookmarksDialogHost(viewModel: BrowserViewModel) {
    val showBookmarksDialog by viewModel.showBookmarksDialog.collectAsStateWithLifecycle()
    if (showBookmarksDialog) {
        ChromeBookmarksSheet(
            bookmarksFlow = viewModel.bookmarksFlow,
            onSelectBookmark = { viewModel.openBookmark(it) },
            onDeleteBookmark = { viewModel.deleteBookmark(it) },
            onDismiss = { viewModel.setShowBookmarksDialog(false) }
        )
    }
}

@Composable
private fun HistoryDialogHost(viewModel: BrowserViewModel) {
    val showHistoryDialog by viewModel.showHistoryDialog.collectAsStateWithLifecycle()
    if (showHistoryDialog) {
        ChromeHistorySheet(
            historyFlow = viewModel.historyFlow,
            onSelectHistory = { viewModel.openHistory(it) },
            onDeleteHistory = { viewModel.deleteHistory(it) },
            onClearAllHistory = { viewModel.clearAllHistory() },
            onDismiss = { viewModel.setShowHistoryDialog(false) }
        )
    }
}

@Composable
private fun PolicyManagementDialogHost(viewModel: BrowserViewModel) {
    val showPolicyManagementDialog by viewModel.showPolicyManagementDialog.collectAsStateWithLifecycle()
    if (showPolicyManagementDialog) {
        val blockedHosts by viewModel.blockedHosts.collectAsStateWithLifecycle()
        val popupAllowedHosts by viewModel.popupAllowedHosts.collectAsStateWithLifecycle()
        ChromePolicyManagementDialog(
            blockedHosts = blockedHosts,
            popupAllowedHosts = popupAllowedHosts,
            onAddBlockedHost = { viewModel.blockSite(it) },
            onRemoveBlockedHost = { viewModel.unblockHost(it) },
            onRemovePopupAllowedHost = { viewModel.removePopupAllowedHost(it) },
            onDismiss = { viewModel.setShowPolicyManagementDialog(false) }
        )
    }
}

@Composable
private fun AboutDialogHost(viewModel: BrowserViewModel) {
    val showAboutDialog by viewModel.showAboutDialog.collectAsStateWithLifecycle()
    if (showAboutDialog) {
        AboutGeckoDialog(onDismiss = { viewModel.setShowAboutDialog(false) })
    }
}

@Composable
private fun DiagnosticsDialogHost(viewModel: BrowserViewModel) {
    val showDiagnosticsDialog by viewModel.showDiagnosticsDialog.collectAsStateWithLifecycle()
    if (showDiagnosticsDialog) {
        val diagnosticsLogs by viewModel.diagnosticsLogs.collectAsStateWithLifecycle()
        DiagnosticsDialog(
            logs = diagnosticsLogs,
            onDismiss = { viewModel.closeDiagnostics() }
        )
    }
}

@Composable
private fun ProtectionStatsDialogHost(viewModel: BrowserViewModel) {
    val showProtectionStatsDialog by viewModel.showProtectionStatsDialog.collectAsStateWithLifecycle()
    if (showProtectionStatsDialog) {
        val tabs by viewModel.tabs.collectAsStateWithLifecycle()
        val activeTabId by viewModel.activeTabId.collectAsStateWithLifecycle()
        val tabStatsMap by viewModel.tabStatsMap.collectAsStateWithLifecycle()
        val totalAdsBlocked by viewModel.totalAdsBlocked.collectAsStateWithLifecycle()
        val totalTrackersBlocked by viewModel.totalTrackersBlocked.collectAsStateWithLifecycle()
        val totalPopupsBlocked by viewModel.totalPopupsBlocked.collectAsStateWithLifecycle()
        val overlaysRemoved by viewModel.overlaysRemoved.collectAsStateWithLifecycle()
        val blockedHosts by viewModel.blockedHosts.collectAsStateWithLifecycle()
        val popupAllowedHosts by viewModel.popupAllowedHosts.collectAsStateWithLifecycle()

        val currentTabStats by remember {
            derivedStateOf {
                val activeTab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()
                tabStatsMap[activeTab?.id] ?: TabProtectionStats()
            }
        }

        ProtectionStatsDialog(
            currentAds = currentTabStats.adsBlocked,
            currentTrackers = currentTabStats.trackersBlocked,
            currentPopups = currentTabStats.popupsBlocked,
            currentOverlaysRemoved = currentTabStats.overlaysRemoved,
            totalAds = totalAdsBlocked,
            totalTrackers = totalTrackersBlocked,
            totalPopups = totalPopupsBlocked,
            overlaysRemoved = overlaysRemoved,
            blockedSitesCount = blockedHosts.size,
            popupAllowedSitesCount = popupAllowedHosts.size,
            openTabsCount = tabs.size,
            onResetTotals = { viewModel.resetProtectionTotals() },
            onDismiss = { viewModel.closeProtectionStatsDialog() }
        )
    }
}

@Composable
private fun ClearBrowsingDataDialogHost(viewModel: BrowserViewModel) {
    val showClearBrowsingDataDialog by viewModel.showClearBrowsingDataDialog.collectAsStateWithLifecycle()
    if (showClearBrowsingDataDialog) {
        ClearBrowsingDataDialog(
            onDismiss = { viewModel.setShowClearBrowsingDataDialog(false) },
            onConfirmClear = { clearHistory, clearCookies, clearCache, clearProtectionStats, clearSitePermissions ->
                viewModel.clearBrowsingData(
                    clearHistory = clearHistory,
                    clearCookies = clearCookies,
                    clearCache = clearCache,
                    clearProtectionStats = clearProtectionStats,
                    clearSitePermissions = clearSitePermissions
                )
            }
        )
    }
}

@Composable
private fun PromptsAndContextMenuHost(viewModel: BrowserViewModel) {
    val pagePrompt by viewModel.pagePrompt.collectAsStateWithLifecycle()
    val permissionPrompt by viewModel.permissionPrompt.collectAsStateWithLifecycle()
    val contextMenuState by viewModel.contextMenuState.collectAsStateWithLifecycle()

    pagePrompt?.let { prompt ->
        ChromePagePromptDialog(prompt = prompt)
    }

    permissionPrompt?.let { prompt ->
        ChromePermissionDialog(prompt = prompt)
    }

    contextMenuState?.let { state ->
        ChromeContextMenuSheet(
            state = state,
            onOpenInNewTab = { viewModel.openLinkInNewTab(it) },
            onOpenInCurrentTab = { viewModel.openLinkInCurrentTab(it) },
            onCopyLink = { viewModel.copyToClipboard(it, "liên kết") },
            onShareLink = { viewModel.shareLink(it) },
            onBlockSite = { viewModel.blockSite(it) },
            onViewImage = { viewModel.createNewTab(initialUrl = it, switchToIt = true) },
            onCopyImageLink = { viewModel.copyToClipboard(it, "link ảnh") },
            onSaveImage = { viewModel.saveImage(it) },
            onDismiss = { viewModel.dismissContextMenu() }
        )
    }
}
