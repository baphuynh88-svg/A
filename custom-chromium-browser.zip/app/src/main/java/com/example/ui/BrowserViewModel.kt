package com.example.ui

import android.app.Application
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.local.BookmarkEntity
import com.example.data.local.BrowserDatabase
import com.example.data.local.BrowserRepository
import com.example.data.local.HistoryEntity
import com.example.data.local.ProtectionStatsStore
import com.example.data.local.SavedTabInfo
import com.example.data.local.SearchHistoryStore
import com.example.data.local.ShortcutItem
import com.example.data.local.ShortcutStore
import com.example.data.local.SitePermissionStore
import com.example.data.local.SitePolicyStore
import com.example.data.local.TabProtectionStats
import com.example.data.local.TabSessionStore
import com.example.gecko.AuraMediaEvent
import com.example.gecko.AudioExtractionFallback
import com.example.gecko.BrowserTab
import com.example.gecko.ContextMenuState
import com.example.gecko.DownloadHelper
import com.example.gecko.DownloadResult
import com.example.gecko.DownloadService
import com.example.gecko.GeckoEngine
import com.example.gecko.GeckoTabHelper
import com.example.gecko.HttpStatusMessages
import com.example.gecko.MediaController
import com.example.gecko.MediaDownloader
import com.example.gecko.MediaItem
import com.example.gecko.MediaKind
import com.example.gecko.MediaNotificationData
import com.example.gecko.MediaPlaybackService
import com.example.gecko.MediaState
import com.example.gecko.PageTranslation
import com.example.gecko.PagePrompt
import com.example.gecko.PermissionBridge
import com.example.gecko.PermissionPrompt
import com.example.gecko.SaviorItemDownloadState
import com.example.gecko.SaviorMediaPayload
import com.example.gecko.YouTubeExtractorRepo
import com.example.gecko.YtMedia
import com.example.gecko.YtOption
import com.example.ui.components.AuraDownloadsQueryHelper
import com.example.ui.components.DownloadedFileItem
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.WebResponse
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.net.URLEncoder

enum class SearchEngine(val displayName: String, val searchUrl: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q=")
}

data class SnackbarEvent(
    val message: String,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null
)

sealed interface YtDialogState {
    data object Loading : YtDialogState
    data class Ready(val media: YtMedia, val selectedId: String) : YtDialogState
    data class Error(val msg: String) : YtDialogState
}

@OptIn(FlowPreview::class)
class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BrowserRepository(
        BrowserDatabase.getInstance(application).browserDao()
    )

    val sitePolicyStore = SitePolicyStore(application)
    val sitePermissionStore = SitePermissionStore(application)
    val protectionStatsStore = ProtectionStatsStore(application)
    val searchHistoryStore = SearchHistoryStore(application)
    val shortcutStore = ShortcutStore(application)
    val tabSessionStore = TabSessionStore(application)

    val shortcuts: StateFlow<List<ShortcutItem>> = shortcutStore.shortcuts
    val blockedHosts: StateFlow<Set<String>> = sitePolicyStore.blockedHosts
    val popupAllowedHosts: StateFlow<Set<String>> = sitePolicyStore.popupAllowedHosts
    val blockCookies: StateFlow<Boolean> = sitePolicyStore.blockCookies
    val ublockEnabled: StateFlow<Boolean> = sitePolicyStore.ublockEnabled
    val cleanOverlayEnabled: StateFlow<Boolean> = sitePolicyStore.cleanOverlayEnabled
    val backgroundPlayEnabled: StateFlow<Boolean> = sitePolicyStore.backgroundPlayEnabled
    val saviorEnabled: StateFlow<Boolean> = sitePolicyStore.saviorEnabled
    val devtoolsEnabled: StateFlow<Boolean> = sitePolicyStore.devtoolsEnabled

    private fun isUrlHostBlocked(url: String, blockedSet: Set<String>): Boolean {
        val targetHost = SitePolicyStore.normalizeHost(url)
        if (targetHost.isBlank()) return false
        return blockedSet.any { blocked ->
            val normalizedBlocked = SitePolicyStore.normalizeHost(blocked)
            normalizedBlocked.isNotBlank() && (
                targetHost == normalizedBlocked ||
                targetHost.endsWith(".$normalizedBlocked")
            )
        }
    }

    private fun isQueryOrUrlBlocked(raw: String, blockedSet: Set<String>): Boolean {
        val trimmed = raw.trim().lowercase()
        if (trimmed.isBlank()) return false
        val targetHost = SitePolicyStore.normalizeHost(trimmed)
        return blockedSet.any { blocked ->
            val normalizedBlocked = SitePolicyStore.normalizeHost(blocked)
            normalizedBlocked.isNotBlank() && (
                targetHost == normalizedBlocked ||
                targetHost.endsWith(".$normalizedBlocked") ||
                trimmed.contains(normalizedBlocked)
            )
        }
    }

    val searchHistory: StateFlow<List<String>> = combine(
        searchHistoryStore.queries,
        blockedHosts
    ) { queries, blockedSet ->
        queries.filterNot { isQueryOrUrlBlocked(it, blockedSet) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAdsBlocked: StateFlow<Long> = protectionStatsStore.totalAds
    val totalTrackersBlocked: StateFlow<Long> = protectionStatsStore.totalTrackers
    val totalPopupsBlocked: StateFlow<Long> = protectionStatsStore.totalPopups
    val overlaysRemoved: StateFlow<Long> = protectionStatsStore.overlaysRemoved
    val tabStatsMap: StateFlow<Map<String, TabProtectionStats>> = protectionStatsStore.tabStatsMap

    @Volatile
    private var lastOverlaySnackbarAt: Long = 0L
    private var lastHttpStatusKey: String = ""
    private var lastHttpStatusAt: Long = 0L

    private val _showProtectionStatsDialog = MutableStateFlow(false)
    val showProtectionStatsDialog: StateFlow<Boolean> = _showProtectionStatsDialog.asStateFlow()

    private val _snackbarEvent = MutableStateFlow<SnackbarEvent?>(null)
    val snackbarEvent: StateFlow<SnackbarEvent?> = _snackbarEvent.asStateFlow()

    private val _showPolicyManagementDialog = MutableStateFlow(false)
    val showPolicyManagementDialog: StateFlow<Boolean> = _showPolicyManagementDialog.asStateFlow()

    private val _pagePrompt = MutableStateFlow<PagePrompt?>(null)
    val pagePrompt: StateFlow<PagePrompt?> = _pagePrompt.asStateFlow()

    private val _permissionPrompt = MutableStateFlow<PermissionPrompt?>(null)
    val permissionPrompt: StateFlow<PermissionPrompt?> = _permissionPrompt.asStateFlow()

    private val _contextMenuState = MutableStateFlow<ContextMenuState?>(null)
    val contextMenuState: StateFlow<ContextMenuState?> = _contextMenuState.asStateFlow()

    private val _isFullscreen = MutableStateFlow(false)
    val isFullscreen: StateFlow<Boolean> = _isFullscreen.asStateFlow()

    private val _mediaState = MutableStateFlow<MediaState?>(null)
    val mediaState: StateFlow<MediaState?> = _mediaState.asStateFlow()

    // Danh sách media phát hiện bởi tiện ích Savior theo từng tab (tối đa 30 mục/tab, khử trùng theo url)
    private val _detectedMediaByTab = MutableStateFlow<Map<String, List<MediaItem>>>(emptyMap())
    val detectedMediaByTab: StateFlow<Map<String, List<MediaItem>>> = _detectedMediaByTab.asStateFlow()
    val mediaItemsByTab: StateFlow<Map<String, List<MediaItem>>>
        get() = detectedMediaByTab

    private val _showSaviorSheet = MutableStateFlow(false)
    val showSaviorSheet: StateFlow<Boolean> = _showSaviorSheet.asStateFlow()

    private val _ytDialogState = MutableStateFlow<YtDialogState?>(null)
    val ytDialogState: StateFlow<YtDialogState?> = _ytDialogState.asStateFlow()

    private val _ytDialogUrl = MutableStateFlow<String?>(null)
    val ytDialogUrl: StateFlow<String?> = _ytDialogUrl.asStateFlow()

    private var ytExtractJob: Job? = null

    val saviorDownloadStates: StateFlow<Map<String, SaviorItemDownloadState>> = DownloadService.downloadStates

    private val _audioFallbackPrompt = MutableStateFlow<AudioExtractionFallback?>(null)
    val audioFallbackPrompt: StateFlow<AudioExtractionFallback?> = _audioFallbackPrompt.asStateFlow()

    private var hasRequestedDownloadNotifications: Boolean = false

    private fun requestDownloadNotificationPermissionOnceIfNeeded() {
        if (hasRequestedDownloadNotifications) return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            hasRequestedDownloadNotifications = true
            val app = getApplication<Application>()
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(
                app,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted) {
                PermissionBridge.requester?.invoke(
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS)
                ) { _ ->
                    // Từ chối vẫn tải bình thường
                }
            }
        }
    }

    fun setShowSaviorSheet(show: Boolean) {
        _showSaviorSheet.value = show
    }

    fun openYtDialog(url: String) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isBlank()) return
        ytExtractJob?.cancel()
        _showSaviorSheet.value = false
        _ytDialogUrl.value = trimmedUrl
        _ytDialogState.value = YtDialogState.Loading

        ytExtractJob = viewModelScope.launch {
            try {
                val result = YouTubeExtractorRepo.load(trimmedUrl)
                result.fold(
                    onSuccess = { media ->
                        val defaultId = YouTubeExtractorRepo.pickDefaultOptionId(media.options)
                            ?: media.options.firstOrNull()?.id.orEmpty()
                        _ytDialogState.value = YtDialogState.Ready(
                            media = media,
                            selectedId = defaultId
                        )
                    },
                    onFailure = { err ->
                        _ytDialogState.value = YtDialogState.Error(
                            msg = err.message ?: "Không lấy được thông tin video, thử lại sau"
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                _ytDialogState.value = YtDialogState.Error(
                    msg = e.message ?: "Không lấy được thông tin video, thử lại sau"
                )
            }
        }
    }

    fun retryYtDialog() {
        val url = _ytDialogUrl.value ?: activeTab?.url ?: return
        openYtDialog(url)
    }

    fun dismissYtDialog() {
        ytExtractJob?.cancel()
        ytExtractJob = null
        _ytDialogState.value = null
        _ytDialogUrl.value = null
    }

    fun selectOption(id: String) {
        _ytDialogState.update { current ->
            if (current is YtDialogState.Ready && current.media.options.any { it.id == id }) {
                current.copy(selectedId = id)
            } else {
                current
            }
        }
    }

    fun confirmDownload() {
        val ready = _ytDialogState.value as? YtDialogState.Ready ?: return
        val option = ready.media.options.find { it.id == ready.selectedId }
            ?: ready.media.options.firstOrNull()
            ?: return
        onDownloadYoutube(option)
    }

    fun onDownloadYoutube(option: YtOption) {
        val readyState = _ytDialogState.value as? YtDialogState.Ready
        val pageUrl = _ytDialogUrl.value?.takeIf { it.isNotBlank() }
            ?: activeTab?.url.orEmpty()
        val videoTitle = readyState?.media?.title?.takeIf { it.isNotBlank() }
            ?: activeTab?.title?.takeIf { it.isNotBlank() && it != "New Tab" }
            ?: "YouTube Video"

        dismissYtDialog()
        AppLogger.d("Savior", "onDownloadYoutube: title=$videoTitle, option=${option.label} (${option.id}), url=$pageUrl")
        requestDownloadNotificationPermissionOnceIfNeeded()
        DownloadService.enqueueYouTubeDownload(
            context = getApplication(),
            pageUrl = pageUrl,
            videoTitle = videoTitle,
            option = option
        )
        _snackbarEvent.value = SnackbarEvent(message = "Đang tải ${option.label}...")
    }

    fun onDownloadVideo(item: MediaItem) {
        if (item.isProtected) {
            _snackbarEvent.value = SnackbarEvent(message = "Nội dung được bảo vệ, không thể tải")
            return
        }
        if (item.kind == MediaKind.HLS || item.kind == MediaKind.DASH) {
            _snackbarEvent.value = SnackbarEvent(message = "Sắp có")
            return
        }
        AppLogger.d("Savior", "onDownloadVideo: url=${item.url}")
        requestDownloadNotificationPermissionOnceIfNeeded()
        DownloadService.enqueueDownload(
            context = getApplication(),
            item = item,
            audioOnly = false
        )
    }

    fun onDownloadAudio(item: MediaItem) {
        if (item.isProtected) {
            _snackbarEvent.value = SnackbarEvent(message = "Nội dung được bảo vệ, không thể tải")
            return
        }
        if (item.kind == MediaKind.HLS || item.kind == MediaKind.DASH) {
            _snackbarEvent.value = SnackbarEvent(message = "Sắp có")
            return
        }
        AppLogger.d("Savior", "onDownloadAudio: url=${item.url}")
        requestDownloadNotificationPermissionOnceIfNeeded()
        DownloadService.enqueueDownload(
            context = getApplication(),
            item = item,
            audioOnly = true
        )
    }

    fun cancelSaviorDownload(itemId: String) {
        DownloadService.cancelDownload(getApplication(), itemId)
    }

    fun confirmSaveVideoFromAudioFallback() {
        val fallback = _audioFallbackPrompt.value ?: return
        _audioFallbackPrompt.value = null
        viewModelScope.launch {
            val saved = MediaDownloader.saveFallbackTempVideo(getApplication(), fallback)
            if (saved != null) {
                DownloadService.postCompletedNotification(getApplication(), saved)
                showCompletedDownloadSnackbar(saved.fileName, saved.uri, saved.mimeType)
                loadDownloadedFiles()
            } else {
                _snackbarEvent.value = SnackbarEvent(message = "Không thể lưu file video")
            }
        }
    }

    fun dismissAudioFallback() {
        val fallback = _audioFallbackPrompt.value ?: return
        _audioFallbackPrompt.value = null
        MediaDownloader.discardFallbackTempVideo(fallback)
    }

    private fun showCompletedDownloadSnackbar(fileName: String, uri: android.net.Uri?, mimeType: String?) {
        if (uri != null) {
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã tải xong $fileName",
                actionLabel = "Mở",
                onAction = {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, mimeType ?: "*/*")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        getApplication<Application>().startActivity(intent)
                    } catch (_: Exception) {
                        _snackbarEvent.value = SnackbarEvent(message = "Không có ứng dụng để mở file này")
                    }
                }
            )
        } else {
            _snackbarEvent.value = SnackbarEvent(message = "Đã tải xong $fileName")
        }
    }

    private val lastPageHostPathByTab = java.util.concurrent.ConcurrentHashMap<String, String>()

    companion object {
        const val MAX_MEDIA_ITEMS_PER_TAB = 30

        internal fun extractHostAndPath(rawUrl: String): String {
            val trimmed = rawUrl.trim()
            if (trimmed.isBlank() || trimmed == "about:blank") return ""
            return try {
                val uri = android.net.Uri.parse(trimmed)
                val host = (uri.host ?: "").lowercase().removePrefix("www.")
                if (host.isBlank()) return ""
                val path = (uri.path ?: "").ifBlank { "/" }.trimEnd('/').ifBlank { "/" }
                "$host$path"
            } catch (_: Exception) {
                ""
            }
        }
    }

    private fun handlePageStartNavigation(tabId: String, newUrl: String) {
        val newHostPath = extractHostAndPath(newUrl)
        if (newHostPath.isBlank()) return

        val currentTabUrl = _tabs.value.find { it.id == tabId }?.url ?: ""
        val prevHostPath = lastPageHostPathByTab[tabId]?.takeIf { it.isNotBlank() }
            ?: extractHostAndPath(currentTabUrl)
        val existingItemHostPath = _detectedMediaByTab.value[tabId]?.firstOrNull()?.let {
            extractHostAndPath(it.pageUrl)
        } ?: ""

        lastPageHostPathByTab[tabId] = newHostPath

        val isDifferentPage = (prevHostPath.isNotBlank() && prevHostPath != newHostPath) ||
            (existingItemHostPath.isNotBlank() && existingItemHostPath != newHostPath)

        if (isDifferentPage && _detectedMediaByTab.value.containsKey(tabId)) {
            _detectedMediaByTab.update { it - tabId }
            AppLogger.d(
                "Savior",
                "Xoá danh sách media của tabId=$tabId khi điều hướng sang trang mới ($newHostPath)"
            )
        }
    }

    private fun handleTabLocationChanged(tabId: String, newUrl: String) {
        handlePageStartNavigation(tabId, newUrl)
        if (tabId == _activeTabId.value) {
            val dialogUrl = _ytDialogUrl.value
            if (dialogUrl != null) {
                val oldVideoId = YouTubeExtractorRepo.extractVideoId(dialogUrl)
                val newVideoId = YouTubeExtractorRepo.extractVideoId(newUrl)
                if (dialogUrl != newUrl && (oldVideoId == null || oldVideoId != newVideoId)) {
                    dismissYtDialog()
                }
            }
        }
    }

    private fun resolveTabIdForSaviorPayload(payload: SaviorMediaPayload): String? {
        val directId = payload.tabId
        if (!directId.isNullOrBlank() && _tabs.value.any { it.id == directId }) {
            return directId
        }
        val currentTabs = _tabs.value
        if (currentTabs.isEmpty()) return null

        val pageUrl = payload.pageUrl.trim()
        if (pageUrl.isNotBlank()) {
            // 1. Khớp chính xác URL trang đang mở (ưu tiên activeTab)
            val active = activeTab
            if (active != null && !active.isStartPage && active.url == pageUrl) {
                return active.id
            }
            currentTabs.find { !it.isStartPage && it.url == pageUrl }?.let { return it.id }

            // 2. Khớp theo host + path
            val targetHostPath = extractHostAndPath(pageUrl)
            if (targetHostPath.isNotBlank()) {
                if (active != null && extractHostAndPath(active.url) == targetHostPath) {
                    return active.id
                }
                currentTabs.find { extractHostAndPath(it.url) == targetHostPath }?.let { return it.id }
            }

            // 3. Khớp theo host
            val targetHost = SitePolicyStore.normalizeHost(pageUrl)
            if (targetHost.isNotBlank()) {
                if (active != null && SitePolicyStore.normalizeHost(active.url) == targetHost) {
                    return active.id
                }
                currentTabs.find { SitePolicyStore.normalizeHost(it.url) == targetHost }?.let { return it.id }
            }
        }

        return _activeTabId.value.takeIf { id -> currentTabs.any { it.id == id } }
    }

    private fun handleSaviorMediaDetected(payload: SaviorMediaPayload) {
        if (!sitePolicyStore.saviorEnabled.value) return
        val rawUrl = payload.url.trim()
        if (rawUrl.isBlank() ||
            rawUrl.startsWith("blob:", ignoreCase = true) ||
            rawUrl.startsWith("data:", ignoreCase = true)
        ) {
            return
        }

        val tabId = resolveTabIdForSaviorPayload(payload) ?: return
        val tab = _tabs.value.find { it.id == tabId } ?: return

        val effectivePageUrl = tab.url.ifBlank { payload.pageUrl }
        val effectivePageTitle = payload.pageTitle.ifBlank {
            tab.title.takeIf { it.isNotBlank() && it != "New Tab" } ?: ""
        }

        val pageHostPath = extractHostAndPath(effectivePageUrl)
        if (pageHostPath.isNotBlank()) {
            lastPageHostPathByTab.putIfAbsent(tabId, pageHostPath)
        }

        var newlyAddedItem: MediaItem? = null
        _detectedMediaByTab.update { currentMap ->
            val currentList = currentMap[tabId] ?: emptyList()
            val existingIndex = currentList.indexOfFirst { it.url == rawUrl }
            if (existingIndex != -1) {
                val existing = currentList[existingIndex]
                val mergedDuration = if (existing.durationSec <= 0.0 && payload.durationSec > 0.0) {
                    payload.durationSec
                } else {
                    existing.durationSec
                }
                val mergedProtected = existing.isProtected || payload.isProtected
                if (mergedDuration != existing.durationSec || mergedProtected != existing.isProtected) {
                    val updatedList = currentList.toMutableList().apply {
                        set(
                            existingIndex,
                            existing.copy(
                                durationSec = mergedDuration,
                                isProtected = mergedProtected
                            )
                        )
                    }
                    currentMap + (tabId to updatedList)
                } else {
                    currentMap
                }
            } else {
                val item = MediaItem(
                    url = rawUrl,
                    kind = payload.kind,
                    pageUrl = effectivePageUrl,
                    pageTitle = effectivePageTitle,
                    isProtected = payload.isProtected,
                    durationSec = payload.durationSec,
                    sizeBytes = null
                )
                newlyAddedItem = item
                val appended = currentList + item
                val capped = if (appended.size > MAX_MEDIA_ITEMS_PER_TAB) {
                    appended.takeLast(MAX_MEDIA_ITEMS_PER_TAB)
                } else {
                    appended
                }
                currentMap + (tabId to capped)
            }
        }

        val added = newlyAddedItem ?: return
        val protectedTag = if (added.isProtected) " [DRM: không cho tải]" else ""
        AppLogger.d(
            "Savior",
            "Phát hiện media: tabId=$tabId, kind=${added.kind}, protected=${added.isProtected}$protectedTag, duration=${added.durationSec}s, url=${added.url}"
        )

        if ((added.kind == MediaKind.VIDEO || added.kind == MediaKind.AUDIO) && added.sizeBytes == null) {
            fetchMediaItemSizeBytes(tabId, added)
        }
    }

    private fun fetchMediaItemSizeBytes(tabId: String, item: MediaItem) {
        if (item.kind != MediaKind.VIDEO && item.kind != MediaKind.AUDIO) return
        if (item.sizeBytes != null) return
        if (!item.url.startsWith("http://", ignoreCase = true) &&
            !item.url.startsWith("https://", ignoreCase = true)
        ) {
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            var connection: java.net.HttpURLConnection? = null
            try {
                val urlObj = java.net.URL(item.url)
                connection = (urlObj.openConnection() as? java.net.HttpURLConnection)?.apply {
                    requestMethod = "HEAD"
                    connectTimeout = 5000
                    readTimeout = 5000
                    instanceFollowRedirects = true
                    if (item.pageUrl.isNotBlank()) {
                        setRequestProperty("Referer", item.pageUrl)
                    }
                }
                connection?.connect()
                val contentLength = connection?.contentLengthLong ?: -1L
                if (contentLength > 0L) {
                    var updated = false
                    _detectedMediaByTab.update { currentMap ->
                        val list = currentMap[tabId] ?: return@update currentMap
                        val newList = list.map { m ->
                            if (m.url == item.url && m.sizeBytes == null) {
                                updated = true
                                m.copy(sizeBytes = contentLength)
                            } else {
                                m
                            }
                        }
                        if (updated) currentMap + (tabId to newList) else currentMap
                    }
                    if (updated) {
                        AppLogger.d(
                            "Savior",
                            "Cập nhật dung lượng media: tabId=$tabId, sizeBytes=$contentLength, url=${item.url}"
                        )
                    }
                }
            } catch (e: Exception) {
                AppLogger.d("Savior", "HEAD Content-Length lỗi cho url=${item.url}: ${e.message}")
            } finally {
                try {
                    connection?.disconnect()
                } catch (_: Exception) {}
            }
        }
    }

    private var hasRequestedPostNotifications: Boolean = false

    private fun requestNotificationPermissionOnceIfNeeded() {
        if (hasRequestedPostNotifications) return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            hasRequestedPostNotifications = true
            val app = getApplication<Application>()
            val granted = androidx.core.content.ContextCompat.checkSelfPermission(
                app,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted) {
                PermissionBridge.requester?.invoke(
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS)
                ) { isGranted ->
                    if (isGranted) {
                        syncMediaNotification()
                    }
                }
            }
        }
    }

    private fun syncMediaNotification() {
        val current = _mediaState.value ?: return
        val tab = _tabs.value.find { it.id == current.tabId }
        val host = SitePolicyStore.normalizeHost(tab?.url ?: "")
        val title = current.title.ifBlank {
            tab?.title?.takeIf { it.isNotBlank() && it != "New Tab" } ?: host.ifBlank { "Đang phát media" }
        }
        val artistOrHost = current.artist.ifBlank { host }
        MediaPlaybackService.startOrUpdate(
            context = getApplication(),
            data = MediaNotificationData(
                tabId = current.tabId,
                title = title,
                artistOrHost = artistOrHost,
                artwork = current.artwork,
                isPlaying = current.isPlaying,
                durationMs = current.durationMs,
                positionMs = current.positionMs,
                playbackRate = current.playbackRate,
                positionUpdatedAtElapsedMs = current.positionUpdatedAtElapsedMs
            )
        )
    }

    private fun handleMediaEvent(event: AuraMediaEvent) {
        when (event) {
            is AuraMediaEvent.Activated -> {
                MediaPlaybackService.cancelScheduledDismiss()
                val tabTitle = _tabs.value.find { it.id == event.tabId }?.title?.takeIf {
                    it.isNotBlank() && it != "New Tab"
                } ?: ""
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        current.copy(
                            tabId = event.tabId,
                            title = current.title.ifBlank { tabTitle }
                        )
                    } else if (current != null && current.isPlaying && current.tabId == event.tabId) {
                        // Giữ nguyên session đang phát nếu có một media phụ kích hoạt trong cùng tab
                        current
                    } else {
                        MediaState(
                            tabId = event.tabId,
                            title = tabTitle,
                            artist = "",
                            artwork = null,
                            isPlaying = event.mediaSession.isActive,
                            mediaSession = event.mediaSession
                        )
                    }
                }
                if (_mediaState.value?.isPlaying == true) {
                    requestNotificationPermissionOnceIfNeeded()
                }
                syncMediaNotification()
            }
            is AuraMediaEvent.Deactivated -> {
                var wasCurrent = false
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        wasCurrent = true
                        null
                    } else {
                        current
                    }
                }
                if (wasCurrent) {
                    releaseSessionKeptForMediaIfBackgrounded(event.tabId)
                    MediaPlaybackService.scheduleDismissIn5s(getApplication())
                }
            }
            is AuraMediaEvent.MetadataChanged -> {
                val fallbackTitle = _tabs.value.find { it.id == event.tabId }?.title?.takeIf {
                    it.isNotBlank() && it != "New Tab"
                } ?: ""
                val effectiveTitle = event.title.ifBlank { fallbackTitle }
                var changed = false
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        changed = true
                        current.copy(
                            tabId = event.tabId,
                            title = effectiveTitle.ifBlank { current.title },
                            artist = event.artist,
                            album = event.album,
                            artwork = event.artwork ?: current.artwork,
                            mediaSession = event.mediaSession
                        )
                    } else if (current == null) {
                        changed = true
                        MediaState(
                            tabId = event.tabId,
                            title = effectiveTitle,
                            artist = event.artist,
                            artwork = event.artwork,
                            isPlaying = false,
                            mediaSession = event.mediaSession,
                            album = event.album
                        )
                    } else {
                        current
                    }
                }
                if (changed) {
                    syncMediaNotification()
                }
            }
            is AuraMediaEvent.FeaturesChanged -> {
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        current.copy(features = event.features)
                    } else {
                        current
                    }
                }
            }
            is AuraMediaEvent.PositionStateChanged -> {
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                var updatedState: MediaState? = null
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        val next = current.copy(
                            durationMs = if (event.durationMs > 0L) event.durationMs else current.durationMs,
                            positionMs = event.positionMs,
                            playbackRate = event.playbackRate,
                            positionUpdatedAtElapsedMs = nowElapsed
                        )
                        updatedState = next
                        next
                    } else {
                        current
                    }
                }
                if (updatedState != null) {
                    MediaPlaybackService.updateProgress(
                        durationMs = updatedState!!.durationMs,
                        positionMs = updatedState!!.positionMs,
                        playbackRate = updatedState!!.playbackRate,
                        positionUpdatedAtElapsedMs = nowElapsed
                    )
                }
            }
            is AuraMediaEvent.Play -> {
                userRequestedPause = false
                MediaPlaybackService.cancelScheduledDismiss()
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                val fallbackTitle = _tabs.value.find { it.id == event.tabId }?.title?.takeIf {
                    it.isNotBlank() && it != "New Tab"
                } ?: ""
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        current.copy(
                            tabId = event.tabId,
                            title = current.title.ifBlank { fallbackTitle },
                            isPlaying = true,
                            positionUpdatedAtElapsedMs = nowElapsed
                        )
                    } else {
                        MediaState(
                            tabId = event.tabId,
                            title = fallbackTitle,
                            artist = "",
                            artwork = null,
                            isPlaying = true,
                            mediaSession = event.mediaSession,
                            positionUpdatedAtElapsedMs = nowElapsed
                        )
                    }
                }
                if (!isAppResumed) {
                    keptActiveForMedia = true
                    val mediaTab = _tabs.value.find { it.id == event.tabId }
                    tabHelper.setSessionActive(mediaTab, true)
                    AppLogger.d("AuraBrowser", "keep session active for media: tabId=${event.tabId}")
                }
                requestNotificationPermissionOnceIfNeeded()
                syncMediaNotification()
            }
            is AuraMediaEvent.Pause -> {
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                val pausedRightAfterBackground = !isAppResumed &&
                    !userRequestedPause &&
                    keptActiveForMedia &&
                    sitePolicyStore.backgroundPlayEnabled.value &&
                    (nowElapsed - lastAppPausedAtElapsedMs in 0L..2500L)

                if (pausedRightAfterBackground) {
                    val mediaTab = _tabs.value.find { it.id == event.tabId }
                    tabHelper.setSessionActive(mediaTab, true)
                    try {
                        event.mediaSession.play()
                        AppLogger.d("AuraBrowser", "auto-resumed media paused by background transition: tabId=${event.tabId}")
                        return
                    } catch (_: Exception) {
                    }
                }

                var updated = false
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        updated = true
                        current.copy(
                            isPlaying = false,
                            positionMs = current.currentPositionMs(nowElapsed),
                            positionUpdatedAtElapsedMs = nowElapsed
                        )
                    } else {
                        current
                    }
                }
                if (updated) {
                    releaseSessionKeptForMediaIfBackgrounded(event.tabId)
                    syncMediaNotification()
                }
            }
            is AuraMediaEvent.Stop -> {
                val nowElapsed = android.os.SystemClock.elapsedRealtime()
                var wasCurrent = false
                _mediaState.update { current ->
                    if (current != null && current.mediaSession == event.mediaSession) {
                        wasCurrent = true
                        current.copy(
                            isPlaying = false,
                            positionMs = 0L,
                            positionUpdatedAtElapsedMs = nowElapsed
                        )
                    } else {
                        current
                    }
                }
                if (wasCurrent) {
                    releaseSessionKeptForMediaIfBackgrounded(event.tabId)
                    MediaPlaybackService.scheduleDismissIn5s(getApplication())
                }
            }
        }
    }

    fun mediaPlay() {
        val current = _mediaState.value ?: return
        try {
            userRequestedPause = false
            MediaPlaybackService.cancelScheduledDismiss()
            val mediaTab = _tabs.value.find { it.id == current.tabId }
            if (!isAppResumed) {
                keptActiveForMedia = true
                tabHelper.setSessionActive(mediaTab, true)
                AppLogger.d("AuraBrowser", "keep session active for media: tabId=${current.tabId}")
            }
            current.mediaSession.play()
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            _mediaState.update {
                it?.copy(
                    isPlaying = true,
                    positionUpdatedAtElapsedMs = nowElapsed
                )
            }
            requestNotificationPermissionOnceIfNeeded()
            syncMediaNotification()
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "mediaPlay error: ${e.message}")
        }
    }

    fun mediaPause() {
        val current = _mediaState.value ?: return
        try {
            userRequestedPause = true
            current.mediaSession.pause()
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            _mediaState.update {
                it?.copy(
                    isPlaying = false,
                    positionMs = it.currentPositionMs(nowElapsed),
                    positionUpdatedAtElapsedMs = nowElapsed
                )
            }
            releaseSessionKeptForMediaIfBackgrounded(current.tabId)
            syncMediaNotification()
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "mediaPause error: ${e.message}")
        }
    }

    fun mediaStop() {
        val current = _mediaState.value ?: return
        try {
            userRequestedPause = true
            current.mediaSession.stop()
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            _mediaState.update {
                it?.copy(
                    isPlaying = false,
                    positionMs = 0L,
                    positionUpdatedAtElapsedMs = nowElapsed
                )
            }
            releaseSessionKeptForMediaIfBackgrounded(current.tabId)
            MediaPlaybackService.scheduleDismissIn5s(getApplication())
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "mediaStop error: ${e.message}")
        }
    }

    fun mediaSeekTo(positionMs: Long) {
        val current = _mediaState.value ?: return
        try {
            val targetMs = if (current.durationMs > 0L) {
                positionMs.coerceIn(0L, current.durationMs)
            } else {
                positionMs.coerceAtLeast(0L)
            }
            current.mediaSession.seekTo(targetMs / 1000.0, false)
            val nowElapsed = android.os.SystemClock.elapsedRealtime()
            _mediaState.update {
                it?.copy(
                    positionMs = targetMs,
                    positionUpdatedAtElapsedMs = nowElapsed
                )
            }
            MediaPlaybackService.updateProgress(
                durationMs = current.durationMs,
                positionMs = targetMs,
                playbackRate = current.playbackRate,
                positionUpdatedAtElapsedMs = nowElapsed
            )
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "mediaSeekTo error: ${e.message}")
        }
    }

    fun setPagePrompt(prompt: PagePrompt?) {
        _pagePrompt.value?.dismiss()
        _pagePrompt.value = prompt
    }

    fun clearPagePrompt(prompt: PagePrompt? = null) {
        if (prompt == null || _pagePrompt.value == prompt) {
            _pagePrompt.value = null
        }
    }

    fun setPermissionPrompt(prompt: PermissionPrompt?) {
        _permissionPrompt.value?.dismiss()
        _permissionPrompt.value = prompt
    }

    fun clearPermissionPrompt() {
        _permissionPrompt.value = null
    }

    fun dismissContextMenu() {
        _contextMenuState.value = null
    }

    fun setFullscreen(fullscreen: Boolean) {
        _isFullscreen.value = fullscreen
    }

    fun exitFullscreen() {
        if (_isFullscreen.value) {
            activeTab?.session?.exitFullScreen()
            _isFullscreen.value = false
        }
    }

    fun openLinkInNewTab(url: String) {
        val host = SitePolicyStore.normalizeHost(url)
        if (host.isNotBlank() && sitePolicyStore.isHostBlocked(host)) {
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn $host",
                actionLabel = "Bỏ chặn",
                onAction = { unblockHost(host) }
            )
            return
        }
        createNewTab(initialUrl = url, switchToIt = false)
        val createdTab = _tabs.value.lastOrNull()
        if (createdTab != null) {
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã mở tab mới",
                actionLabel = "Chuyển",
                onAction = { selectTab(createdTab.id) }
            )
        }
    }

    /**
     * Mở link / từ khoá đến từ app khác (intent VIEW, WEB_SEARCH, SEND) trong một tab mới
     * và chuyển sang tab đó. Dùng chung quy tắc với thanh địa chỉ: URL thì mở thẳng,
     * còn lại tìm bằng máy tìm kiếm đang chọn.
     */
    fun openExternalInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return
        val url = normalizeInput(trimmed)

        val host = SitePolicyStore.normalizeHost(url)
        if (host.isNotBlank() && sitePolicyStore.isHostBlocked(host)) {
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn $host",
                actionLabel = "Bỏ chặn",
                onAction = { unblockHost(host) }
            )
            return
        }

        if (url.startsWith(_searchEngine.value.searchUrl)) {
            searchHistoryStore.add(trimmed)
        }
        createNewTab(initialUrl = url, switchToIt = true)
    }

    /**
     * Dịch trang hiện tại sang tiếng Việt qua Google Translate; nếu trang đang là bản dịch
     * thì quay về trang gốc.
     */
    fun translateCurrentPage() {
        val tab = activeTab ?: return
        val currentUrl = tab.url
        if (currentUrl.isBlank() || tab.isStartPage) return

        if (PageTranslation.isTranslatedUrl(currentUrl)) {
            val original = PageTranslation.toOriginalUrl(currentUrl)
            if (original != null) {
                submitOmnibox(original)
            } else {
                _snackbarEvent.value = SnackbarEvent(message = "Không thể quay lại trang gốc")
            }
            return
        }

        val translated = PageTranslation.toTranslatedUrl(currentUrl)
        if (translated == null) {
            _snackbarEvent.value = SnackbarEvent(message = "Không thể dịch trang này")
            return
        }
        _snackbarEvent.value = SnackbarEvent(message = "Đang dịch sang tiếng Việt...")
        submitOmnibox(translated)
    }

    fun openLinkInCurrentTab(url: String) {
        activeTab?.let {
            submitOmnibox(url)
        }
    }

    fun copyToClipboard(text: String, label: String = "Link") {
        val clipboard = getApplication<Application>().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        _snackbarEvent.value = SnackbarEvent(message = "Đã sao chép $label")
    }

    fun shareLink(url: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, url)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Chia sẻ liên kết").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(chooser)
        } catch (_: Exception) {}
    }

    fun blockSite(url: String) {
        val host = SitePolicyStore.normalizeHost(url)
        if (host.isNotBlank()) {
            sitePolicyStore.addBlockedHost(host)
            GeckoEngine.notifyBlockedHostsChanged()
            closeTabsForBlockedHost(host)
            reloadActiveTabIfSearchPage()
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn và ẩn $host",
                actionLabel = "Bỏ chặn",
                onAction = { unblockHost(host) }
            )
        }
    }

    fun saveImage(url: String) {
        DownloadHelper.downloadUrl(
            context = getApplication(),
            url = url
        ) { result ->
            when (result) {
                is DownloadResult.Progress -> _snackbarEvent.value = SnackbarEvent(message = result.message)
                is DownloadResult.Success -> {
                    loadDownloadedFiles()
                    if (result.uri != null) {
                        _snackbarEvent.value = SnackbarEvent(
                            message = result.message,
                            actionLabel = "Mở",
                            onAction = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(result.uri, result.mimeType ?: "*/*")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    getApplication<Application>().startActivity(intent)
                                } catch (_: Exception) {}
                            }
                        )
                    } else {
                        _snackbarEvent.value = SnackbarEvent(message = result.message)
                    }
                }
                is DownloadResult.Error -> _snackbarEvent.value = SnackbarEvent(message = result.message)
            }
        }
    }

    private fun handleDownload(response: WebResponse) {
        DownloadHelper.start(
            context = getApplication(),
            response = response
        ) { result ->
            when (result) {
                is DownloadResult.Progress -> {
                    _snackbarEvent.value = SnackbarEvent(message = result.message)
                }
                is DownloadResult.Success -> {
                    loadDownloadedFiles()
                    if (result.uri != null) {
                        _snackbarEvent.value = SnackbarEvent(
                            message = result.message,
                            actionLabel = "Mở",
                            onAction = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(result.uri, result.mimeType ?: "*/*")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    getApplication<Application>().startActivity(intent)
                                } catch (_: Exception) {
                                    _snackbarEvent.value = SnackbarEvent(message = "Không có ứng dụng để mở file này")
                                }
                            }
                        )
                    } else {
                        _snackbarEvent.value = SnackbarEvent(message = result.message)
                    }
                }
                is DownloadResult.Error -> {
                    _snackbarEvent.value = SnackbarEvent(message = result.message)
                }
            }
        }
    }

    private val _tabs = MutableStateFlow<List<BrowserTab>>(emptyList())
    val tabs: StateFlow<List<BrowserTab>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow("")
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _showTabSwitcher = MutableStateFlow(false)
    val showTabSwitcher: StateFlow<Boolean> = _showTabSwitcher.asStateFlow()

    private val _showBookmarksDialog = MutableStateFlow(false)
    val showBookmarksDialog: StateFlow<Boolean> = _showBookmarksDialog.asStateFlow()

    private val _showHistoryDialog = MutableStateFlow(false)
    val showHistoryDialog: StateFlow<Boolean> = _showHistoryDialog.asStateFlow()

    private val _showDownloadsScreen = MutableStateFlow(false)
    val showDownloadsScreen: StateFlow<Boolean> = _showDownloadsScreen.asStateFlow()

    private val _downloadedFiles = MutableStateFlow<List<DownloadedFileItem>>(emptyList())
    val downloadedFiles: StateFlow<List<DownloadedFileItem>> = _downloadedFiles.asStateFlow()

    private val _showOverflowMenu = MutableStateFlow(false)
    val showOverflowMenu: StateFlow<Boolean> = _showOverflowMenu.asStateFlow()

    private val _showAboutDialog = MutableStateFlow(false)
    val showAboutDialog: StateFlow<Boolean> = _showAboutDialog.asStateFlow()

    private val _showDiagnosticsDialog = MutableStateFlow(false)
    val showDiagnosticsDialog: StateFlow<Boolean> = _showDiagnosticsDialog.asStateFlow()

    private val _showClearBrowsingDataDialog = MutableStateFlow(false)
    val showClearBrowsingDataDialog: StateFlow<Boolean> = _showClearBrowsingDataDialog.asStateFlow()

    fun setShowClearBrowsingDataDialog(show: Boolean) {
        _showClearBrowsingDataDialog.value = show
    }

    val activeTabIsPrivate: StateFlow<Boolean> = _tabs.combine(_activeTabId) { tabList, activeId ->
        tabList.find { it.id == activeId }?.isPrivate == true
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    fun clearBrowsingData(
        clearHistory: Boolean,
        clearCookies: Boolean,
        clearCache: Boolean,
        clearProtectionStats: Boolean,
        clearSitePermissions: Boolean
    ) {
        setShowClearBrowsingDataDialog(false)
        viewModelScope.launch {
            try {
                if (clearHistory) {
                    repository.clearHistory()
                    searchHistoryStore.clear()
                }

                if (clearProtectionStats) {
                    protectionStatsStore.resetTotals()
                }

                if (clearSitePermissions) {
                    sitePermissionStore.clearAll()
                }

                var clearFlags = 0L
                if (clearCookies) {
                    clearFlags = clearFlags or org.mozilla.geckoview.StorageController.ClearFlags.COOKIES or org.mozilla.geckoview.StorageController.ClearFlags.SITE_DATA
                }
                if (clearCache) {
                    clearFlags = clearFlags or org.mozilla.geckoview.StorageController.ClearFlags.ALL_CACHES
                }

                if (clearFlags != 0L) {
                    val runtime = GeckoEngine.getRuntime(getApplication())
                    val success = kotlinx.coroutines.suspendCancellableCoroutine<Boolean> { cont ->
                        runtime.storageController.clearData(clearFlags).then(
                            {
                                if (cont.isActive) cont.resume(true) { _, _, _ -> }
                                org.mozilla.geckoview.GeckoResult.fromValue(null)
                            },
                            { error ->
                                AppLogger.d("BrowserViewModel", "Lỗi clearData: $error")
                                if (cont.isActive) cont.resume(false) { _, _, _ -> }
                                org.mozilla.geckoview.GeckoResult.fromValue(null)
                            }
                        )
                    }
                    if (!success) {
                        _snackbarEvent.value = SnackbarEvent(message = "Xoá thất bại")
                        return@launch
                    }
                }

                _snackbarEvent.value = SnackbarEvent(message = "Đã xoá dữ liệu duyệt web")
                if (clearCookies) {
                    reloadActiveTab()
                }
            } catch (e: Exception) {
                AppLogger.d("BrowserViewModel", "Lỗi xoá dữ liệu duyệt web: ${e.message}")
                _snackbarEvent.value = SnackbarEvent(message = "Xoá thất bại")
            }
        }
    }

    private val _diagnosticsLogs = MutableStateFlow<List<String>>(emptyList())
    val diagnosticsLogs: StateFlow<List<String>> = _diagnosticsLogs.asStateFlow()

    private val _omniboxInput = MutableStateFlow("")
    val omniboxInput: StateFlow<String> = _omniboxInput.asStateFlow()

    private val _isEditingOmnibox = MutableStateFlow(false)
    val isEditingOmnibox: StateFlow<Boolean> = _isEditingOmnibox.asStateFlow()

    private val _showFindInPage = MutableStateFlow(false)
    val showFindInPage: StateFlow<Boolean> = _showFindInPage.asStateFlow()

    private val _findQuery = MutableStateFlow("")
    val findQuery: StateFlow<String> = _findQuery.asStateFlow()

    private val _searchEngine = MutableStateFlow(SearchEngine.GOOGLE)
    val searchEngine: StateFlow<SearchEngine> = _searchEngine.asStateFlow()

    // Flows for history and bookmarks (filtered by blockedHosts at display layer without deleting from DB)
    val bookmarksFlow: Flow<List<BookmarkEntity>> = combine(
        repository.allBookmarks,
        blockedHosts
    ) { bookmarks, blockedSet ->
        bookmarks.filterNot { isUrlHostBlocked(it.url, blockedSet) }
    }

    val historyFlow: Flow<List<HistoryEntity>> = combine(
        repository.allHistory,
        blockedHosts
    ) { historyList, blockedSet ->
        historyList.filterNot { isUrlHostBlocked(it.url, blockedSet) }
    }

    // Derive bookmarked state from active tab's URL with distinctUntilChanged to minimize recomposition
    private val activeTabUrl: Flow<String> = _tabs.map { currentTabs ->
        currentTabs.find { it.id == _activeTabId.value }?.url ?: ""
    }.distinctUntilChanged()

    val isCurrentPageBookmarked: StateFlow<Boolean> = combine(
        activeTabUrl,
        repository.allBookmarks
    ) { currentUrl, bookmarkList ->
        val active = activeTab
        if (currentUrl.isBlank() || active?.isStartPage == true || currentUrl.startsWith("about:")) {
            false
        } else {
            bookmarkList.any { it.url == currentUrl }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val tabHelper: GeckoTabHelper = GeckoTabHelper(
        context = application,
        sitePermissionStore = sitePermissionStore,
        sitePolicyStore = sitePolicyStore,
        onTabUpdate = { tabId, updater ->
            _tabs.update { currentList ->
                var changed = false
                val mapped = currentList.map { tab ->
                    if (tab.id == tabId) {
                        val updated = updater(tab)
                        if (updated != tab) changed = true
                        updated
                    } else {
                        tab
                    }
                }
                if (changed) mapped else currentList
            }
        },
        onPageVisited = { title, url ->
            viewModelScope.launch {
                repository.addHistory(title, url)
            }
        },
        isHostBlocked = { host ->
            sitePolicyStore.isHostBlocked(host)
        },
        onBlockedUrl = { host ->
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn $host",
                actionLabel = "Bỏ chặn",
                onAction = { unblockHost(host) }
            )
        },
        isPopupAllowed = { host ->
            sitePolicyStore.isPopupAllowed(host)
        },
        onBlockedPopup = { host ->
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn popup từ $host",
                actionLabel = "Cho phép",
                onAction = { allowPopupForHost(host) }
            )
        },
        onPopupTabCreated = { popupTab ->
            try {
                val popupSession = popupTab.session
                if (popupSession != null && popupSession.isOpen) {
                    val previousTab = activeTab
                    if (previousTab != null) {
                        tabHelper.setSessionActive(previousTab, false)
                    }
                    val nonStartTab = popupTab.copy(
                        isStartPage = false,
                        lastAccessedAt = System.currentTimeMillis()
                    )
                    _tabs.update { it + nonStartTab }
                    _activeTabId.value = nonStartTab.id
                    _showTabSwitcher.value = false
                    _omniboxInput.value = nonStartTab.url
                    tabHelper.setSessionActive(nonStartTab, true)
                    enforceMaxLiveSessions(nonStartTab.id)
                } else {
                    AppLogger.d("AuraBrowser", "popup failed: tabId=${popupTab.id} (session not open in onPopupTabCreated)")
                }
            } catch (e: Exception) {
                AppLogger.d("AuraBrowser", "popup failed: tabId=${popupTab.id} (${e.message})")
            }
        },
        getCurrentTab = { tabId ->
            _tabs.value.find { it.id == tabId }
        },
        isActiveTab = { tabId ->
            _activeTabId.value == tabId
        },
        onTrackerBlocked = { tabId ->
            protectionStatsStore.recordTrackerBlocked(tabId)
        },
        onPopupBlocked = { tabId ->
            protectionStatsStore.recordPopupBlocked(tabId)
        },
        onPageResetStats = { tabId ->
            protectionStatsStore.onPageStart(tabId)
        },
        onDownload = { response ->
            handleDownload(response)
        },
        onShowPrompt = { prompt ->
            setPagePrompt(prompt)
        },
        onClearPrompt = {
            clearPagePrompt()
        },
        onShowPermissionPrompt = { prompt ->
            setPermissionPrompt(prompt)
        },
        onClearPermissionPrompt = {
            clearPermissionPrompt()
        },
        onContextMenuRequested = { tabId, linkUri, srcUri, type ->
            _contextMenuState.value = ContextMenuState(tabId, linkUri, srcUri, type)
        },
        onExternalAppOpened = {
            _snackbarEvent.value = SnackbarEvent(message = "Đang mở ứng dụng khác")
        },
        onFullScreenChange = { tabId, fullScreen ->
            _isFullscreen.value = fullScreen
        },
        onSessionLost = { tabId ->
            onSessionLost(tabId)
        },
        onMediaEvent = { event ->
            handleMediaEvent(event)
        },
        onPageStartNavigation = { tabId, newUrl ->
            handlePageStartNavigation(tabId, newUrl)
        },
        onTabLocationChanged = { tabId, newUrl ->
            handleTabLocationChanged(tabId, newUrl)
        }
    )

    init {
        MediaController.onPlay = { mediaPlay() }
        MediaController.onPause = { mediaPause() }
        MediaController.onStop = { mediaStop() }
        MediaController.onSeekTo = { posMs -> mediaSeekTo(posMs) }
        MediaController.onSelectTab = { tabId -> selectTab(tabId) }

        GeckoEngine.actionDelegateCallback = { session, badgeText ->
            val tab = _tabs.value.find { it.session == session }
            if (tab != null) {
                protectionStatsStore.recordAdsBadge(tab.id, badgeText)
            }
        }

        GeckoEngine.onSaveImageRequestedCallback = { url -> saveImage(url) }
        GeckoEngine.onHttpStatusCallback = { tabId, status, url ->
            // Chỉ báo cho tab đang xem, và không báo lặp cùng một trang trong 5 giây
            val isActive = tabId == null || tabId == activeTab?.id
            val key = "$status|$url"
            val now = System.currentTimeMillis()
            if (isActive && HttpStatusMessages.isError(status) &&
                !(key == lastHttpStatusKey && now - lastHttpStatusAt < 5000L)
            ) {
                lastHttpStatusKey = key
                lastHttpStatusAt = now
                _snackbarEvent.value = SnackbarEvent(
                    message = HttpStatusMessages.snackbarText(status)
                )
            }
        }
        GeckoEngine.onOverlayRemovedCallback = { _ ->
            protectionStatsStore.recordOverlayRemoved(activeTab?.id)
            val now = System.currentTimeMillis()
            if (now - lastOverlaySnackbarAt >= 5000L) {
                lastOverlaySnackbarAt = now
                _snackbarEvent.value = SnackbarEvent(
                    message = "Đã xoá lớp quảng cáo",
                    actionLabel = "Hoàn tác",
                    onAction = {
                        sitePolicyStore.setCleanOverlayEnabled(false)
                        GeckoEngine.setCleanOverlayEnabled(false) {
                            reloadActiveTab()
                        }
                    }
                )
            }
        }

        GeckoEngine.getBlockedHostsCallback = {
            sitePolicyStore.blockedHosts.value
        }

        GeckoEngine.onSaviorMediaDetectedCallback = { payload ->
            handleSaviorMediaDetected(payload)
        }

        DownloadService.onDownloadCompleted = { completed ->
            showCompletedDownloadSnackbar(completed.fileName, completed.uri, completed.mimeType)
            loadDownloadedFiles()
        }

        DownloadService.onDownloadError = { errMsg ->
            _snackbarEvent.value = SnackbarEvent(message = errMsg)
        }

        DownloadService.onAudioExtractionFailed = { _, fallback ->
            _audioFallbackPrompt.value?.let { prev ->
                if (prev != fallback) {
                    MediaDownloader.discardFallbackTempVideo(prev)
                }
            }
            _audioFallbackPrompt.value = fallback
        }

        // Initialize GeckoEngine with saved preferences (cookies, uBlock Origin, Clean Overlay, Background Play, Savior)
        GeckoEngine.getRuntime(
            context = application,
            blockThirdPartyCookies = sitePolicyStore.blockCookies.value,
            ublockEnabled = sitePolicyStore.ublockEnabled.value,
            cleanOverlayEnabled = sitePolicyStore.cleanOverlayEnabled.value,
            backgroundPlayEnabled = sitePolicyStore.backgroundPlayEnabled.value,
            saviorEnabled = sitePolicyStore.saviorEnabled.value,
            onUblockInstallError = { errMsg ->
                _snackbarEvent.value = SnackbarEvent(message = errMsg)
            }
        )
        if (sitePolicyStore.devtoolsEnabled.value) {
            GeckoEngine.setDevtoolsEnabled(true)
        }

        // Khôi phục máy tìm kiếm đã chọn
        tabSessionStore.loadSearchEngine()?.let { savedName ->
            SearchEngine.values().find { it.name == savedName }?.let {
                _searchEngine.value = it
            }
        }

        // Khôi phục các tab đã lưu (lazy session) hoặc tạo tab đầu tiên nếu chưa có
        restoreTabsOrCreate()

        // Tự động lưu phiên tab khi có thay đổi (debounce 500ms)
        viewModelScope.launch {
            combine(_tabs, _activeTabId) { tabs, activeId ->
                tabs to activeId
            }
            .debounce(500)
            .collect { (currentTabs, currentActiveId) ->
                if (currentTabs.isNotEmpty()) {
                    saveTabsNow(currentTabs, currentActiveId)
                }
            }
        }
    }

    private fun restoreTabsOrCreate() {
        val saved = tabSessionStore.load()
        if (saved == null || saved.tabs.isEmpty()) {
            createNewTab()
            return
        }
        val validTabs = saved.tabs.filterNot { s ->
            !s.isStartPage && s.url.isNotBlank() && sitePolicyStore.isHostBlocked(s.url)
        }
        if (validTabs.isEmpty()) {
            createNewTab()
            return
        }
        val restored = validTabs.map { s ->
            BrowserTab(
                id = s.id,
                title = s.title,
                url = s.url,
                isStartPage = s.isStartPage || s.url.isBlank(),
                isDesktopMode = s.isDesktopMode,
                session = null,
                lastAccessedAt = System.currentTimeMillis()
            )
        }
        _tabs.value = restored
        val activeId = restored.firstOrNull { it.id == saved.activeTabId }?.id ?: restored.last().id
        selectTab(activeId)
    }

    fun saveTabsNow(
        tabsToSave: List<BrowserTab> = _tabs.value,
        activeId: String? = _activeTabId.value
    ) {
        // Tab ẩn danh KHÔNG lưu vào bất kỳ nơi lưu tab nào
        val nonPrivateTabs = tabsToSave.filter { !it.isPrivate }
        if (nonPrivateTabs.isEmpty()) return
        val snap = nonPrivateTabs.map { t ->
            SavedTabInfo(
                id = t.id,
                title = t.title,
                url = t.url,
                isStartPage = t.isStartPage,
                isDesktopMode = t.isDesktopMode
            )
        }
        val safeActiveId = if (nonPrivateTabs.any { it.id == activeId }) activeId else nonPrivateTabs.firstOrNull()?.id
        viewModelScope.launch(Dispatchers.IO) {
            tabSessionStore.save(snap, safeActiveId)
        }
    }

    val activeTab: BrowserTab?
        get() = _tabs.value.find { it.id == _activeTabId.value } ?: _tabs.value.firstOrNull()

    // Enforce maximum of 4 live GeckoSessions at the same time
    private fun enforceMaxLiveSessions(currentActiveId: String) {
        _tabs.update { currentTabs ->
            val liveTabs = currentTabs.filter { it.session != null }
            if (liveTabs.size <= 4) {
                currentTabs
            } else {
                // Find inactive live tabs sorted by lastAccessedAt ascending (oldest first)
                // Do not discard the tab currently playing media
                val mediaPlayingTabId = _mediaState.value?.takeIf { it.isPlaying }?.tabId
                val candidatesToDiscard = liveTabs
                    .filter { it.id != currentActiveId && it.id != mediaPlayingTabId }
                    .sortedBy { it.lastAccessedAt }
                val discardCount = liveTabs.size - 4
                val toDiscardIds = candidatesToDiscard.take(discardCount).map { it.id }.toSet()
                if (_mediaState.value?.tabId in toDiscardIds) {
                    _mediaState.value = null
                    MediaPlaybackService.scheduleDismissIn5s(getApplication())
                }

                currentTabs.map { tab ->
                    if (toDiscardIds.contains(tab.id)) {
                        try {
                            tab.session?.close()
                        } catch (_: Exception) {
                        }
                        tab.copy(session = null)
                    } else {
                        tab
                    }
                }
            }
        }
    }

    fun createNewTab(
        initialUrl: String? = null,
        switchToIt: Boolean = true,
        isPrivate: Boolean = false
    ): BrowserTab {
        val previousTab = activeTab
        val newTab = tabHelper.createSession(initialUrl, isPrivate = isPrivate)
        _tabs.update { it + newTab }

        if (switchToIt) {
            dismissYtDialog()
            if (previousTab != null) {
                tabHelper.setSessionActive(previousTab, false)
            }
            _activeTabId.value = newTab.id
            _showTabSwitcher.value = false
            _omniboxInput.value = initialUrl ?: ""
            tabHelper.setSessionActive(newTab, true)
            enforceMaxLiveSessions(newTab.id)
        } else {
            tabHelper.setSessionActive(newTab, false)
            enforceMaxLiveSessions(_activeTabId.value)
        }
        return newTab
    }

    fun closeAllPrivateTabs() {
        val privateTabs = _tabs.value.filter { it.isPrivate }
        if (privateTabs.isEmpty()) return
        val privateIds = privateTabs.map { it.id }.toSet()
        if (_mediaState.value?.tabId in privateIds) {
            _mediaState.value = null
            MediaPlaybackService.scheduleDismissIn5s(getApplication())
        }
        privateTabs.forEach { tabHelper.closeTab(it) }
        _detectedMediaByTab.update { map -> map.filterKeys { it !in privateIds } }
        privateIds.forEach { lastPageHostPathByTab.remove(it) }
        val remaining = _tabs.value.filter { !it.isPrivate }
        if (remaining.isEmpty()) {
            _tabs.value = emptyList()
            createNewTab()
        } else {
            _tabs.value = remaining
            if (!remaining.any { it.id == _activeTabId.value }) {
                selectTab(remaining.last().id)
            }
        }
        _snackbarEvent.value = SnackbarEvent(message = "Đã đóng tất cả tab ẩn danh")
    }

    fun selectTab(tabId: String) {
        exitFullscreen()
        val previousTab = activeTab
        if (previousTab?.id != tabId) {
            dismissYtDialog()
            tabHelper.setSessionActive(previousTab, false)
        }

        var targetTab = _tabs.value.find { it.id == tabId } ?: return
        if (targetTab.session == null) {
            // Restore discarded session using saved sessionState
            val newSession = tabHelper.restoreSession(targetTab)
            targetTab = targetTab.copy(session = newSession, lastAccessedAt = System.currentTimeMillis())
            _tabs.update { list ->
                list.map { if (it.id == tabId) targetTab else it }
            }
        } else {
            _tabs.update { list ->
                list.map { if (it.id == tabId) it.copy(lastAccessedAt = System.currentTimeMillis()) else it }
            }
        }

        _activeTabId.value = tabId
        _showTabSwitcher.value = false
        tabHelper.setSessionActive(targetTab, true)
        _omniboxInput.value = if (targetTab.isStartPage) "" else targetTab.url

        enforceMaxLiveSessions(tabId)
    }

    fun closeTab(tabId: String) {
        if (_activeTabId.value == tabId) {
            dismissYtDialog()
        }
        if (_pagePrompt.value?.tabId == tabId) {
            _pagePrompt.value?.dismiss()
            _pagePrompt.value = null
        }
        if (_permissionPrompt.value?.tabId == tabId) {
            _permissionPrompt.value?.dismiss()
            _permissionPrompt.value = null
        }
        if (_contextMenuState.value?.tabId == tabId) {
            _contextMenuState.value = null
        }
        if (_mediaState.value?.tabId == tabId) {
            _mediaState.value = null
            releaseSessionKeptForMediaIfBackgrounded(tabId)
            MediaPlaybackService.scheduleDismissIn5s(getApplication())
        }
        exitFullscreen()

        val currentList = _tabs.value
        val closedIndex = currentList.indexOfFirst { it.id == tabId }
        if (closedIndex == -1) return
        val tabToClose = currentList[closedIndex]
        tabHelper.closeTab(tabToClose)
        protectionStatsStore.onTabClosed(tabId)
        _detectedMediaByTab.update { it - tabId }
        lastPageHostPathByTab.remove(tabId)

        val updatedList = currentList.filter { it.id != tabId }
        if (updatedList.isEmpty()) {
            _tabs.value = emptyList()
            createNewTab()
        } else {
            _tabs.value = updatedList
            if (_activeTabId.value == tabId) {
                val neighborIndex = closedIndex.coerceAtMost(updatedList.lastIndex)
                val newActive = updatedList[neighborIndex]
                selectTab(newActive.id)
            }
        }
    }

    fun closeAllTabs() {
        dismissYtDialog()
        _pagePrompt.value?.dismiss()
        _pagePrompt.value = null
        _permissionPrompt.value?.dismiss()
        _permissionPrompt.value = null
        _contextMenuState.value = null
        if (_mediaState.value != null) {
            _mediaState.value = null
            MediaPlaybackService.scheduleDismissIn5s(getApplication())
        }
        exitFullscreen()

        _tabs.value.forEach { tabHelper.closeTab(it) }
        _detectedMediaByTab.value = emptyMap()
        lastPageHostPathByTab.clear()
        _tabs.value = emptyList()
        createNewTab()
        _showTabSwitcher.value = false
    }

    fun submitOmnibox(input: String) {
        val trimmed = input.trim()
        if (trimmed.isBlank()) return
        val url = normalizeInput(trimmed)

        val host = SitePolicyStore.normalizeHost(url)
        if (sitePolicyStore.isHostBlocked(host) || sitePolicyStore.isHostBlocked(trimmed)) {
            val blockedHost = if (sitePolicyStore.isHostBlocked(host)) host else SitePolicyStore.normalizeHost(trimmed)
            _isEditingOmnibox.value = false
            _omniboxInput.value = if (activeTab?.isStartPage == true) "" else (activeTab?.url ?: "")
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã chặn $blockedHost",
                actionLabel = "Bỏ chặn",
                onAction = { unblockHost(blockedHost) }
            )
            return
        }

        // Nếu rơi vào nhánh tìm kiếm (không phải URL trực tiếp), lưu từ khoá vào lịch sử (chỉ khi không phải tab ẩn danh)
        if (url.startsWith(_searchEngine.value.searchUrl)) {
            val currentTab = activeTab
            if (currentTab?.isPrivate != true) {
                searchHistoryStore.add(trimmed)
            }
        }

        var tab = activeTab ?: return
        if (tab.session == null) {
            val newSession = tabHelper.restoreSession(tab)
            tab = tab.copy(session = newSession)
        }

        // Set isStartPage = false and update url optimistically
        _tabs.update { currentTabs ->
            currentTabs.map {
                if (it.id == tab.id) it.copy(
                    session = tab.session,
                    url = url,
                    isLoading = true,
                    progress = 15,
                    isStartPage = false,
                    lastAccessedAt = System.currentTimeMillis()
                ) else it
            }
        }

        AppLogger.d("AuraBrowser", "submitOmnibox: input=$input, url=$url")
        tabHelper.setSessionActive(tab, true)
        tabHelper.loadUri(tab, url)
        _omniboxInput.value = url
        _isEditingOmnibox.value = false
        enforceMaxLiveSessions(tab.id)

        val targetTabId = tab.id
        viewModelScope.launch {
            kotlinx.coroutines.delay(250)
            if (_activeTabId.value == targetTabId) {
                val currentTab = activeTab
                if (currentTab != null && currentTab.id == targetTabId) {
                    tabHelper.setSessionActive(currentTab, true)
                    AppLogger.d("AuraBrowser", "submitOmnibox: delayed 250ms setSessionActive(true) on tab $targetTabId")
                }
            }
        }
    }

    fun reloadActiveTab() {
        activeTab?.let { tabHelper.reload(it) }
    }

    fun stopActiveTab() {
        activeTab?.let { tabHelper.stop(it) }
    }

    fun goBackActiveTab(): Boolean {
        val tab = activeTab ?: return false
        return tabHelper.goBack(tab)
    }

    fun goForwardActiveTab(): Boolean {
        val tab = activeTab ?: return false
        return tabHelper.goForward(tab)
    }

    fun toggleDesktopMode() {
        val tab = activeTab ?: return
        val newMode = tabHelper.toggleDesktopMode(tab)
        _tabs.update { currentTabs ->
            currentTabs.map {
                if (it.id == tab.id) it.copy(isDesktopMode = newMode) else it
            }
        }
    }

    fun toggleBookmark() {
        val tab = activeTab ?: return
        val currentUrl = tab.url
        if (currentUrl.isBlank() || tab.isStartPage || currentUrl.startsWith("about:")) return

        viewModelScope.launch {
            val isBookmarked = isCurrentPageBookmarked.value
            if (isBookmarked) {
                repository.removeBookmarkByUrl(currentUrl)
            } else {
                repository.addBookmark(tab.title, currentUrl)
            }
        }
    }

    fun deleteBookmark(id: Long) {
        viewModelScope.launch {
            repository.removeBookmarkById(id)
        }
    }

    fun openBookmark(bookmark: BookmarkEntity) {
        _showBookmarksDialog.value = false
        var tab = activeTab
        if (tab != null) {
            if (tab.session == null) {
                val newSession = tabHelper.restoreSession(tab)
                tab = tab.copy(session = newSession)
            }
            _tabs.update { currentTabs ->
                currentTabs.map {
                    if (it.id == tab.id) it.copy(
                        session = tab.session,
                        url = bookmark.url,
                        isLoading = true,
                        progress = 15,
                        isStartPage = false,
                        lastAccessedAt = System.currentTimeMillis()
                    ) else it
                }
            }
            tabHelper.setSessionActive(tab, true)
            tabHelper.loadUri(tab, bookmark.url)
            _omniboxInput.value = bookmark.url
            enforceMaxLiveSessions(tab.id)
        } else {
            createNewTab(bookmark.url)
        }
    }

    fun deleteHistory(id: Long) {
        viewModelScope.launch {
            repository.deleteHistoryById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun openHistory(history: HistoryEntity) {
        _showHistoryDialog.value = false
        var tab = activeTab
        if (tab != null) {
            if (tab.session == null) {
                val newSession = tabHelper.restoreSession(tab)
                tab = tab.copy(session = newSession)
            }
            _tabs.update { currentTabs ->
                currentTabs.map {
                    if (it.id == tab.id) it.copy(
                        session = tab.session,
                        url = history.url,
                        isLoading = true,
                        progress = 15,
                        isStartPage = false,
                        lastAccessedAt = System.currentTimeMillis()
                    ) else it
                }
            }
            tabHelper.setSessionActive(tab, true)
            tabHelper.loadUri(tab, history.url)
            _omniboxInput.value = history.url
            enforceMaxLiveSessions(tab.id)
        } else {
            createNewTab(history.url)
        }
    }

    // Policy Actions
    private fun closeTabsForBlockedHost(blockedHost: String) {
        val normalizedBlocked = SitePolicyStore.normalizeHost(blockedHost)
        if (normalizedBlocked.isBlank()) return
        val currentActiveId = _activeTabId.value
        val matchingTabs = _tabs.value.filter { tab ->
            val tabHost = SitePolicyStore.normalizeHost(tab.url)
            tabHost.isNotBlank() && (
                tabHost == normalizedBlocked ||
                tabHost.endsWith(".$normalizedBlocked") ||
                sitePolicyStore.isHostBlocked(tabHost)
            )
        }
        val inactiveMatching = matchingTabs.filter { it.id != currentActiveId }
        val activeMatching = matchingTabs.filter { it.id == currentActiveId }
        (inactiveMatching + activeMatching).forEach { tab ->
            closeTab(tab.id)
        }
    }

    private fun isSearchEngineResultsUrl(url: String): Boolean {
        if (url.isBlank()) return false
        val host = SitePolicyStore.normalizeHost(url)
        val isSearchHost = host == "google.com" ||
                host == "google.com.vn" ||
                host.endsWith(".google.com") ||
                host.endsWith(".google.com.vn") ||
                host == "bing.com" ||
                host.endsWith(".bing.com") ||
                host == "duckduckgo.com" ||
                host.endsWith(".duckduckgo.com") ||
                host == "search.brave.com"
        if (!isSearchHost) return false
        val lower = url.lowercase()
        return lower.contains("/search") || lower.contains("?q=") || lower.contains("&q=")
    }

    private fun reloadActiveTabIfSearchPage() {
        val current = activeTab ?: return
        if (!current.isStartPage && isSearchEngineResultsUrl(current.url)) {
            reloadActiveTab()
        }
    }

    fun blockCurrentSite() {
        val tab = activeTab ?: return
        val currentUrl = tab.url
        if (currentUrl.isBlank() || tab.isStartPage || currentUrl.startsWith("about:") || currentUrl.startsWith("chrome:")) return

        val host = SitePolicyStore.normalizeHost(currentUrl)
        if (host.isBlank()) return
        sitePolicyStore.addBlockedHost(host)
        GeckoEngine.notifyBlockedHostsChanged()
        closeTabsForBlockedHost(host)
        reloadActiveTabIfSearchPage()

        _snackbarEvent.value = SnackbarEvent(
            message = "Đã chặn và ẩn $host",
            actionLabel = "Bỏ chặn",
            onAction = { unblockHost(host) }
        )
    }

    fun unblockHost(host: String) {
        sitePolicyStore.removeBlockedHost(host)
        GeckoEngine.notifyBlockedHostsChanged()
        reloadActiveTabIfSearchPage()
    }

    fun allowPopupForHost(host: String) {
        sitePolicyStore.addPopupAllowedHost(host)
    }

    fun removePopupAllowedHost(host: String) {
        sitePolicyStore.removePopupAllowedHost(host)
    }

    fun togglePopupForCurrentSite() {
        val tab = activeTab ?: return
        val host = SitePolicyStore.normalizeHost(tab.url)
        if (host.isBlank()) return

        if (sitePolicyStore.isPopupAllowed(host)) {
            sitePolicyStore.removePopupAllowedHost(host)
        } else {
            sitePolicyStore.addPopupAllowedHost(host)
        }
    }

    fun isCurrentSitePopupAllowed(): Boolean {
        val tab = activeTab ?: return false
        val host = SitePolicyStore.normalizeHost(tab.url)
        return sitePolicyStore.isPopupAllowed(host)
    }

    fun toggleBlockCookies() {
        val newValue = !sitePolicyStore.blockCookies.value
        sitePolicyStore.setBlockCookies(newValue)
        GeckoEngine.setCookieBehavior(newValue)
        reloadActiveTab()
    }

    fun toggleUblock() {
        val newValue = !sitePolicyStore.ublockEnabled.value
        sitePolicyStore.setUblockEnabled(newValue)
        GeckoEngine.setUblockEnabled(newValue) {
            reloadActiveTab()
        }
    }

    fun toggleCleanOverlay() {
        val newValue = !sitePolicyStore.cleanOverlayEnabled.value
        sitePolicyStore.setCleanOverlayEnabled(newValue)
        GeckoEngine.setCleanOverlayEnabled(newValue) {
            reloadActiveTab()
        }
        _snackbarEvent.value = SnackbarEvent(
            message = if (newValue) "Đã bật dọn lớp phủ quảng cáo" else "Đã tắt dọn lớp phủ quảng cáo"
        )
    }

    fun toggleBackgroundPlay() {
        val newValue = !sitePolicyStore.backgroundPlayEnabled.value
        sitePolicyStore.setBackgroundPlayEnabled(newValue)
        GeckoEngine.setBackgroundPlayEnabled(newValue) {
            reloadActiveTab()
        }
        _snackbarEvent.value = SnackbarEvent(
            message = if (newValue) "Đã bật phát YouTube dưới nền" else "Đã tắt phát YouTube dưới nền"
        )
    }

    fun toggleSavior() {
        val newValue = !sitePolicyStore.saviorEnabled.value
        sitePolicyStore.setSaviorEnabled(newValue)
        if (!newValue) {
            _showSaviorSheet.value = false
            dismissYtDialog()
        }
        GeckoEngine.setSaviorEnabled(newValue)
        _snackbarEvent.value = SnackbarEvent(
            message = if (newValue) "Đã bật Savior" else "Đã tắt Savior"
        )
    }

    fun toggleDevtools() {
        val newValue = !sitePolicyStore.devtoolsEnabled.value
        sitePolicyStore.setDevtoolsEnabled(newValue)
        GeckoEngine.setDevtoolsEnabled(newValue) {
            reloadActiveTab()
        }
        _snackbarEvent.value = SnackbarEvent(
            message = if (newValue) "Đã bật F12, đang tải lại trang" else "Đã tắt F12, đang tải lại trang"
        )
    }

    fun clearSnackbarEvent() {
        _snackbarEvent.value = null
    }

    fun setShowPolicyManagementDialog(show: Boolean) {
        _showPolicyManagementDialog.value = show
    }

    fun setShowTabSwitcher(show: Boolean) {
        if (show) exitFullscreen()
        _showTabSwitcher.value = show
        val active = activeTab
        if (show) {
            tabHelper.setSessionActive(active, false)
        } else {
            tabHelper.setSessionActive(active, true)
        }
    }

    fun setShowBookmarksDialog(show: Boolean) {
        _showBookmarksDialog.value = show
    }

    fun setShowHistoryDialog(show: Boolean) {
        _showHistoryDialog.value = show
    }

    fun setShowDownloadsScreen(show: Boolean) {
        _showDownloadsScreen.value = show
        if (show) {
            loadDownloadedFiles()
        }
    }

    fun loadDownloadedFiles() {
        viewModelScope.launch {
            val files = AuraDownloadsQueryHelper.queryDownloadedFiles(getApplication())
            _downloadedFiles.value = files
        }
    }

    fun deleteDownloadedFile(item: DownloadedFileItem) {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val deleted = AuraDownloadsQueryHelper.deleteDownloadedFile(app, item)
            if (deleted) {
                Toast.makeText(
                    app,
                    app.getString(R.string.downloads_toast_deleted),
                    Toast.LENGTH_SHORT
                ).show()
                loadDownloadedFiles()
            } else {
                Toast.makeText(
                    app,
                    app.getString(R.string.downloads_toast_delete_failed),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    fun setShowOverflowMenu(show: Boolean) {
        _showOverflowMenu.value = show
    }

    fun setShowAboutDialog(show: Boolean) {
        _showAboutDialog.value = show
    }

    fun openDiagnostics() {
        _diagnosticsLogs.value = AppLogger.getRecentLogs()
        _showDiagnosticsDialog.value = true
    }

    fun closeDiagnostics() {
        _showDiagnosticsDialog.value = false
    }

    fun openProtectionStatsDialog() {
        val tab = activeTab
        if (tab != null) {
            tabHelper.refreshContentBlockingLog(tab) { loggedCount ->
                protectionStatsStore.recordLogCrossReferenced(tab.id, loggedCount)
            }
        }
        _showProtectionStatsDialog.value = true
    }

    fun closeProtectionStatsDialog() {
        _showProtectionStatsDialog.value = false
    }

    fun resetProtectionTotals() {
        protectionStatsStore.resetTotals()
    }

    private var isAppResumed: Boolean = false
    private var isRecovering: Boolean = false
    private var keptActiveForMedia: Boolean = false
    private var userRequestedPause: Boolean = false
    private var lastAppPausedAtElapsedMs: Long = 0L

    private fun releaseSessionKeptForMediaIfBackgrounded(mediaTabId: String? = _mediaState.value?.tabId) {
        if (!isAppResumed && keptActiveForMedia) {
            keptActiveForMedia = false
            val mediaTab = if (mediaTabId != null) _tabs.value.find { it.id == mediaTabId } else null
            tabHelper.setSessionActive(mediaTab, false)
            if (activeTab?.id != mediaTab?.id) {
                tabHelper.setSessionActive(activeTab, false)
            }
            AppLogger.d(
                "AuraBrowser",
                "release session active after media stopped/paused in background: tabId=${mediaTab?.id ?: activeTab?.id}"
            )
        }
    }

    fun onSessionLost(tabId: String) {
        AppLogger.d("AuraBrowser", "session lost: tabId=$tabId")
        if (_mediaState.value?.tabId == tabId) {
            _mediaState.value = null
            releaseSessionKeptForMediaIfBackgrounded(tabId)
            MediaPlaybackService.scheduleDismissIn5s(getApplication())
        }
        val tab = _tabs.value.find { it.id == tabId }
        try {
            tab?.session?.close()
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "Error closing lost session: ${e.message}")
        }

        _tabs.update { list ->
            list.map { t ->
                if (t.id == tabId) {
                    t.copy(session = null)
                } else {
                    t
                }
            }
        }

        val isActive = _activeTabId.value == tabId
        if (isActive && isAppResumed) {
            recoverActiveTab()
        } else {
            AppLogger.d("AuraBrowser", "Session marked lost for tabId=$tabId, waiting for resume (isActive=$isActive, isAppResumed=$isAppResumed)")
        }
    }

    fun recoverActiveTab() {
        if (isRecovering) return
        val currentTab = activeTab ?: return
        if (currentTab.isStartPage) return

        val session = currentTab.session
        val isPlayingInThisTab = _mediaState.value?.let { it.tabId == currentTab.id && it.isPlaying } == true
        if (isPlayingInThisTab && session != null) {
            return
        }
        val needsRecovery = session == null || !session.isOpen
        if (!needsRecovery) return

        isRecovering = true
        AppLogger.d("AuraBrowser", "recovering: tabId=${currentTab.id}, url=${currentTab.url}")
        try {
            val newSession = tabHelper.restoreSession(currentTab)
            _tabs.update { list ->
                list.map { t ->
                    if (t.id == currentTab.id) {
                        t.copy(session = newSession)
                    } else {
                        t
                    }
                }
            }
            val updatedTab = _tabs.value.find { it.id == currentTab.id }
            tabHelper.setSessionActive(updatedTab, true)
            AppLogger.d("AuraBrowser", "recovered: tabId=${currentTab.id}")
        } catch (e: Exception) {
            AppLogger.d("AuraBrowser", "Error recovering session for tabId=${currentTab.id}: ${e.message}")
        } finally {
            isRecovering = false
        }
    }

    fun onAppResumed() {
        isAppResumed = true
        if (keptActiveForMedia) {
            keptActiveForMedia = false
            AppLogger.d("AuraBrowser", "release keptActiveForMedia on resume")
        }
        recoverActiveTab()
        tabHelper.setSessionActive(activeTab, true)
    }

    fun onAppPaused() {
        isAppResumed = false
        lastAppPausedAtElapsedMs = android.os.SystemClock.elapsedRealtime()
        val currentMedia = _mediaState.value
        if (currentMedia != null && currentMedia.isPlaying) {
            keptActiveForMedia = true
            val mediaTab = _tabs.value.find { it.id == currentMedia.tabId }
            tabHelper.setSessionActive(mediaTab, true)
            syncMediaNotification()
            AppLogger.d("AuraBrowser", "keep session active for media: tabId=${currentMedia.tabId}")
        } else {
            keptActiveForMedia = false
            tabHelper.setSessionActive(activeTab, false)
        }
    }

    fun onAppBackgrounded() {
        val currentMedia = _mediaState.value
        if (keptActiveForMedia && currentMedia != null && currentMedia.isPlaying) {
            val mediaTab = _tabs.value.find { it.id == currentMedia.tabId }
            tabHelper.setSessionActive(mediaTab, true)
        }
        protectionStatsStore.flush()
        saveTabsNow()
    }

    fun removeSearchQuery(query: String) {
        searchHistoryStore.remove(query)
    }

    fun clearSearchHistory() {
        searchHistoryStore.clear()
        _snackbarEvent.value = SnackbarEvent(message = "Đã xoá lịch sử tìm kiếm")
    }

    fun addShortcut(title: String, url: String) {
        shortcutStore.add(title, url)
    }

    fun editShortcut(id: String, title: String, url: String) {
        shortcutStore.edit(id, title, url)
    }

    fun deleteShortcut(id: String) {
        val removed = shortcutStore.remove(id)
        if (removed != null) {
            _snackbarEvent.value = SnackbarEvent(
                message = "Đã xoá lối tắt",
                actionLabel = "Hoàn tác",
                onAction = { shortcutStore.restore(removed) }
            )
        }
    }

    fun deleteShortcut(shortcut: ShortcutItem) {
        deleteShortcut(shortcut.id)
    }

    fun setOmniboxInput(text: String) {
        _omniboxInput.value = text
    }

    fun setIsEditingOmnibox(editing: Boolean) {
        _isEditingOmnibox.value = editing
        if (editing) {
            val tab = activeTab
            _omniboxInput.value = if (tab?.isStartPage == true) "" else (tab?.url ?: "")
        }
    }

    fun setShowFindInPage(show: Boolean) {
        _showFindInPage.value = show
        if (!show) {
            _findQuery.value = ""
        }
    }

    fun setFindQuery(query: String) {
        _findQuery.value = query
    }

    fun setSearchEngine(engine: SearchEngine) {
        _searchEngine.value = engine
        viewModelScope.launch(Dispatchers.IO) {
            tabSessionStore.saveSearchEngine(engine.name)
        }
    }

    private fun normalizeInput(input: String): String {
        val trimmed = input.trim()
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true) ||
            trimmed.startsWith("about:", ignoreCase = true) ||
            trimmed.startsWith("file://", ignoreCase = true)
        ) {
            return trimmed
        }

        val domainRegex = Regex("""^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(/.*)?$""")
        val ipRegex = Regex("""^(\d{1,3}\.){3}\d{1,3}(:\d+)?(/.*)?$""")
        val localhostRegex = Regex("""^localhost(:\d+)?(/.*)?$""")

        if (domainRegex.matches(trimmed) || ipRegex.matches(trimmed) || localhostRegex.matches(trimmed)) {
            return "https://$trimmed"
        }

        val encoded = URLEncoder.encode(trimmed, "UTF-8")
        return "${_searchEngine.value.searchUrl}$encoded"
    }

    override fun onCleared() {
        super.onCleared()
        MediaController.onPlay = null
        MediaController.onPause = null
        MediaController.onStop = null
        MediaController.onSelectTab = null
        MediaPlaybackService.dismissNow(getApplication())
        _tabs.value.forEach { tabHelper.closeTab(it) }
    }
}
