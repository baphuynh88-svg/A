package com.example.ui.components

import android.content.Context
import android.view.View
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.util.AppLogger
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

private class AuraGeckoView(context: Context) : GeckoView(context) {
    @Volatile
    var keepSessionActiveInBackground: Boolean = false

    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.VISIBLE &&
            (keepSessionActiveInBackground || com.example.gecko.BackgroundKeepAlive.shouldKeepActive())
        ) {
            // Ngăn GeckoView tự động gọi mSession.setActive(false) khi ứng dụng xuống nền trong lúc đang phát media
            AppLogger.d("AuraBrowser", "AuraGeckoView: giữ session active khi window visibility=$visibility")
            try {
                val currentSession = session
                if (currentSession != null && currentSession.isOpen) {
                    currentSession.setActive(true)
                }
            } catch (_: Exception) {
            }
            return
        }
        super.onWindowVisibilityChanged(visibility)
    }
}

@Composable
fun GeckoViewContainer(
    tabId: String,
    session: GeckoSession?,
    keepSessionActiveInBackground: Boolean = false,
    epoch: Int = 0,
    modifier: Modifier = Modifier
) {
    key(tabId, epoch) {
        AndroidView(
            modifier = modifier.fillMaxSize(),
            factory = { context ->
                AuraGeckoView(context).apply {
                    this.keepSessionActiveInBackground = keepSessionActiveInBackground
                    session?.let { s ->
                        if (s.isOpen) {
                            try {
                                setSession(s)
                            } catch (e: Exception) {
                                AppLogger.d("GeckoViewContainer", "Lỗi setSession cho tab $tabId: ${e.message}")
                            }
                        }
                    }
                }
            },
            update = { view ->
                view.keepSessionActiveInBackground = keepSessionActiveInBackground
                if (session != null && session.isOpen && view.session != session) {
                    try {
                        view.releaseSession()
                        view.setSession(session)
                    } catch (e: Exception) {
                        AppLogger.d("GeckoViewContainer", "Lỗi switch session cho tab $tabId: ${e.message}")
                    }
                } else if ((session == null || !session.isOpen) && view.session != null) {
                    try {
                        view.releaseSession()
                    } catch (_: Exception) {}
                }
            },
            onRelease = { view ->
                try {
                    view.releaseSession()
                } catch (_: Exception) {}
            }
        )
    }
}
