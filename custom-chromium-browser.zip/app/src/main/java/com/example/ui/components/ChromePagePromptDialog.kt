package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.gecko.PagePrompt

/**
 * Hiển thị các hộp thoại JavaScript/HTML chuẩn của web (alert, confirm, prompt, thẻ <select> dropdown).
 * Luôn ghi rõ nguồn theo yêu cầu: "Trang <host> cho biết:".
 */
@Composable
fun ChromePagePromptDialog(
    prompt: PagePrompt
) {
    when (prompt) {
        is PagePrompt.Alert -> {
            AlertDialog(
                onDismissRequest = prompt.onDismiss,
                title = {
                    Text(
                        text = "Trang ${prompt.host} cho biết:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = prompt.message,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    TextButton(onClick = prompt.onConfirm) {
                        Text("OK")
                    }
                }
            )
        }

        is PagePrompt.Confirm -> {
            AlertDialog(
                onDismissRequest = prompt.onDismiss,
                title = {
                    Text(
                        text = "Trang ${prompt.host} cho biết:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = prompt.message,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(onClick = prompt.onPositive) {
                        Text("Đồng ý")
                    }
                },
                dismissButton = {
                    TextButton(onClick = prompt.onNegative) {
                        Text("Huỷ")
                    }
                }
            )
        }

        is PagePrompt.Text -> {
            var inputText by remember(prompt) { mutableStateOf(prompt.defaultValue) }

            AlertDialog(
                onDismissRequest = prompt.onDismiss,
                title = {
                    Text(
                        text = "Trang ${prompt.host} cho biết:",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        if (prompt.message.isNotBlank()) {
                            Text(
                                text = prompt.message,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = { prompt.onConfirm(inputText) }) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = prompt.onDismiss) {
                        Text("Huỷ")
                    }
                }
            )
        }

        is PagePrompt.Choice -> {
            if (prompt.isMultiple) {
                val selectedIds = remember(prompt) {
                    mutableStateListOf<String>().apply {
                        addAll(prompt.choices.filter { it.isSelected }.map { it.id })
                    }
                }

                AlertDialog(
                    onDismissRequest = prompt.onDismiss,
                    title = {
                        Text(
                            text = "Trang ${prompt.host} cho biết:",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            if (prompt.message.isNotBlank()) {
                                Text(
                                    text = prompt.message,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 280.dp)
                            ) {
                                items(prompt.choices) { choice ->
                                    val checked = selectedIds.contains(choice.id)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (checked) selectedIds.remove(choice.id)
                                                else selectedIds.add(choice.id)
                                            }
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = checked,
                                            onCheckedChange = { isChecked ->
                                                if (isChecked) selectedIds.add(choice.id)
                                                else selectedIds.remove(choice.id)
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = choice.label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = { prompt.onConfirmMultiple(selectedIds.toTypedArray()) }) {
                            Text("OK")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = prompt.onDismiss) {
                            Text("Huỷ")
                        }
                    }
                )
            } else {
                var selectedId by remember(prompt) {
                    mutableStateOf(prompt.choices.firstOrNull { it.isSelected }?.id ?: prompt.choices.firstOrNull()?.id ?: "")
                }

                AlertDialog(
                    onDismissRequest = prompt.onDismiss,
                    title = {
                        Text(
                            text = "Trang ${prompt.host} cho biết:",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            if (prompt.message.isNotBlank()) {
                                Text(
                                    text = prompt.message,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 280.dp)
                            ) {
                                items(prompt.choices) { choice ->
                                    val selected = choice.id == selectedId
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedId = choice.id }
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = selected,
                                            onClick = { selectedId = choice.id }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = choice.label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = { prompt.onConfirmSingle(selectedId) }) {
                            Text("OK")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = prompt.onDismiss) {
                            Text("Huỷ")
                        }
                    }
                )
            }
        }
    }
}
