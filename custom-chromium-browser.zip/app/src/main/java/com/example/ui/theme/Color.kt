package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ChromeBlue = Color(0xFF1A73E8)
val ChromeBlueDark = Color(0xFF8AB4F8)
val ChromeSurface = Color(0xFFFFFFFF)
val ChromeSurfaceDark = Color(0xFF1F1F1F)
val ChromeVariant = Color(0xFFF1F3F4)
val ChromeVariantDark = Color(0xFF2C2C2C)
val ChromeAccent = Color(0xFF0D65D9)
val ChromeAccentDark = Color(0xFF90CAF9)
