package com.example.ui.components

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StrictMode
import android.provider.MediaStore
import android.util.Size
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.gecko.SaviorDownloadStatus
import com.example.gecko.SaviorItemDownloadState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DownloadedFileItem(
    val id: String,
    val displayName: String,
    val sizeBytes: Long,
    val mimeType: String,
    val dateAddedMillis: Long,
    val contentUri: Uri,
    val filePath: String? = null
)

enum class DownloadFileCategory(val labelResId: Int) {
    ALL(R.string.downloads_filter_all),
    VIDEO(R.string.downloads_filter_video),
    AUDIO(R.string.downloads_filter_audio),
    IMAGE(R.string.downloads_filter_image),
    DOCUMENT(R.string.downloads_filter_document),
    OTHER(R.string.downloads_filter_other)
}

internal fun classifyDownloadedFile(mimeType: String, fileName: String): DownloadFileCategory {
    val cleanMime = mimeType.lowercase(Locale.ROOT).trim()
    val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

    return when {
        cleanMime.startsWith("video/") || ext in setOf("mp4", "webm", "mkv", "mov", "m4v", "avi", "3gp") ->
            DownloadFileCategory.VIDEO
        cleanMime.startsWith("audio/") || ext in setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac") ->
            DownloadFileCategory.AUDIO
        cleanMime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic") ->
            DownloadFileCategory.IMAGE
        cleanMime == "application/pdf" ||
            cleanMime.startsWith("text/") ||
            cleanMime.contains("word") ||
            cleanMime.contains("excel") ||
            cleanMime.contains("spreadsheet") ||
            cleanMime.contains("presentation") ||
            cleanMime.contains("powerpoint") ||
            cleanMime.contains("officedocument") ||
            cleanMime.contains("opendocument") ||
            cleanMime == "application/rtf" ||
            cleanMime == "application/epub+zip" ||
            ext in setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "epub", "md") ->
            DownloadFileCategory.DOCUMENT
        else -> DownloadFileCategory.OTHER
    }
}

internal fun formatDownloadedFileSize(sizeBytes: Long): String {
    if (sizeBytes <= 0L) return "0 B"
    val kb = 1024.0
    val mb = kb * 1024.0
    val gb = mb * 1024.0
    return when {
        sizeBytes >= gb -> String.format(Locale.US, "%.2f GB", sizeBytes / gb)
        sizeBytes >= mb -> String.format(Locale.US, "%.1f MB", sizeBytes / mb)
        sizeBytes >= kb -> String.format(Locale.US, "%.0f KB", sizeBytes / kb)
        else -> "$sizeBytes B"
    }
}

internal fun formatDownloadedFileTypeLabel(
    context: Context,
    mimeType: String,
    fileName: String
): String {
    val ext = fileName.substringAfterLast('.', "").uppercase(Locale.ROOT)
    if (ext.isNotBlank() && ext.length <= 5) {
        return ext
    }
    return when (classifyDownloadedFile(mimeType, fileName)) {
        DownloadFileCategory.VIDEO -> context.getString(R.string.downloads_filter_video)
        DownloadFileCategory.AUDIO -> context.getString(R.string.downloads_filter_audio)
        DownloadFileCategory.IMAGE -> context.getString(R.string.downloads_filter_image)
        DownloadFileCategory.DOCUMENT -> context.getString(R.string.downloads_filter_document)
        else -> context.getString(R.string.downloads_filter_other)
    }
}

internal fun formatDateBucketLabel(
    context: Context,
    timestampMillis: Long
): String {
    val nowCal = Calendar.getInstance()
    val todayYear = nowCal.get(Calendar.YEAR)
    val todayDayOfYear = nowCal.get(Calendar.DAY_OF_YEAR)

    val yesterdayCal = (nowCal.clone() as Calendar).apply {
        add(Calendar.DAY_OF_YEAR, -1)
    }
    val yesterdayYear = yesterdayCal.get(Calendar.YEAR)
    val yesterdayDayOfYear = yesterdayCal.get(Calendar.DAY_OF_YEAR)

    val itemCal = Calendar.getInstance().apply {
        timeInMillis = if (timestampMillis > 0L) timestampMillis else System.currentTimeMillis()
    }
    val itemYear = itemCal.get(Calendar.YEAR)
    val itemDayOfYear = itemCal.get(Calendar.DAY_OF_YEAR)

    return when {
        itemYear == todayYear && itemDayOfYear == todayDayOfYear ->
            context.getString(R.string.downloads_date_today)
        itemYear == yesterdayYear && itemDayOfYear == yesterdayDayOfYear ->
            context.getString(R.string.downloads_date_yesterday)
        else -> {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            sdf.format(Date(itemCal.timeInMillis))
        }
    }
}

object AuraDownloadsQueryHelper {
    suspend fun queryDownloadedFiles(context: Context): List<DownloadedFileItem> = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            queryMediaStoreDownloadsApi29(context)
        } else {
            queryLegacyDownloadsDirectory(context)
        }
    }

    private fun queryMediaStoreDownloadsApi29(context: Context): List<DownloadedFileItem> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return emptyList()
        val result = mutableListOf<DownloadedFileItem>()
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? AND ${MediaStore.MediaColumns.IS_PENDING} = 0"
        val selectionArgs = arrayOf("Download/Aura%")
        val sortOrder = "${MediaStore.MediaColumns.DATE_ADDED} DESC, ${MediaStore.MediaColumns._ID} DESC"

        try {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawName = cursor.getString(nameCol)?.takeIf { it.isNotBlank() } ?: "download_$id"
                    val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val rawMime = cursor.getString(mimeCol)?.takeIf { it.isNotBlank() }
                        ?: resolveMimeFromFileName(rawName)
                    val rawDateAdded = cursor.getLong(dateCol)
                    val dateAddedMillis = when {
                        rawDateAdded <= 0L -> System.currentTimeMillis()
                        rawDateAdded < 10_000_000_000L -> rawDateAdded * 1000L
                        else -> rawDateAdded
                    }
                    val contentUri = ContentUris.withAppendedId(collection, id)
                    result.add(
                        DownloadedFileItem(
                            id = "ms_$id",
                            displayName = rawName,
                            sizeBytes = size,
                            mimeType = rawMime,
                            dateAddedMillis = dateAddedMillis,
                            contentUri = contentUri,
                            filePath = null
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    @Suppress("DEPRECATION")
    private fun queryLegacyDownloadsDirectory(context: Context): List<DownloadedFileItem> {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val auraDir = File(downloadsDir, "Aura")
        if (!auraDir.exists() || !auraDir.isDirectory) return emptyList()

        val files = auraDir.walkTopDown()
            .filter { it.isFile && !it.name.startsWith(".") }
            .sortedByDescending { it.lastModified() }
            .toList()

        return files.map { file ->
            val mimeType = resolveMimeFromFileName(file.name)
            val contentUri = resolveLegacyContentUri(context, file) ?: Uri.fromFile(file)
            DownloadedFileItem(
                id = "file_${file.absolutePath}",
                displayName = file.name,
                sizeBytes = file.length().coerceAtLeast(0L),
                mimeType = mimeType,
                dateAddedMillis = file.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis(),
                contentUri = contentUri,
                filePath = file.absolutePath
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveLegacyContentUri(context: Context, file: File): Uri? {
        return try {
            val externalFilesUri = MediaStore.Files.getContentUri("external")
            val projection = arrayOf(MediaStore.Files.FileColumns._ID)
            val selection = "${MediaStore.MediaColumns.DATA} = ?"
            val selectionArgs = arrayOf(file.absolutePath)
            context.contentResolver.query(
                externalFilesUri,
                projection,
                selection,
                selectionArgs,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val id = cursor.getLong(0)
                    ContentUris.withAppendedId(externalFilesUri, id)
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveMimeFromFileName(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext.isNotBlank()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
        }
        return when (ext) {
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg", "opus" -> "audio/ogg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "pdf" -> "application/pdf"
            "txt" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    suspend fun deleteDownloadedFile(context: Context, item: DownloadedFileItem): Boolean =
        withContext(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    context.contentResolver.delete(item.contentUri, null, null) > 0
                } else {
                    val path = item.filePath
                    if (!path.isNullOrBlank()) {
                        val file = File(path)
                        val deleted = !file.exists() || file.delete()
                        try {
                            context.contentResolver.delete(item.contentUri, null, null)
                        } catch (_: Exception) {
                        }
                        deleted
                    } else {
                        context.contentResolver.delete(item.contentUri, null, null) > 0
                    }
                }
            } catch (_: Exception) {
                false
            }
        }
}

@Composable
fun ChromeDownloadsScreen(
    downloadedFiles: List<DownloadedFileItem>,
    downloadStates: Map<String, SaviorItemDownloadState>,
    onRefresh: () -> Unit,
    onDeleteFile: (DownloadedFileItem) -> Unit,
    onCancelDownload: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var isSearching by rememberSaveable { mutableStateOf(false) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf(DownloadFileCategory.ALL) }
    var itemPendingDelete by remember { mutableStateOf<DownloadedFileItem?>(null) }

    val focusRequester = remember { FocusRequester() }

    val activeDownloads = remember(downloadStates) {
        downloadStates.values.filter {
            it.status == SaviorDownloadStatus.QUEUED ||
                it.status == SaviorDownloadStatus.DOWNLOADING ||
                it.status == SaviorDownloadStatus.MUXING
        }
    }

    // Tự làm mới khi mở màn hình và khi số lượng tải đang chạy thay đổi (ví dụ vừa hoàn tất 1 file)
    LaunchedEffect(activeDownloads.size) {
        onRefresh()
    }

    LaunchedEffect(isSearching) {
        if (isSearching) {
            try {
                focusRequester.requestFocus()
            } catch (_: Exception) {
            }
        }
    }

    val filteredFiles = remember(downloadedFiles, searchQuery, selectedCategory) {
        val query = searchQuery.trim()
        downloadedFiles.filter { item ->
            val matchesQuery = query.isBlank() || item.displayName.contains(query, ignoreCase = true)
            val matchesCategory = selectedCategory == DownloadFileCategory.ALL ||
                classifyDownloadedFile(item.mimeType, item.displayName) == selectedCategory
            matchesQuery && matchesCategory
        }
    }

    val groupedFiles = remember(filteredFiles, context) {
        filteredFiles.groupBy { item ->
            formatDateBucketLabel(context, item.dateAddedMillis)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BackHandler {
            if (isSearching) {
                isSearching = false
                searchQuery = ""
            } else {
                onDismiss()
            }
        }

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("chrome_downloads_screen"),
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                ) {
                    DownloadsTopBar(
                        isSearching = isSearching,
                        searchQuery = searchQuery,
                        focusRequester = focusRequester,
                        onSearchQueryChange = { searchQuery = it },
                        onOpenSearch = { isSearching = true },
                        onCloseSearch = {
                            isSearching = false
                            searchQuery = ""
                        },
                        onBack = {
                            if (isSearching) {
                                isSearching = false
                                searchQuery = ""
                            } else {
                                onDismiss()
                            }
                        }
                    )

                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(DownloadFileCategory.entries) { category ->
                            val selected = selectedCategory == category
                            FilterChip(
                                selected = selected,
                                onClick = { selectedCategory = category },
                                label = {
                                    Text(
                                        text = stringResource(category.labelResId),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                },
                                modifier = Modifier.testTag("downloads_chip_${category.name.lowercase(Locale.ROOT)}")
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                }
            }
        ) { innerPadding ->
            if (activeDownloads.isEmpty() && filteredFiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(72.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (searchQuery.isNotBlank() || selectedCategory != DownloadFileCategory.ALL) {
                                stringResource(R.string.downloads_empty_search_message)
                            } else {
                                stringResource(R.string.downloads_empty_message)
                            },
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.testTag("downloads_empty_text")
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .testTag("downloads_list"),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    if (activeDownloads.isNotEmpty()) {
                        item(key = "active_downloads_header") {
                            SectionHeaderRow(title = stringResource(R.string.downloads_section_active))
                        }
                        items(activeDownloads, key = { "active_${it.itemId}" }) { state ->
                            ActiveDownloadItemRow(
                                state = state,
                                onCancel = { onCancelDownload(state.itemId) }
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            )
                        }
                    }

                    groupedFiles.forEach { (dateHeader, itemsInDate) ->
                        item(key = "header_$dateHeader") {
                            SectionHeaderRow(title = dateHeader)
                        }
                        items(itemsInDate, key = { it.id }) { fileItem ->
                            DownloadedFileRow(
                                item = fileItem,
                                onOpen = { openDownloadedFile(context, fileItem) },
                                onShare = { shareDownloadedFile(context, fileItem) },
                                onDeleteRequest = { itemPendingDelete = fileItem }
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            )
                        }
                    }
                }
            }
        }

        itemPendingDelete?.let { targetItem ->
            AlertDialog(
                onDismissRequest = { itemPendingDelete = null },
                title = {
                    Text(
                        text = stringResource(R.string.downloads_delete_dialog_title),
                        fontWeight = FontWeight.SemiBold
                    )
                },
                text = {
                    Text(
                        text = stringResource(R.string.downloads_delete_dialog_message, targetItem.displayName)
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            itemPendingDelete = null
                            onDeleteFile(targetItem)
                        },
                        modifier = Modifier.testTag("confirm_delete_download_button")
                    ) {
                        Text(
                            text = stringResource(R.string.downloads_delete_confirm),
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { itemPendingDelete = null },
                        modifier = Modifier.testTag("cancel_delete_download_button")
                    ) {
                        Text(text = stringResource(R.string.downloads_delete_cancel))
                    }
                }
            )
        }
    }
}

@Composable
private fun DownloadsTopBar(
    isSearching: Boolean,
    searchQuery: String,
    focusRequester: FocusRequester,
    onSearchQueryChange: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onCloseSearch: () -> Unit,
    onBack: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("downloads_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.downloads_back_cd),
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            if (isSearching) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = stringResource(R.string.downloads_search_placeholder),
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester)
                            .testTag("downloads_search_input")
                    )
                }

                IconButton(
                    onClick = {
                        if (searchQuery.isNotEmpty()) {
                            onSearchQueryChange("")
                        } else {
                            onCloseSearch()
                        }
                    },
                    modifier = Modifier.testTag("downloads_search_clear_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = if (searchQuery.isNotEmpty()) {
                            stringResource(R.string.downloads_search_clear_cd)
                        } else {
                            stringResource(R.string.downloads_search_close_cd)
                        },
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = stringResource(R.string.downloads_title),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )

                IconButton(
                    onClick = onOpenSearch,
                    modifier = Modifier.testTag("downloads_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = stringResource(R.string.downloads_search_cd),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeaderRow(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge.copy(
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun ActiveDownloadItemRow(
    state: SaviorItemDownloadState,
    onCancel: () -> Unit
) {
    val total = state.totalBytes
    val fraction = if (total != null && total > 0L) {
        (state.downloadedBytes.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    } else {
        null
    }

    val statusText = when (state.status) {
        SaviorDownloadStatus.QUEUED -> stringResource(R.string.downloads_status_queued)
        SaviorDownloadStatus.MUXING -> stringResource(R.string.downloads_status_muxing)
        else -> {
            val downloadedStr = formatDownloadedFileSize(state.downloadedBytes)
            val totalStr = total?.takeIf { it > 0L }?.let { formatDownloadedFileSize(it) }
            if (totalStr != null && fraction != null) {
                val pct = (fraction * 100).toInt()
                "$downloadedStr / $totalStr ($pct%)"
            } else {
                "$downloadedStr • ${stringResource(R.string.downloads_status_downloading)}"
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("active_download_row_${state.itemId}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(44.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = state.fileName.ifBlank { "Media" },
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            if (fraction != null && state.status == SaviorDownloadStatus.DOWNLOADING) {
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        TextButton(
            onClick = onCancel,
            modifier = Modifier.testTag("cancel_active_download_${state.itemId}")
        ) {
            Text(
                text = stringResource(R.string.downloads_action_cancel),
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun DownloadedFileRow(
    item: DownloadedFileItem,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onDeleteRequest: () -> Unit
) {
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    val category = remember(item.mimeType, item.displayName) {
        classifyDownloadedFile(item.mimeType, item.displayName)
    }
    val subtitle = remember(item.sizeBytes, item.mimeType, item.displayName, context) {
        val sizeStr = formatDownloadedFileSize(item.sizeBytes)
        val typeStr = formatDownloadedFileTypeLabel(context, item.mimeType, item.displayName)
        "$sizeStr • $typeStr"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("downloaded_file_row_${item.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DownloadedFileThumbnailOrIcon(
            item = item,
            category = category
        )

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.displayName,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Box {
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier.testTag("downloaded_file_more_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = stringResource(R.string.downloads_more_options_cd),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.downloads_action_open)) },
                    leadingIcon = {
                        Icon(
                            imageVector = categoryIcon(category),
                            contentDescription = null
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onOpen()
                    },
                    modifier = Modifier.testTag("downloaded_file_menu_open_${item.id}")
                )

                DropdownMenuItem(
                    text = { Text(stringResource(R.string.downloads_action_share)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onShare()
                    },
                    modifier = Modifier.testTag("downloaded_file_menu_share_${item.id}")
                )

                DropdownMenuItem(
                    text = {
                        Text(
                            text = stringResource(R.string.downloads_action_delete),
                            color = MaterialTheme.colorScheme.error
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                    },
                    onClick = {
                        menuExpanded = false
                        onDeleteRequest()
                    },
                    modifier = Modifier.testTag("downloaded_file_menu_delete_${item.id}")
                )
            }
        }
    }
}

@Composable
private fun DownloadedFileThumbnailOrIcon(
    item: DownloadedFileItem,
    category: DownloadFileCategory
) {
    val context = LocalContext.current
    val shouldTryThumbnail = category == DownloadFileCategory.IMAGE || category == DownloadFileCategory.VIDEO

    val thumbnailBitmap by produceState<Bitmap?>(initialValue = null, item.id, shouldTryThumbnail) {
        if (!shouldTryThumbnail) {
            value = null
            return@produceState
        }
        value = withContext(Dispatchers.IO) {
            loadFileThumbnailSafe(context, item, category)
        }
    }

    val bmp = thumbnailBitmap
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
    } else {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
            modifier = Modifier.size(44.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = categoryIcon(category),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

private fun categoryIcon(category: DownloadFileCategory): ImageVector {
    return when (category) {
        DownloadFileCategory.VIDEO -> Icons.Default.VideoFile
        DownloadFileCategory.AUDIO -> Icons.Default.AudioFile
        DownloadFileCategory.IMAGE -> Icons.Default.Image
        DownloadFileCategory.DOCUMENT -> Icons.Default.Description
        else -> Icons.AutoMirrored.Filled.InsertDriveFile
    }
}

@Suppress("DEPRECATION")
private fun loadFileThumbnailSafe(
    context: Context,
    item: DownloadedFileItem,
    category: DownloadFileCategory
): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.loadThumbnail(item.contentUri, Size(128, 128), null)
        } else {
            val path = item.filePath ?: return null
            if (category == DownloadFileCategory.VIDEO) {
                ThumbnailUtils.createVideoThumbnail(path, MediaStore.Images.Thumbnails.MINI_KIND)
            } else {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, opts)
                val maxDim = maxOf(opts.outWidth, opts.outHeight)
                val sampleSize = if (maxDim > 256) (maxDim / 128).coerceAtLeast(1) else 1
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
                BitmapFactory.decodeFile(path, decodeOpts)
            }
        }
    } catch (_: Exception) {
        null
    }
}

private fun openDownloadedFile(context: Context, item: DownloadedFileItem) {
    val effectiveMime = item.mimeType.ifBlank { "*/*" }
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(item.contentUri, effectiveMime)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    val previousPolicy = StrictMode.getVmPolicy()
    try {
        if (item.contentUri.scheme == "file") {
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(
            context,
            context.getString(R.string.downloads_toast_no_app_to_open),
            Toast.LENGTH_SHORT
        ).show()
    } finally {
        if (item.contentUri.scheme == "file") {
            StrictMode.setVmPolicy(previousPolicy)
        }
    }
}

private fun shareDownloadedFile(context: Context, item: DownloadedFileItem) {
    val effectiveMime = item.mimeType.ifBlank { "*/*" }
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = effectiveMime
        putExtra(Intent.EXTRA_STREAM, item.contentUri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(
        shareIntent,
        context.getString(R.string.downloads_share_chooser_title)
    ).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    val previousPolicy = StrictMode.getVmPolicy()
    try {
        if (item.contentUri.scheme == "file") {
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
        }
        context.startActivity(chooser)
    } catch (_: Exception) {
        Toast.makeText(
            context,
            context.getString(R.string.downloads_toast_share_error),
            Toast.LENGTH_SHORT
        ).show()
    } finally {
        if (item.contentUri.scheme == "file") {
            StrictMode.setVmPolicy(previousPolicy)
        }
    }
}
