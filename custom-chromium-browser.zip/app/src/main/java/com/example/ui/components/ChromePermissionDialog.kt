package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.gecko.PermissionPrompt

/**
 * Hộp thoại xin quyền nội dung web (Vị trí, Camera, Micro) với tuỳ chọn "Nhớ lựa chọn cho trang này".
 */
@Composable
fun ChromePermissionDialog(
    prompt: PermissionPrompt
) {
    var rememberChoice by remember(prompt) { mutableStateOf(false) }

    when (prompt) {
        is PermissionPrompt.Geolocation -> {
            AlertDialog(
                onDismissRequest = prompt.onDismiss,
                icon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                title = {
                    Text(
                        text = "Quyền truy cập vị trí",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Cho phép trang \"${prompt.host}\" sử dụng vị trí của bạn?",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { rememberChoice = !rememberChoice }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = rememberChoice,
                                onCheckedChange = { rememberChoice = it }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Nhớ lựa chọn cho trang này",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { prompt.onDecision(true, rememberChoice) }) {
                        Text("Cho phép")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { prompt.onDecision(false, rememberChoice) }) {
                        Text("Từ chối")
                    }
                }
            )
        }

        is PermissionPrompt.Media -> {
            val icon = if (prompt.hasVideo) Icons.Default.Videocam else Icons.Default.Mic
            val title = when {
                prompt.hasVideo && prompt.hasAudio -> "Quyền Camera & Micro"
                prompt.hasVideo -> "Quyền Camera"
                else -> "Quyền Micro"
            }
            val question = when {
                prompt.hasVideo && prompt.hasAudio -> "Cho phép trang \"${prompt.host}\" sử dụng Camera và Micro của bạn?"
                prompt.hasVideo -> "Cho phép trang \"${prompt.host}\" sử dụng Camera của bạn?"
                else -> "Cho phép trang \"${prompt.host}\" sử dụng Micro của bạn?"
            }

            AlertDialog(
                onDismissRequest = prompt.onDismiss,
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                title = {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = question,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { rememberChoice = !rememberChoice }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = rememberChoice,
                                onCheckedChange = { rememberChoice = it }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Nhớ lựa chọn cho trang này",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { prompt.onDecision(true, rememberChoice) }) {
                        Text("Cho phép")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { prompt.onDecision(false, rememberChoice) }) {
                        Text("Từ chối")
                    }
                }
            )
        }
    }
}
