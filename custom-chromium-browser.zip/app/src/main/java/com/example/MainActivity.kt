package com.example

import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.gecko.FilePickerBridge
import com.example.gecko.MediaPlaybackService
import com.example.gecko.PermissionBridge
import com.example.ui.BrowserScreen
import com.example.ui.BrowserViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppLogger

class MainActivity : ComponentActivity() {
    private companion object {
        const val OPENED_DIR_NAME = "opened"
    }

    private val viewModel: BrowserViewModel by viewModels()

    // Đã từng vào fullscreen: dùng để kiểm tra lại kích thước cửa sổ sau khi thoát
    private var wasFullscreen = false

    private var filePickerCallback: ((Int, Intent?) -> Unit)? = null
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        filePickerCallback?.invoke(result.resultCode, result.data)
        filePickerCallback = null
    }

    private var permissionCallback: ((Boolean) -> Unit)? = null
    private val requestMultiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.isNotEmpty() && results.values.all { it }
        permissionCallback?.invoke(allGranted)
        permissionCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đăng ký launcher cho FilePickerBridge trước khi setContent
        FilePickerBridge.launcher = { intent, callback ->
            filePickerCallback = callback
            try {
                filePickerLauncher.launch(intent)
            } catch (_: Exception) {
                callback(Activity.RESULT_CANCELED, null)
                filePickerCallback = null
            }
        }

        // Đăng ký requester cho PermissionBridge trước khi setContent
        PermissionBridge.requester = { permissions, callback ->
            permissionCallback = callback
            try {
                requestMultiplePermissionsLauncher.launch(permissions)
            } catch (_: Exception) {
                callback(false)
                permissionCallback = null
            }
        }

        enableEdgeToEdge()
        handleMediaNotificationIntent(intent)
        cleanupOldOpenedFiles()
        if (savedInstanceState == null) {
            handleExternalIntent(intent)
        }
        setContent {
            val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
            val activeTabIsPrivate by viewModel.activeTabIsPrivate.collectAsStateWithLifecycle()

            // Đảm bảo không gán FLAG_SECURE để màn hình không bị đen thui trên Streaming Emulator
            LaunchedEffect(Unit) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }

            // Xử lý chế độ Fullscreen toàn màn hình cho video/web
            LaunchedEffect(isFullscreen) {
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                if (isFullscreen) {
                    insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    insetsController.hide(WindowInsetsCompat.Type.systemBars())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        window.attributes = window.attributes.apply {
                            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        }
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                } else {
                    insetsController.show(WindowInsetsCompat.Type.systemBars())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        window.attributes = window.attributes.apply {
                            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                        }
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    if (wasFullscreen) {
                        wasFullscreen = false
                        // Quẹt back thoát fullscreen có thể làm khung giao diện kẹt ở kích thước lúc xoay ngang
                        ensureWindowLayoutMatches()
                    }
                }
                if (isFullscreen) wasFullscreen = true
            }

            MyApplicationTheme {
                val isDark = isSystemInDarkTheme()
                val topBarColor = MaterialTheme.colorScheme.surface
                val view = LocalView.current

                if (!view.isInEditMode && !isFullscreen) {
                    SideEffect {
                        val currentWindow = (view.context as? Activity)?.window ?: return@SideEffect
                        val insetsController = WindowCompat.getInsetsController(currentWindow, view)
                        // Icon status bar và navigation bar tự đổi sáng/tối theo theme
                        insetsController.isAppearanceLightStatusBars = !isDark
                        insetsController.isAppearanceLightNavigationBars = !isDark
                    }
                }

                // Khi fullscreen: Bỏ windowInsetsPadding(safeDrawing) để tràn toàn màn hình
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(topBarColor)
                        .then(
                            if (isFullscreen) Modifier else Modifier.windowInsetsPadding(WindowInsets.safeDrawing)
                        )
                ) {
                    BrowserScreen(viewModel = viewModel)
                }
            }
        }
    }

    /**
     * Sau khi thoát fullscreen (xoay ngang -> dọc), đôi khi cây giao diện giữ kích thước cũ:
     * thanh địa chỉ lệch/tràn phải, phần dưới đen. Ép đo lại; nếu vẫn lệch so với cửa sổ thật
     * thì dựng lại Activity (ViewModel và các tab vẫn giữ nguyên).
     */
    private suspend fun ensureWindowLayoutMatches() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val delays = longArrayOf(500L, 700L, 900L)
        var attempt = 0
        for (d in delays) {
            delay(d)
            attempt++
            val decor = window.decorView
            decor.requestLayout()
            ViewCompat.requestApplyInsets(decor)
            val bounds = windowManager.currentWindowMetrics.bounds
            val matches = decor.width == bounds.width() && decor.height == bounds.height()
            AppLogger.d(
                "Fullscreen",
                "kiểm tra #$attempt: decor=${decor.width}x${decor.height} cửa sổ=${bounds.width()}x${bounds.height()} " +
                    "orientation=${resources.configuration.orientation} khớp=$matches"
            )
            if (matches) {
                // Lần đầu đã lệch rồi mới khớp: dựng lại GeckoView theo kích thước đã ổn định
                if (attempt > 1) viewModel.refreshGeckoView()
                return
            }
        }
        AppLogger.d("Fullscreen", "vẫn lệch sau 3 lần kiểm tra -> dựng lại Activity")
        recreate()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMediaNotificationIntent(intent)
        handleExternalIntent(intent)
    }

    private fun handleMediaNotificationIntent(intent: Intent?) {
        val targetTabId = intent?.getStringExtra(MediaPlaybackService.EXTRA_TAB_ID)
        if (!targetTabId.isNullOrBlank()) {
            viewModel.selectTab(targetTabId)
            intent.removeExtra(MediaPlaybackService.EXTRA_TAB_ID)
        }
    }

    private fun handleExternalIntent(intent: Intent?) {
        intent ?: return
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                val data = intent.data ?: return
                when (data.scheme?.lowercase()) {
                    "http", "https", "file" -> viewModel.openExternalInput(data.toString())
                    "content" -> openContentUri(data)
                }
                // Xoá data để không xử lý lại (vd: mở lại từ lịch sử, tạo lại activity)
                intent.data = null
            }

            Intent.ACTION_WEB_SEARCH -> {
                val query = intent.getStringExtra(SearchManager.QUERY)
                if (!query.isNullOrBlank()) {
                    viewModel.openExternalInput(query)
                }
                intent.removeExtra(SearchManager.QUERY)
            }

            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!text.isNullOrBlank()) {
                    // Chữ được chia sẻ thường có dạng "Tiêu đề https://..." nên ưu tiên lấy URL trong đó
                    val url = Regex("""https?://\S+""", RegexOption.IGNORE_CASE)
                        .find(text)?.value
                    viewModel.openExternalInput(url ?: text)
                }
                intent.removeExtra(Intent.EXTRA_TEXT)
            }
        }
    }

    /**
     * GeckoView không đọc được content:// của app khác, nên sao chép dữ liệu vào
     * cacheDir/opened/ rồi mở bằng file://.
     */
    private fun openContentUri(uri: Uri) {
        lifecycleScope.launch {
            try {
                val copied = withContext(Dispatchers.IO) { copyContentToCache(uri) }
                viewModel.openExternalInput(Uri.fromFile(copied).toString())
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                Toast.makeText(this@MainActivity, "Không có quyền đọc tệp này", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Không thể mở tệp này", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun copyContentToCache(uri: Uri): File {
        val dir = File(cacheDir, OPENED_DIR_NAME).apply { mkdirs() }

        var displayName: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) displayName = cursor.getString(idx)
                }
            }
        } catch (_: Exception) {
        }

        var name = sanitizeFileName(displayName)
        if (!name.contains('.')) {
            val mime = try { contentResolver.getType(uri) } catch (_: Exception) { null }
            val ext = when (mime) {
                "message/rfc822", "multipart/related" -> "mhtml"
                null -> null
                else -> MimeTypeMap.getSingleton().getExtensionFromMimeType(mime)
            }
            if (!ext.isNullOrBlank()) name = "$name.$ext"
        }

        // Xử lý trùng tên: name.ext -> name (1).ext
        val base = name.substringBeforeLast('.', name)
        val extPart = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var target = File(dir, name)
        var counter = 1
        while (target.exists()) {
            target = File(dir, "$base ($counter)$extPart")
            counter++
        }

        // Chống path traversal: file đích phải nằm trong thư mục opened
        if (target.canonicalFile.parentFile?.canonicalPath != dir.canonicalPath) {
            throw IOException("Invalid target path")
        }

        val input = contentResolver.openInputStream(uri) ?: throw IOException("Cannot open stream")
        input.use { src ->
            target.outputStream().use { dst -> src.copyTo(dst) }
        }
        return target
    }

    private fun sanitizeFileName(raw: String?): String {
        var name = raw.orEmpty().substringAfterLast('/').substringAfterLast('\\')
        name = name.replace(Regex("[^\\p{L}\\p{N}._ ()-]"), "_")
        name = name.trim().trimStart('.')
        if (name.length > 100) {
            val ext = if (name.contains('.')) "." + name.substringAfterLast('.').take(10) else ""
            name = name.substringBeforeLast('.', name).take(100 - ext.length) + ext
        }
        return name.ifBlank { "file" }
    }

    private fun cleanupOldOpenedFiles() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val limit = System.currentTimeMillis() - 24L * 60 * 60 * 1000
                File(cacheDir, OPENED_DIR_NAME).listFiles()?.forEach { f ->
                    if (f.isFile && f.lastModified() < limit) f.delete()
                }
            } catch (_: Exception) {
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onAppResumed()
    }

    override fun onPause() {
        super.onPause()
        viewModel.onAppPaused()
    }

    override fun onStop() {
        super.onStop()
        viewModel.onAppBackgrounded()
    }

    override fun onDestroy() {
        super.onDestroy()
        FilePickerBridge.launcher = null
        PermissionBridge.requester = null
    }
}
