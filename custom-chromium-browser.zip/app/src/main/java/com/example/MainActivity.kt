package com.example

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.gecko.FilePickerBridge
import com.example.gecko.MediaPlaybackService
import com.example.gecko.PermissionBridge
import com.example.ui.BrowserScreen
import com.example.ui.BrowserViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: BrowserViewModel by viewModels()

    private var filePickerCallback: ((Int, Intent?) -> Unit)? = null
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        filePickerCallback?.invoke(result.resultCode, result.data)
        filePickerCallback = null
    }

    private var permissionCallback: ((Boolean) -> Unit)? = null
    private val requestMultiplePermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.isNotEmpty() && results.values.all { it }
        permissionCallback?.invoke(allGranted)
        permissionCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Đăng ký launcher cho FilePickerBridge trước khi setContent
        FilePickerBridge.launcher = { intent, callback ->
            filePickerCallback = callback
            try {
                filePickerLauncher.launch(intent)
            } catch (_: Exception) {
                callback(Activity.RESULT_CANCELED, null)
                filePickerCallback = null
            }
        }

        // Đăng ký requester cho PermissionBridge trước khi setContent
        PermissionBridge.requester = { permissions, callback ->
            permissionCallback = callback
            try {
                requestMultiplePermissionsLauncher.launch(permissions)
            } catch (_: Exception) {
                callback(false)
                permissionCallback = null
            }
        }

        enableEdgeToEdge()
        handleMediaNotificationIntent(intent)
        setContent {
            val isFullscreen by viewModel.isFullscreen.collectAsStateWithLifecycle()
            val activeTabIsPrivate by viewModel.activeTabIsPrivate.collectAsStateWithLifecycle()

            // Đảm bảo không gán FLAG_SECURE để màn hình không bị đen thui trên Streaming Emulator
            LaunchedEffect(Unit) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }

            // Xử lý chế độ Fullscreen toàn màn hình cho video/web
            LaunchedEffect(isFullscreen) {
                val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                if (isFullscreen) {
                    insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    insetsController.hide(WindowInsetsCompat.Type.systemBars())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        window.attributes = window.attributes.apply {
                            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        }
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                } else {
                    insetsController.show(WindowInsetsCompat.Type.systemBars())
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        window.attributes = window.attributes.apply {
                            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                        }
                    }
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            MyApplicationTheme {
                val isDark = isSystemInDarkTheme()
                val topBarColor = MaterialTheme.colorScheme.surface
                val view = LocalView.current

                if (!view.isInEditMode && !isFullscreen) {
                    SideEffect {
                        val currentWindow = (view.context as? Activity)?.window ?: return@SideEffect
                        val insetsController = WindowCompat.getInsetsController(currentWindow, view)
                        // Icon status bar và navigation bar tự đổi sáng/tối theo theme
                        insetsController.isAppearanceLightStatusBars = !isDark
                        insetsController.isAppearanceLightNavigationBars = !isDark
                    }
                }

                // Khi fullscreen: Bỏ windowInsetsPadding(safeDrawing) để tràn toàn màn hình
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(topBarColor)
                        .then(
                            if (isFullscreen) Modifier else Modifier.windowInsetsPadding(WindowInsets.safeDrawing)
                        )
                ) {
                    BrowserScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMediaNotificationIntent(intent)
    }

    private fun handleMediaNotificationIntent(intent: Intent?) {
        val targetTabId = intent?.getStringExtra(MediaPlaybackService.EXTRA_TAB_ID)
        if (!targetTabId.isNullOrBlank()) {
            viewModel.selectTab(targetTabId)
            intent.removeExtra(MediaPlaybackService.EXTRA_TAB_ID)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onAppResumed()
    }

    override fun onPause() {
        super.onPause()
        viewModel.onAppPaused()
    }

    override fun onStop() {
        super.onStop()
        viewModel.onAppBackgrounded()
    }

    override fun onDestroy() {
        super.onDestroy()
        FilePickerBridge.launcher = null
        PermissionBridge.requester = null
    }
}
